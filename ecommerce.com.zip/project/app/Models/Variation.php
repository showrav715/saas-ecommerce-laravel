<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Variation extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable = [
        'user_id',
        'name',
        'attribute_id',
        'price',
    ];

    public function attribute()
    {
        return $this->belongsTo(Attribute::class)->withDefault([
            'name' => 'no attribute',
        ]);
    }
}
