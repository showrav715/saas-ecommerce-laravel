<?php

namespace App\Models;
use Illuminate\{
    Database\Eloquent\Model
};


class UserPaymentGateway extends Model
{
    protected $fillable = ['title', 'details', 'subtitle', 'name', 'type', 'information','currency_id','status','fixed_charge','percent_charge','user_id','keyword'];
    public $timestamps = false;
    protected $casts = ['currency_id'=>'array'];

    public function currency()
    {
        return $this->belongsTo('App\Models\Currency')->withDefault();
    }

    public static function scopeHasGateway($curr)
    {
        return UserPaymentGateway::where('currency_id', 'like', "%\"{$curr}\"%")->get();
    }

    public function convertAutoData(){
        return  json_decode($this->information,true);
    }

    public function getAutoDataText(){
        $text = $this->convertAutoData();
        return end($text);
    }

    public function showKeyword(){
        $data = $this->keyword == null ? 'other' : $this->keyword;
        return $data;
    }

    public function showCheckoutLink(){
        $link = '';
        $data = $this->keyword == null ? 'other' : $this->keyword;
        if($data == 'paypal'){
            $link = route('seller.front.paypal.submit');
        }else if($data == 'stripe'){
            $link = route('seller.front.stripe.submit');
        }
        else if($data == 'mercadopago'){
            $link = route('seller.front.mercadopago.submit');
        }
        else if($data == 'authorize'){
            $link = route('seller.front.authorize.submit');
        }else if($data == 'paystack'){
            $link = route('seller.front.paystack.submit');
        }else if($data == 'paytm'){
            $link = route('seller.front.paytm.submit');
        }else if($data == 'mollie'){
            $link = route('seller.front.molly.submit');
        }else if($data == 'razorpay'){
            $link = route('seller.front.razorpay.submit');
        }
        
        //else if($data == 'authorize'){
        //     $link = route('front.authorize.submit');
        // }else if($data == 'mercadopago'){
        //     $link = route('front.mercadopago.submit');
        // }else if($data == 'flutterwave'){
        //     $link = route('front.flutter.submit');
        // }else if($data == 'sslcommerz'){
        //     $link = route('front.ssl.submit');
        // }else if($data == 'voguepay'){
        //     $link = route('front.voguepay.submit');
        // }
        else if($data == 'cod'){
            $link = route('seller.front.cod.submit');
        }
        else{
            $link = route('seller.front.manual.submit');
        }
        return $link;
    }

    public function showSubscriptionLink(){
        $link = '';
        $data = $this->keyword;
        if($data == 'paypal'){
            $link = route('user.paypal.submit');
        }else if($data == 'stripe'){
            $link = route('user.stripe.submit');
        }else if($data == 'instamojo'){
            $link = route('user.instamojo.submit');
        }else if($data == 'paystack'){
            $link = route('user.paystack.submit');
        }else if($data == 'paytm'){
            $link = route('user.paytm.submit');
        }else if($data == 'mollie'){
            $link = route('user.molly.submit');
        }else if($data == 'razorpay'){
            $link = route('user.razorpay.submit');
        }else if($data == 'authorize.net'){
            $link = route('user.authorize.submit');
        }else if($data == 'mercadopago'){
            $link = route('user.mercadopago.submit');
        }else if($data == 'flutterwave'){
            $link = route('user.flutter.submit');
        }else if($data == '2checkout'){
            $link = route('user.twocheckout.submit');
        }else if($data == 'sslcommerz'){
            $link = route('user.ssl.submit');
        }else if($data == 'voguepay'){
            $link = route('user.voguepay.submit');
        }else if($data == null){
            $link = route('user.manual.submit');
        }
        return $link;
    }

   


    public function showForm(){
        $show = '';
        $data = $this->keyword == null ? 'other' : $this->keyword;
        $values = ['cod','voguepay','sslcommerz','flutterwave','razorpay','mollie','paytm','paystack','paypal','instamojo'];
        if (in_array($data, $values)){
            $show = 'no';
        }else{
            $show = 'yes';
        }
        return $show;
    }

    public function formUrl(){
        $keyword = $this->keyword;
        $route = route('seller.front.checkout.form.get', $keyword);
        return $route;
    }
}