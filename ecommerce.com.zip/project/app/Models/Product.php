<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'sku',
        'current_price',
        'previus_price',
        'base_price',
        'stock',
        'details',
        'category_id',
        'brand_id',
        'photo',
        'file_type',
        'type',
        'file',
        'link',
        'user_id',
        'attributes_id',
        'variations_id',
        'status',
        'tags',
        'meta_tag',
        'new',
        'trending',
        'best',
        'featured',
        'status',
        'rating'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class)->withDefault([
            'name' => 'No Category',
        ]);

    }
    public function subcategory()
    {
        return $this->belongsTo(Subcategory::class)->withDefault([
            'name' => 'No Subcategory',
        ]);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class)->withDefault([
            'name' => 'No Brand',
        ]);
    }

    public function product_attrs()
    {
        return $this->belongsTo(ProductAttribute::class, 'id', 'product_id');
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function rating()
    {
        $rating  = $this->rating;
        return round($rating,1);
    }

    public function galleries()
    {
        return $this->hasMany(Gallery::class);
    }

}
