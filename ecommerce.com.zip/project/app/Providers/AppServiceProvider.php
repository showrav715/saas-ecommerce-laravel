<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\Generalsetting;
use App\Models\SupportTicket;
use App\Models\UserCurrency;
use App\Models\UserGeneralsetting;
use App\Models\UserSocialLink;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register()
    {

        view()->composer('*', function ($settings) {
            if (\Request::is('admin') || \Request::is('admin/*')) {
                $settings->with('gs', Generalsetting::first());
            } elseif (\Request::is('seller') || \Request::is('seller/*')) {
                $user = getUser('user_id');
                $settings->with('gs', cache()->remember('seller' . getUser('domain') . getUser('user_id'), now()->addDay(), function () use ($user) {
                    return UserGeneralsetting::where('user_id', $user)->first();
                }));
                $settings->with('globalcurrency', cache()->remember('globalcurrency' . getUser('user_id'), now()->addDay(), function () use ($user) {
                    return UserCurrency::where('user_id', $user)->get();
                }));
            }

        });

        view()->composer('front.*', function ($settings) {
            $settings->with('gs', Generalsetting::first());
        });

        view()->composer('admin.partials.sidebar', function ($view) {
            $view->with([
                'pending_seller_ticket' => SupportTicket::where('user_type', 'seller')->whereStatus(0)->whereHas('messages')->count(),
            ]);
        });
        view()->composer('seller.*', function ($view) {
            $user = getUser('user_id');
            $check = UserCurrency::where('user_id', $user)->get();
            if ($check->count() == 0) {
                addCurrency();
            }
        });

        view()->composer(['sellerFront.*', 'sellerUser.*'], function ($settings) {
           
            $user = getUser('user_id');
            if ($user == 'user_id') {
                return true;
            }
            $settings->with('gs', cache()->remember(getUser('domain') . getUser('user_id'), now()->addDay(), function () use ($user) {
                return UserGeneralsetting::where('user_id', $user)->first();
            }));
            $settings->with('socialLink', cache()->remember('socialLink' . getUser('user_id'), now()->addDay(), function () use ($user) {
                return UserSocialLink::where('user_id', $user)->first();
            }));
            $settings->with('globalcategory', cache()->remember('category' . getUser('user_id'), now()->addDay(), function () use ($user) {
                return Category::withCount('subcategories', 'products')->with('subcategories')->where('user_id', $user)->get();
            }));

            $settings->with('globalcurrency', cache()->remember('globalcurrency' . getUser('user_id'), now()->addDay(), function () use ($user) {
                $check = UserCurrency::where('user_id', $user)->get();
                if ($check->count() == 0) {
                    addCurrency();
                }
                return UserCurrency::where('user_id', $user)->get();
            }));

           
        });

    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
