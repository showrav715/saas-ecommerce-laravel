
<?php

use App\Http\Helpers\EmailHelper;
use App\Models\ContactPage;
use App\Models\Currency;
use App\Models\Domain;
use App\Models\Generalsetting;
use App\Models\Location;
use App\Models\Order;
use App\Models\Package;
use App\Models\PackageOrder;
use App\Models\Shipping;
use App\Models\User;
use App\Models\UserCurrency;
use App\Models\UserGeneralsetting;
use App\Models\UserPaymentGateway;
use App\Models\Variation;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

function getPhoto($filename, $seller_id = null)
{
    if ($seller_id) {
        if ($filename) {
            if (file_exists('assets/images/' . $seller_id . '/' . $filename)) {
                return asset('assets/images/' . $seller_id . '/' . $filename);
            } else {
                return asset('assets/images/default.png');
            }

        } else {
            return asset('assets/images/default.png');
        }

    } else {
        if ($filename) {
            if (file_exists('assets/images' . '/' . $filename)) {
                return asset('assets/images/' . $filename);
            } else {
                return asset('assets/images/default.png');
            }

        } else {
            return asset('assets/images/default.png');
        }
    }

}

function getFile($filename, $seller_id = null)
{

    if ($seller_id) {
        if ($filename) {
            if (file_exists('assets/images/' . $seller_id . '/files/' . $filename)) {
                return asset('assets/images/' . $seller_id . '/files/' . $filename);
            } else {
                return asset('assets/images/default.png');
            }

        } else {
            return asset('assets/images/default.png');
        }

    } else {
        if ($filename) {
            if (file_exists('assets/images' . '/' . $filename)) {
                return asset('assets/images/' . $filename);
            } else {
                return asset('assets/images/default.png');
            }

        } else {
            return asset('assets/images/default.png');
        }
    }

}

function sellerpath()
{
    $location = asset('assets/images/' . auth()->user()->id);
    if (!file_exists($location)) {
        mkdir($location, 0777, true);
    }
    return $location;
}
function adminpath()
{
    $location = asset('assets/images/');
    if (!file_exists($location)) {
        mkdir($location, 0777, true);
    }
    return $location;
}

function tagFormat($tag)
{
    $common_rep = ["value", "{", "}", "[", "]", ":", "\""];
    $tag = str_replace($common_rep, '', $tag);
    if (!empty($tag)) {
        return $tag;
    } else {
        return null;
    }
}

function diffTime($time)
{
    return Carbon::parse($time)->diffForHumans();
}

function filter($key, $value)
{
    $queries = request()->query();
    if (count($queries) > 0) {
        $delimeter = '&';
    } else {
        $delimeter = '?';
    }

    if (request()->has($key)) {
        $url = request()->getRequestUri();
        $pattern = "\?$key";
        $match = preg_match("/$pattern/", $url);
        if ($match != 0) {
            return preg_replace('~(\?|&)' . $key . '[^&]*~', "\?$key=$value", $url);
        }

        $filteredURL = preg_replace('~(\?|&)' . $key . '[^&]*~', '', $url);
        return $filteredURL . $delimeter . "$key=$value";
    }
    return request()->getRequestUri() . $delimeter . "$key=$value";
}

function randNum($digits = 6)
{
    return rand(pow(10, $digits - 1), pow(10, $digits) - 1);
}

function numFormat($amount, $length = 2)
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }
    // if (0 < $length) {
    //     return number_format($amount + 0, $length);
    // }

    $total = round($amount * $curr->value, $length);
    return $total;
}

function dateFormat($date, $format = 'd M Y -- h:i a')
{
    return Carbon::parse($date)->format($format);
}

function defaultCurr()
{
    return Currency::where('default', 1)->first();
}

function admin()
{
    return auth()->guard('admin')->user();
}
function seller()
{
    return auth()->guard('web')->user();
}

function sellerId()
{
    return getUser('user_id');
}

function menu($route)
{
    if (is_array($route)) {
        foreach ($route as $value) {
            if (request()->routeIs($value)) {
                return 'active';
            }
        }
    } elseif (request()->routeIs($route)) {
        return 'active';
    }
}

function adminShowAmount($amount)
{
    $curr = Currency::where('default', 1)->first();
    $total = round($amount * $curr->value, 2);
    return $curr->symbol . $total;
}

function sellerShowAmount($amount)
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }

    $user = getUser('user_id');
    $setting = cache()->remember(getUser('domain') . getUser('user_id'), now()->addDay(), function () use ($user) {
        return UserGeneralsetting::where('user_id', $user)->first();
    });

    $total = numFormat($amount);
    if ($setting->currency_possition == 'left') {
        return $curr->symbol . $total;
    } else {
        return $total . $curr->symbol;
    }
}

function sellerConvertAmount($amount)
{
    return numFormat($amount);
}

function sellerStoreAmount($amount)
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }
    return $amount / $curr->value;
}

function adminCurrency()
{
    $curr = Generalsetting::first();
    return $curr->currency_icon;
}

function sellerCurrency()
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }
    return $curr->symbol;
}

function sellerCurrencyData()
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }
    return $curr;
}

function landingCurrencyData()
{
    if (Session::has('landing_currency')) {
        $curr = Currency::where('id', Session::get('landing_currency'))->first();
    } else {
        $curr = Currency::where('default', 1)->first();
    }
    return $curr;
}

function adminCurrencyCode()
{
    $curr = Generalsetting::first();
    return $curr->currency_code;
}

function landingCurrency()
{
    if (Session::has('landing_currency')) {
        $curr = Currency::where('id', Session::get('landing_currency'))->first();
    } else {
        $curr = Currency::where('default', 1)->first();
    }
    return $curr;
}

function sellerCurrencyCode()
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }
    return $curr->code;
}

function sellerCurrencyDirection()
{
    $curr = UserGeneralsetting::where('user_id', getUser('user_id'))->first();

    return $curr->currency_possition;
}

function setEnv($key, $value, $old = null)
{
    if ($old) {
        $keVal = $old;
    } else {
        $keVal = env($key);
    }

    file_put_contents(app()->environmentFilePath(), str_replace(
        $key . '=' . $keVal,
        $key . '=' . $value,
        file_get_contents(app()->environmentFilePath())
    ));
}

if (!function_exists('getUser')) {
    function getUser($type = null)
    {

        $url = Request::getHost();
        $url = str_replace('www.', '', $url);
        Cache::forget($url);
        // cache domain store
        $data = Cache::remember($url, 70000, function () use ($url) {
            return Domain::whereDomain($url)->first();
        });

        if ($data) {
            $data = $data->toArray();
        } else {
            return $type;
        }
        if ($type == 'user_id') {
            return $data['user_id'];
        }
        if ($type == 'domain') {
            return $data['domain'];
        }
        if ($type == 'status') {
            return $data['status'];
        }
        if ($type == 'is_trial') {
            return $data['is_trial'];
        }
        if ($type == 'will_expire') {
            return $data['will_expire'];
        }
        if ($type == 'plan') {
            return json_decode($data['data']);
        }
        return $data;
    }
}

if (!function_exists('getPackage')) {
    function getPackage($type = null)
    {
        $url = Request::getHost();
        $url = str_replace('www.', '', $url);

        // cache domain store
        $data = Cache::remember($url, 70000, function () use ($url) {
            return Domain::whereDomain($url)->first();
        });

        $data = json_decode($data->data);
        if ($type == 'category_limit') {
            return $data->category_limit;
        }

        if ($type == 'product_limit') {
            return $data->product_limit;
        }

        if ($type == 'customer_limit') {
            return $data->customer_limit;
        }
        if ($type == 'brand_limit') {
            return $data->brand_limit;
        }
        if ($type == 'variant_limit') {
            return $data->variant_limit;
        }
        if ($type == 'custom_domain') {
            return $data->custom_domain;
        }
        if ($type == 'customer_panel_access') {
            return $data->customer_panel_access;
        }
        if ($type == 'support') {
            return $data->support;
        }
        if ($type == 'qr_code') {
            return $data->qr_code;
        }
        if ($type == 'facebook_pixel') {
            return $data->facebook_pixel;
        }
        if ($type == 'google_analytics') {
            return $data->google_analytics;
        }

    }
}

function discountPrice($product)
{
    $price = $product->base_price;
    $discount = $product->previous_price;
    $discount = ($discount - $price) / $discount * 100;

    if ($discount > 0) {
        return '-' . round($discount, 1) . '%';
    }
    if ($discount == 0) {
        return '0%';
    }
}

function productBasePrice($product, $status = 0)
{
    if (Session::has('currency' . sellerId())) {
        $curr = UserCurrency::where('user_id', sellerId())->where('id', Session::get('currency' . sellerId()))->first();
    } else {
        $curr = UserCurrency::where('user_id', sellerId())->where('default', 1)->first();
    }

    $user = getUser('user_id');
    $setting = cache()->remember(getUser('domain') . getUser('user_id'), now()->addDay(), function () use ($user) {
        return UserGeneralsetting::where('user_id', $user)->first();
    });

    $options = json_decode($product->product_attrs->variation_id, true);
    $option_price = 0;
    if ($options) {
        foreach ($options as $option) {
            if ($option) {
                $main_option = Variation::findOrFail($option[0]);
                if ($main_option) {
                    $option_price += $main_option->price;
                }
            }
        }
    }

    $total = $product->current_price + $option_price;
    $total = numFormat($total);
    if ($status == 0) {
        if ($setting->currency_possition == 'left') {
            return $curr->symbol . $total;
        } else {
            return $total . $curr->symbol;
        }
    } else {
        return $total;
    }
}

function addCurrency()
{
    $sellerId = sellerId();
    $currency = new UserCurrency;
    $currency->user_id = $sellerId;
    $currency->code = 'USD';
    $currency->symbol = '$';
    $currency->default = 1;
    $currency->status = 1;
    $currency->value = 1;
    $currency->save();
}

function generateIndex($attrs, $colors)
{

    try {
        foreach ($attrs as $attr) {
            $name[] = Str::slug($attr['name']);
        }
        if ($colors) {
            array_push($name, Str::slug($colors['color_name']));
        }
        $generate = implode('__', $name);
        return $generate;
    } catch (\Throwable$th) {
        $generate = Str::random(5);
        return $generate;
    }

}

function attributePrice($attrs, $product)
{
    $total = 0;
    foreach ($attrs as $attr) {
        $total += $attr['price'];
    }
    return $total + $product->current_price;
}

function cacheRemove($key)
{
    switch ($key) {
        case 'products':
            Cache::forget('new_products' . getUser('domain'));
            Cache::forget('best_sellings' . getUser('domain'));
            break;

        case 'categories':
            Cache::forget('feature_category' . getUser('domain'));
            break;

        case 'slider':
            Cache::forget('slider' . getUser('domain'));
            break;
        case 'gs':
            Cache::forget(getUser('domain') . getUser('user_id'));
            break;

        case 'banners':
            Cache::forget('banners' . getUser('domain'));
            break;
        case 'services':
            Cache::forget('services' . getUser('domain'));
            break;
        case 'front_blogs':
            Cache::forget('front_blogs' . getUser('domain'));
            Cache::forget('recent_blogs' . getUser('domain'));
            break;
        case 'blog_categories':
            Cache::forget('blog_categories' . getUser('domain'));
            break;

        default:
            # code...
            break;
    }
}

function getCartItemId($cartIndex)
{
    $itemId = explode('-', $cartIndex)[0];
    return $itemId;
}

function shippingCost($shipping_id)
{
    $shipping = Shipping::findOrFail($shipping_id);
    return $shipping->price;
}

function discountAmount()
{
    if (Session::has('discount' . sellerId())) {
        $discount = Session::get('discount' . sellerId());
    } else {
        $discount = [];
    }

    return $discount;
}

function orderNumber()
{
    $gs = UserGeneralsetting::where('user_id', getUser('user_id'))->first();
    return $gs->order_prefix . '-' . Str::random(9);
}

function shippingwithlocation($location_link, $shipping_data)
{

    $location_id = explode('/', $location_link);
    $location_id = end($location_id);
    $location = Location::findOrFail($location_id)->toArray();
    $shipping = Shipping::findOrFail($shipping_data)->toArray();

    $data['location'] = $location;
    $data['shipping'] = $shipping;
    $data = json_encode($data);
    return $data;

}

function checkoutValidate($request)
{
    $request->validate([
        'name' => 'required',
        'email' => 'required|email',
        'phone' => 'required',
        'delivery_address' => 'required',
        'zip' => 'required',
        'location' => 'required',
        'shipping_fee' => 'required',
    ]);
}

function checkoutProcess($request, $method = null)
{

    $methods = ['paypal', 'paytm', 'razorpay'];

    if (in_array($method, $methods)) {
        $input = $request;
    } else {
        $input = $request->all();
    }
    $shippingCost = shippingCost($input['shipping_fee']);
    $data['shippingwithlocation'] = shippingwithlocation($input['location'], $input['shipping_fee']);
    $discountAmount = discountAmount();
    $cart = Session::get('cart' . sellerId());
    $item_amount = array_sum(array_column($cart, 'cart_item_price'));
    $item_amount = $item_amount + $shippingCost;
    $data['item_amount'] = $item_amount-@$discountAmount['discount'];
    $data['item_number'] = Str::random(9);
    $data['item_name'] = implode(array_column($cart, 'name'));
    $data['discountAmount'] = $discountAmount;
    $data['cart'] = $cart;
    return $data;
}

function createOrder($request, array $process, array $array = null, $method = null)
{
    $method = ['paypal', 'paytm', 'razorpay'];
    if (in_array(@$array['method'], $method)) {
        $input = $request;
    } else {
        $input = $request->all();
    }

    $order = new Order();
    $order->cart = json_encode($process['cart']);
    $order->discount = json_encode($process['discountAmount']);
    $order->shipping = $process['shippingwithlocation'];
    $order->seller_id = sellerId();
    $order->user_id = auth()->user()->id;
    $order->order_number = orderNumber();
    $order->name = $input['name'];
    $order->email = $input['email'];
    $order->phone = $input['phone'];
    $order->delivery_address = $input['delivery_address'];
    $order->zip = @$input['zip'];
    $order->payment_method = $array['payment_method'];
    $order->payment_status = $array['payment_status'];
    $order->order_status = 0;
    $order->txn_id = $array['txn'];
    $order->order_total = $process['item_amount'];
    $order->note = @isset($input['order_comments']) ? $input['order_comments'] : '';
    $order->currency = sellerCurrencyData();
    $order->created_at = now();
    $order->save();
    Session::forget('cart' . sellerId());
    sendUserMail($order);
    return $order;
}

function sendUserMail($order)
{
    $name = $order->name;
    $order_number = $order->order_number;
    $order_total = sellerShowAmount($order->order_total);
    $txn_id = $order->txn_id;
    $data = [
        'name' => $name,
        'email' => $order->email,
        'seller_id' => $order->seller_id,
        'subject' => 'Order Placed Successfully',
        'body' => 'Hi <b>' . $name . ' </b> Your order has been placed successfully. Your order number is <b>' . $order_number . ' </b> and total amount is <b>' . $order_total . '</b> and transaction id is <b>' . $txn_id . '</b> Thanks for shopping with us. ',
    ];

    $send = new EmailHelper();
    $send->sellerMail($data);
}

function sellerOrderAmount($order)
{
    $currency = json_decode($order->currency);
    $total = $order->order_total * $currency->value;
    //dd($currency);
    $curr = cache()->remember(getUser('domain') . getUser('user_id'), now()->addDay(), function () {
        return UserGeneralsetting::where('user_id', sellerId())->first();
    });
    if ($curr->currency_possition == 'left') {
        return $currency->symbol . $total;
    } else {
        return $total . $currency->symbol;
    }
}

function sellerOrderShippingAmount($order)
{
    $currency = json_decode($order->currency);
    if ($order->shipping) {
        $shipping = json_decode($order->shipping);
        $total = $shipping->shipping->price * $currency->value;
        $curr = cache()->remember(getUser('domain') . getUser('user_id'), now()->addDay(), function () {
            return UserGeneralsetting::where('user_id', sellerId())->first();
        });
        if ($curr->currency_possition == 'left') {
            return $currency->symbol . $total;
        } else {
            return $total . $currency->symbol;
        }
    } else {
        return 0 . $currency->symbol;
    }

}

function createStore($request, $txn_id, $method, $payment_status)
{
    DB::beginTransaction();
    try {

        // create a new user
        $user = new User();
        $user->name = $request['name'];
        $user->email = $request['email'];
        $user->password = Hash::make($request['password']);
        $user->role = 'seller';
        $user->status = 1;
        $user->email_verified = 1;
        $user->save();

        try {
            $file = fopen('assets/admin/files/temp_payment.csv', "r");
            $i = 1;

            while (($line = fgetcsv($file)) !== false) {

                if ($i != 1) {

                    $input['subtitle'] = $line[0];
                    $input['title'] = $line[1];
                    $input['details'] = $line[2];
                    $input['name'] = $line[3];
                    $input['type'] = $line[4];
                    $input['information'] = $line[5];
                    $input['keyword'] = $line[6];
                    $input['currency_id'] = $line[7];
                    $input['status'] = $line[8];
                    $input['user_id'] = $user->id;
                    $gateway = new UserPaymentGateway();
                    $gateway->fill($input)->save();
                }

                $i++;
            }
            fclose($file);
        } catch (\Throwable$th) {
            throw $th;
        }

        // create a new general setting
        $preload_gs = UserGeneralsetting::where('id', 0)->first()->toArray();
        $preload_gs['user_id'] = $user->id;
        $gs = new UserGeneralsetting();
        $gs->fill($preload_gs)->save();

        // create a new contact page
        $preload_contact_pages = ContactPage::where('id', 0)->first()->toArray();
        $preload_contact_pages['user_id'] = $user->id;
        $contact_page = new ContactPage();
        $contact_page->fill($preload_contact_pages)->save();

        $package = Package::find($request['package_id']);
        $exp_days = $package->days;
        $expiry_date = \Carbon\Carbon::now()->addDays(($exp_days))->format('Y-m-d');

        // create a new package order
        $order = new PackageOrder();
        $order->order_no = $user->id . 'ORD-' . time();
        $order->amount = $package->price / landingCurrency()->value;
        $order->txn = $txn_id;
        $order->will_expire = $expiry_date;
        $order->user_id = $user->id;
        $order->currency = json_encode(landingCurrency(), true);
        $order->package_id = $package->id;
        $order->method = $method;
        $order->status = 1;
        $order->payment_status = $payment_status;
        $order->save();

        // create a new Domain
        $main_domain = env('MAIN_DOMAIN');
        $domain = $request['domain'];
        $final = $domain . '.' . $main_domain;
        $dom = new Domain();
        $dom->domain = $final;
        $dom->status = 1;
        $dom->user_id = $user->id;
        $dom->is_trial = $package->price == 0 ? 1 : 0;
        $dom->data = json_encode($package, true);
        $dom->will_expire = $expiry_date;
        $dom->package_order_id = $order->id;
        $dom->save();

        // update domain id
        $user = User::find($user->id);
        $user->domain_id = $dom->id;
        $user->save();
        DB::commit();
        return 1;

    } catch (\Exception$e) {
        DB::rollback();
        dd($e->getMessage());
        return 0;
    }
}

function subscriptionStore($request, $package_id, $txn_id, array $array = null)
{

    DB::beginTransaction();
    try {

        $user = Auth::user();
        $package = Package::find($package_id);
        $exp_days = $package->days;

        $current_domain = $user->domain;
        $current_package = json_decode($current_domain->data, true)['id'];
        if ($package->id == $current_package) {
            $old_expire_date = $current_domain->will_expire;
            $expiry_date = \Carbon\Carbon::parse($old_expire_date)->addDays(($exp_days))->format('Y-m-d');
        } else {
            $expiry_date = \Carbon\Carbon::now()->addDays(($exp_days))->format('Y-m-d');
        }

        // create a new package order
        $order = new PackageOrder();
        $order->order_no = $user->id . 'ORD-' . time();
        $order->amount = $package->price;
        $order->txn = $txn_id;
        $order->will_expire = $expiry_date;
        $order->user_id = $user->id;
        $order->package_id = $package->id;
        $order->currency = sellerCurrencyData();
        $order->method = $array['payment_method'];
        $order->status = 1;
        $order->payment_status = $array['payment_status'];
        $order->save();

        // update  Domain
        $dom = Domain::where('user_id', $user->id)->first();
        $dom->is_trial = $package->price == 0 ? 1 : 0;
        $dom->data = json_encode($package, true);
        $dom->will_expire = $expiry_date;
        $dom->package_order_id = $order->id;
        $dom->save();
        DB::commit();

        // send mail
        subMail($package, $user, $order);
        return true;

    } catch (\Throwable$th) {
        DB::rollback();
        dd($th->getMessage());
        return false;
    }
}

function subMail($package, $user, $order)
{
    $message = 'Your subscription has been successfully completed.Your subscription package is <b>' . $package->name . '</b>. and your subscription will expire on <b>' . $order->will_expire . '</b>. Thank you for choosing us.';
    $data = [
        'name' => $user->name,
        'email' => $user->email,
        'subject' => 'Subscription Completed',
        'body' => $message,
    ];
    $send = new EmailHelper();
    $send->customMail($data);
}

function checkPackage($user_id)
{
    $last_active_package = PackageOrder::where('user_id', $user_id)->where('status', 1)->orderBy('id', 'desc')->first();
    return $last_active_package;
}

function checkSellerEndData()
{
    $user = Auth::user();
    $domain = $user->domain;
    $expire_date = Carbon::parse($domain->will_expire)->format('Y-m-d');
    $today = Carbon::now()->format('Y-m-d');

    if ($expire_date < $today) {
        return true;
    }
    return false;
}

function sellerCheckCurrency(array $currencies)
{
    $seller_currency = sellerCurrencyData();
    if (in_array($seller_currency->id, $currencies)) {
        return true;
    } else {
        return false;
    }
}

function landingCheckCurrency(array $currencies)
{
    $landing_currency = landingCurrencyData();

    if (in_array($landing_currency->id, $currencies)) {
        return true;
    } else {
        return false;
    }
}

function checkValidateDomain($domain)
{

    $domains = Domain::get();
    $status = 1;
    foreach ($domains as $dom) {
        if ($dom->domain == $domain) {
            $status = 0;
        }
    }

    return $status;

}

function landingShowAmount($amount, $convert = null)
{

    if (Session::has('landing_currency')) {
        $currency = Currency::find(Session::get('landing_currency'));
        $total = $amount * $currency->value;
    } else {
        $currency = Currency::where('default', 1)->first();
        $total = $amount * $currency->value;
    }

    if ($convert) {
        return round($total, 2);
    }

    return $currency->symbol . round($total, 2);
}