<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\Generalsetting;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
class SellerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:web');
    }

    // DASHBOARD
    public function index()
    {
        
        $name = Str::slug(Auth::id().Auth::user()->name);
        @unlink('assets/qrcode/'.$name.'.png');
        \QrCode::format('png')->size(600,600)->generate(getUser('domain'), 'assets/qrcode/'.$name.'.png');

        $domain = Auth::user()->domain;
        $domain_info = json_decode($domain->data,true);
        $recent_orders = Order::where('seller_id', Auth::user()->id)->orderBy('id', 'DESC')->limit(5)->get();
        $recent_customers = User::withCount('orders')->where('owner_id', Auth::user()->id)->orderBy('id', 'DESC')->limit(5)->get();
        $total_orders = Order::where('seller_id', Auth::user()->id)->count();
        $total_customers = User::where('owner_id', Auth::user()->id)->count();
        $total_products = Product::where('user_id', Auth::user()->id)->count();
        $total_sales = Order::where('seller_id', Auth::user()->id)->sum('order_total');
        return view('seller.dashboard', compact('domain_info','domain','recent_orders','recent_customers','total_orders','total_customers','total_products','total_sales'));
    }

    // PROFILE
    public function profile()
    {
        $data = seller();
        return view('seller.profile', compact('data'));
    }

    // PROFILE
    public function profileupdate(Request $request)
    {
        $request->validate(['name' => 'required', 'email' => 'required|email', 'phone' => 'required']);
        $data = seller();
        $input = $request->only('name', 'photo', 'phone', 'email');

        if ($request->hasFile('photo')) {
            $status = MediaHelper::ExtensionValidation($request->file('photo'));
            if (!$status) {
                return back()->with('error', __('Image format is invalid'));
            }
            $input['photo'] = MediaHelper::handleUpdateImage($request->file('photo'), $data->photo, [200, 200]);
        }

        $data->update($input);
        return back()->with('success', __('Profile Updated Successfully'));
    }

    // CHANGE PASSWORD
    public function passwordreset()
    {
        return view('seller.change_password');
    }

    public function changepass(Request $request)
    {
        $request->validate(['old_password' => 'required', 'password' => 'required|confirmed|min:6']);
        $user = seller();
        if ($request->old_password) {
            if (Hash::check($request->old_password, $user->password)) {
                $user->password = bcrypt($request->password);
                $user->update();
            } else {
                return back()->with('error', __('Old Password Mismatch'));
            }
        }

        return back()->with('success', __('Password Changed Successfully'));

    }


    public function cookie()
    {
        return view('admin.cookie');
    }

    public function updateCookie(Request $request)
    {
        $data = $request->validate([
            'status' => 'required',
            'button_text' => 'required',
            'cookie_text' => 'required',
        ]);

        $gs = Generalsetting::first();
        $gs->cookie = $data;
        $gs->update();
        return back()->with('success', 'Cookie concent updated');
    }


}
