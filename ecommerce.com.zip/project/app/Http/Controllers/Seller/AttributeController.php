<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Attribute;
use Illuminate\Http\Request;

class AttributeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:web')->except('status');
    }

    public function index()
    {
        $attributes = Attribute::with('variations')->orderby('id','desc')->paginate(15);
        return view('seller.products.attributes.index', compact('attributes'));
    }

    public function store(Request $request)
    {
        
        if(Attribute::where('user_id',seller()->id)->count() >= getPackage('variant_limit')){
            return back()->with('error', __('You have reached your variant limit'));
        }
        
        $request->validate([
            'name' => 'required|string|max:255|unique:attributes,name',
        ]);

        $attribute = new Attribute();
        $attribute->name = $request->name;
        $attribute->user_id = auth()->user()->id;
        $attribute->save();
        
        return back()->with('success', __('Attribute added successfully'));
    }

    public function update(Request $request, $id)
    {
        $attribute = Attribute::findOrFail($id);
        $request->validate([
            'name' => 'required|string|max:255|unique:attributes,name,' . $attribute->id,
        ]);

        $attribute->name = $request->name;
        $attribute->user_id = auth()->user()->id;
        $attribute->save();

        return back()->with('success', __('Attribute updated successfully'));
    }

    public function destory(Request $request)
    {
        $attribute = Attribute::findOrFail($request->id);
        $attribute->delete();
        return back()->with('success', __('Attribute deleted successfully'));
    }
}
