<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\UserService;
use Illuminate\Http\Request;

class ServiceController extends Controller
{

    public function index()
    {
        $services = UserService::orderby('id', 'desc')->paginate(15);
        return view('seller.service.index', compact('services'));
    }

    public function store(Request $request)
    {
        $this->storeData($request,new UserService());
        return back()->with('success', __('Service added successfully'));
    }

    public function update(Request $request, $id)
    {
        $service = UserService::findOrFail($id);
        $this->storeData($request,$service,$id);
        return back()->with('success', __('Service updated successfully'));
    }

    public function destory(Request $request)
    {
        $service = UserService::findOrFail($request->id);
        $service->delete();
        cacheRemove('services');
        return back()->with('success', __('Service deleted successfully'));
    }

    public function storeData($request,$data,$id=null)
    {
        $request->validate([
            'title' => 'required|string|max:255|unique:user_services,title'. ($id ? ','.$id : ''),
            'text' => 'required|string',
            'status' => 'required|boolean',
            'icon' => 'required|string',
        ]);

        $data->title = $request->title;
        $data->text = $request->text;
        $data->status = $request->status;
        $data->user_id = auth()->user()->id;
        $data->icon = $request->icon;
        $data->save();
        cacheRemove('services');
        
    }
}
