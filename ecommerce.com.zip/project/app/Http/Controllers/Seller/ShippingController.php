<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\Shipping;
use Illuminate\Http\Request;

class ShippingController extends Controller
{

    public function index()
    {
        $shipping = Shipping::whereUserId(auth()->user()->id)->orderby('id','desc')->paginate(15);
        $locations = Location::whereStatus(1)->get();
      
        return view('seller.shipping.index', compact('shipping','locations'));
    }

    public function store(Request $request)
    {
        $this->storeData($request, new Shipping());
        return back()->with('success', __('Shipping added successfully'));
    }

    public function update(Request $request, $id)
    {
        $shipping = Shipping::findOrFail($id);
        $this->storeData($request, $shipping,$id);
        return back()->with('success', __('Shipping updated successfully'));
    }

    public function destory(Request $request)
    {
        $shipping = Shipping::findOrFail($request->id);
        $shipping->delete();
        return back()->with('success', __('Shipping deleted successfully'));
    }


    public function storeData($request,$data,$id=null)
    {
       
        $request->validate([
            'shipping' => 'required|string|max:255|unique:shippings,shipping' . ($id ? ',' . $id : ''),
            'price' => 'required|numeric',
            'locations.*' => 'required|integer|exists:locations,id',
            'status' => 'required|boolean',
        ]); 

        $data->shipping = $request->shipping;
        $data->price = sellerStoreAmount($request->price);
        $data->locations = json_encode($request->locations);
        $data->status = $request->status;
        $data->user_id = auth()->user()->id;
        $data->save();

    }
}
