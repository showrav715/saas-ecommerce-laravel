<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\UserCurrency;
use App\Models\UserPaymentGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
class PaymentMethodController extends Controller
{
    public function index()
    {
        $gatewayes = UserPaymentGateway::where('user_id', Auth::user()->id)->get();
        return view('seller.gateway.index', compact('gatewayes'));
    }

    public function create()
    {
        return view('seller.gateway.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'unique:payment_gateways',
        ]);

        $data = new UserPaymentGateway();
        $data->user_id = Auth::user()->id;
        $data->title = $request->title;
        $data->subtitle = $request->subtitle;
        $data->details = $request->details;
        $data->type = 'manual';
        $data->status = $request->status;
        $data->keyword = Str::slug($request->title);
        $data->save();
        return back()->with('success', 'Payment Method Added Successfully.');

    }

    public function edit($id)
    {
        $data = UserPaymentGateway::findOrFail($id);
        $currencies = UserCurrency::where('user_id', Auth::user()->id)->get();
        return view('seller.gateway.edit', compact('data', 'currencies'));
    }

    public function update(Request $request, $id)
    {

        $data = UserPaymentGateway::findOrFail($id);
        if ($data->type == "automatic") {
            $request->validate([
                'name' => 'unique:payment_gateways,name,' . $id,
                'currency_id' => 'required',
            ]);

            $input = $request->all();
            $info_data = $input['pkey'];

            if (array_key_exists("sandbox_check", $info_data)) {
                $info_data['sandbox_check'] = 1;
            } else {
                if (strpos($data->information, 'sandbox_check') !== false) {
                    $info_data['sandbox_check'] = 0;
                    $text = $info_data['text'];
                    unset($info_data['text']);
                    $info_data['text'] = $text;
                }
            }
     
            $input['information'] = json_encode($info_data);
            $input['currency_id'] = implode(',', $request->currency_id);
            
            $data->update($input);

        } else {
            $request->validate([
                'title' => 'unique:payment_gateways,title,' . $id,
            ]);
         
            $input = $request->all();
            $data->update($input);

        }

        return back()->with('success', 'Payment Method Updated Successfully.');
    }

    public function delete(Request $request)
    {

        $data = UserPaymentGateway::whereUserId(Auth::id())->findOrFail($request->id);
        if ($data->type == 'manual' || $data->keyword != null) {
            $data->delete();
        }

        return back()->with('success', 'Payment Method Deleted Successfully.');

    }
}
