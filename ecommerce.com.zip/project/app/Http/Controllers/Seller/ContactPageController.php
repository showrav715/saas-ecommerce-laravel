<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\ContactMessage;
use App\Models\ContactPage;
use Illuminate\Http\Request;

class ContactPageController extends Controller
{
    public function index()
    {
        $contactPage = ContactPage::whereUserId(auth()->user()->id)->first();
        return view('seller.contact.index', compact('contactPage'));
    }

    public function update(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'text' => 'required',
            'office_address' => 'required',
            'contact_number' => 'required',
            'email_address' => 'required',
            'career_info' => 'required',
        ]);

        $contactPage = ContactPage::whereUserId(auth()->user()->id)->first();
        if ($contactPage) {
            $contactPage->title = $request->title;
            $contactPage->text = $request->text;
            $contactPage->office_address = $request->office_address;
            $contactPage->contact_number = $request->contact_number;
            $contactPage->email_address = $request->email_address;
            $contactPage->career_info = $request->career_info;
            $contactPage->save();
        } else {
            $contactPage = new ContactPage();
            $contactPage->title = $request->title;
            $contactPage->text = $request->text;
            $contactPage->office_address = $request->office_address;
            $contactPage->contact_number = $request->contact_number;
            $contactPage->email_address = $request->email_address;
            $contactPage->career_info = $request->career_info;
            $contactPage->user_id = auth()->user()->id;
            $contactPage->save();
        }

        return redirect()->back()->with('success', 'Contact Page Updated Successfully');

    }


    public function messages()
    {
        $messages = ContactMessage::whereUserId(auth()->user()->id)->get();
        return view('seller.contact.messages', compact('messages'));
    }

    public function delete(Request $request)
    {
        $message = ContactMessage::whereUserId(auth()->user()->id)->whereId($request->id)->first();
        $message->delete();
        return redirect()->back()->with('success', 'Message Deleted Successfully');
    }
}
