<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\UserGeneralsetting;
use App\Models\UserSocialLink;
use Illuminate\Http\Request;

class GeneralSettingController extends Controller
{

    public function update(Request $request)
    {
        $request->validate([
            'title' => 'required_if:basic,1',
            'contact_no' => 'required_if:basic,1',
            'theme_color' => 'required_if:basic,1',
        ], [
            'title.required_if' => 'The title field is required.',
            'contact_no.required_if' => 'The contact number field is required.',
            'theme_color.required_if' => 'The theme color field is required.',
        ]);

        $gs = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        if ($request->basic) {
            $gs->title = $request->title;
            $gs->contact_no = $request->contact_no;
            $gs->theme_color = $request->theme_color;
            $gs->currency_possition = $request->currency_possition;
            $gs->order_prefix = $request->order_prefix;
            $gs->email = $request->email;

        }

        $images = ['header_logo', 'favicon', 'footer_logo'];
        foreach ($images as $image) {
            if (isset($request[$image])) {
                $gs[$image] = MediaHelper::sellerhandleUpdateImage($request[$image], $gs[$image]);
            }
        }

        if($request->facebok_form){
            $gs->facebook_pixel = $request->facebook_pixel;
        }

        if($request->google_form){
            $gs->google_analytics = $request->google_analytics;
        }

        if ($request->social_link == 1) {

            $socialLink = UserSocialLink::where('user_id', auth()->user()->id)->first();

            if ($socialLink) {
                $socialLink->user_id = auth()->user()->id;
                $socialLink->icon = $request->icon;
                $socialLink->url = $request->url;
                $socialLink->icon1 = $request->icon1;
                $socialLink->url1 = $request->url1;
                $socialLink->icon2 = $request->icon2;
                $socialLink->url2 = $request->url2;
                $socialLink->icon3 = $request->icon3;
                $socialLink->url3 = $request->url3;
                $socialLink->icon4 = $request->icon4;
                $socialLink->url4 = $request->url4;
                $socialLink->update();

            } else {
                $socialLink = new UserSocialLink();
                $socialLink->user_id = auth()->user()->id;
                $socialLink->icon = $request->icon;
                $socialLink->url = $request->url;
                $socialLink->icon1 = $request->icon1;
                $socialLink->url1 = $request->url1;
                $socialLink->icon2 = $request->icon2;
                $socialLink->url2 = $request->url2;
                $socialLink->icon3 = $request->icon3;
                $socialLink->url3 = $request->url3;
                $socialLink->icon4 = $request->icon4;
                $socialLink->url4 = $request->url4;
                $socialLink->save();
            }

        }

        if ($request->footer == 1) {
            
            $request->validate([
                'footer_text' => 'required',
                'copyright_text' => 'required',

            ], [
                'footer_text.required' => 'The footer text field is required.',
                'copyright_text.required' => 'The copy right field is required.',
            ]);
 
            $gs->footer_text = $request->footer_text;
            $gs->copyright_text = $request->copyright_text;
            $gs->copyright_show = $request->copyright_show;

        }

        if ($request->header == 1) {
            $gs->support_number = $request->support_number;
            $gs->currency_show = $request->currency_show;
            $gs->language_show = $request->language_show;
        }
        
        $gs->update();
        cacheRemove('gs');
        return redirect()->back()->with('success', 'Data updated successfully');
    }

    public function logo()
    {
        $setting = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        return view('seller.generalsetting.logo', compact('setting'));
    }

    public function menu()
    {
        $setting = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        return view('seller.generalsetting.menu_section', compact('setting'));
    }

    public function siteSettings()
    {
        $setting = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        return view('seller.generalsetting.settings', compact('setting'));
    }

    public function otherSettings()
    {
        $setting = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        $socialLink = UserSocialLink::where('user_id', auth()->user()->id)->first();
        return view('seller.generalsetting.other_settings', compact('setting', 'socialLink'));
    }

    public function google_analytics()
    {
        if (getPackage('google_analytics') == 0) {
            return redirect()->back()->with('error', 'You have not access to this feature.');
        }
        $setting = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        return view('seller.generalsetting.google_analytics', compact('setting'));
    }
    public function facebookPixel()
    {
        if (getPackage('facebook_pixel') == 0) {
            return redirect()->back()->with('error', 'You have not access to this feature.');
        }
        $setting = UserGeneralsetting::where('user_id', auth()->user()->id)->first();
        return view('seller.generalsetting.facebook_pixel', compact('setting'));
    }
}
