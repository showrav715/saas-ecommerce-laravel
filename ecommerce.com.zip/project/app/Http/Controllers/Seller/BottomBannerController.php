<?php

namespace App\Http\Controllers\Seller;
use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\BottomBanner;
use Illuminate\Http\Request;

class BottomBannerController extends Controller
{
    public function index()
    {
        $banner = BottomBanner::whereUserId(auth()->id())->first();
        return view('seller.banner.bottom_banner',compact('banner'));
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'title' => 'required',
            'text' => 'required',
            'photo' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'btn_text' => 'required',
            'btn_link' => 'required',
        ]);
        
        $banner = BottomBanner::whereUserId($id)->first();
        if(!$banner){
            $banner = new BottomBanner();
        }
        $banner->title = $request->title;
        $banner->text = $request->text;
        $banner->btn_text = $request->btn_text;
        $banner->btn_link = $request->btn_link;
        $banner->user_id = $id;
        if ($request['photo']) {
            $status = MediaHelper::ExtensionValidation($request['photo']);
            if (!$status) {
                return ['errors' => [0 => 'file format not supported']];
            }
            $banner->photo = MediaHelper::sellerHandleUpdateImage($request['photo'], $banner->photo);
        }
        $banner->save();
        return back()->with('success', __('Banner updated successfully'));

    }
}
