<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\Banner;
use Illuminate\Http\Request;

class BannerController extends Controller
{
    public function index()
    {
        $banners = Banner::whereUserId(auth()->id())->get();
        return view('seller.banner.index',compact('banners'));
    }


    public function update(Request $request,$id)
    {
        $request->validate([
            'header' => 'required',
            'title' => 'required',
            'subtitle' => 'required',
            'photo' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'link' => 'required',
        ]);

        $banner = Banner::find($id);
        $banner->header = $request->header;
        $banner->title = $request->title;
        $banner->subtitle = $request->subtitle;
        $banner->link = $request->link;
        if ($request['photo']) {
            $status = MediaHelper::ExtensionValidation($request['photo']);
            if (!$status) {
                return ['errors' => [0 => 'file format not supported']];
            }
            $banner->photo = MediaHelper::sellerHandleUpdateImage($request['photo'], $banner->photo);
        }
        $banner->save();
        cacheRemove('banner');
        return back()->with('success', __('Banner updated successfully'));

    }
  
    
}
