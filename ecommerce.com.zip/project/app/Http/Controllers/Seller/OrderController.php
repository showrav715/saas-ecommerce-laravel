<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Helpers\EmailHelper;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with('user')->where('seller_id', Auth::user()->id)->get();
        return view('seller.order.index', compact('orders'));
    }


    public function details($id)
    {
        $order = Order::findOrFail($id);
        return view('seller.order.details', compact('order'));
    }

    public function update(Request $request, $id)
    {
    
        $order = Order::findOrFail($id);
        $order->payment_status = $request->payment_status;
        $order->order_status = $request->order_status;
        $order->save();

        if($request->notify_mail == 'on'){
            if($order->order_status == 0){
                $order_status = 'Pending';
            }elseif($order->order_status == 1){
                $order_status = 'Processing';
            }else{
                $order_status = 'Completed';
            }

            if($order->payment_status == 0){
                $payment_status = 'Unpaid';
            }else{
                $payment_status = 'Paid';
            }


            $data = [
                'email' => $order->user->email,
                'name' => $order->user->name,
                'subject' => 'Order Updated',
                'seller_id' => sellerId(),
                'body' => 'Your order status has been updated. Your order status is '.$order_status.' and payment status is '.$payment_status.'. Order ID: <b>'.$order->order_number.'</b> . Thank you for shopping with us.',
            ];
            $mail = new EmailHelper();
            $mail->sellerMail($data);
        }



        return redirect()->back()->with('success', 'Order status updated successfully');
    }
    
}
    

