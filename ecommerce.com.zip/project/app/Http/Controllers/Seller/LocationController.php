<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Location;
use Illuminate\Http\Request;

class LocationController extends Controller
{

    public function index()
    {
        $locations = Location::whereUserId(auth()->user()->id)->orderby('id','desc')->paginate(15);
        return view('seller.location.index', compact('locations'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'location' => 'required|string|max:255|unique:locations,location',
            'status' => 'required|boolean',
        ]);

        $location = new Location();
        $location->location = $request->location;
        $location->status = $request->status;
        $location->user_id = auth()->user()->id;
        $location->save();
        
        return back()->with('success', __('Location added successfully'));
    }

    public function update(Request $request, $id)
    {
        $location = Location::findOrFail($id);
        $request->validate([
            'location' => 'required|string|max:255|unique:locations,location,' . $location->id,
            'status' => 'required|boolean',
        ]);

        $location->location = $request->location;
        $location->status = $request->status;
        $location->save();

        return back()->with('success', __('Location updated successfully'));
    }

    public function destory(Request $request)
    {
        $location = Location::findOrFail($request->id);
        $location->delete();
        return back()->with('success', __('Location deleted successfully'));
    }
}
