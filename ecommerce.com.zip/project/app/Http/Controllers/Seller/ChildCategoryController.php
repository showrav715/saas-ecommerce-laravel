<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;

class ChildCategoryController extends Controller
{

    public function index($id)
    {
        $categories = Subcategory::with('category')->whereCategoryId($id)->orderby('id','desc')->paginate(15);
        $category = Category::find($id);
        return view('seller.products.subcategory.index', compact('categories','category'));
    }

    public function store(Request $request,$id)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:subcategories,name',
            'slug' => 'required|string|max:255|unique:subcategories,slug',
            'status' => 'required|boolean',
        ]);

        $category = new Subcategory();
        $category->name = $request->name;
        $category->category_id = $id;
        $category->slug = $request->slug;
        $category->status = $request->status;
        $category->save();
        
        return back()->with('success', __('Category added successfully'));
    }

    public function update(Request $request, $id)
    {
        $category = Subcategory::findOrFail($id);
        $request->validate([
            'name' => 'required|string|max:255|unique:subcategories,name,' . $category->id,
            'slug' => 'required|string|max:255|unique:subcategories,slug,' . $category->id ,
            'status' => 'required|boolean',
        ]);

        $category->name = $request->name;
        $category->slug = $request->slug;
        $category->status = $request->status;
        $category->save();

        return back()->with('success', __('Category updated successfully'));
    }

    public function destory(Request $request)
    {
        $category = Subcategory::findOrFail($request->id);
        $category->delete();
        return back()->with('success', __('Category deleted successfully'));
    }
}
