<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\Attribute;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Gallery;
use App\Models\Product;
use App\Models\ProductAttribute;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{

    public function index()
    {
        $seller = seller();
        $products = $seller->products()->latest()->paginate(10);
        return view('seller.products.index', compact('seller', 'products'));
    }

    public function create()
    {
        $categories = Category::whereUserId(auth()->id())->get();
        $brands = Brand::whereUserId(auth()->id())->get();
        return view('seller.products.create', compact('categories', 'brands'));
    }

    public function store(Request $request)
    {
        if (Product::where('user_id', seller()->id)->count() >= getPackage('product_limit')) {
            return back()->with('error', __('You have reached your product limit'));
        }
        $request->validate([
            'name' => 'required',
            'slug' => 'required|unique:products,slug',
            'current_price' => 'required|numeric|min:1',
            'previus_price' => 'nullable|numeric|min:1',
            'details' => 'required|min:10',
            'category_id' => 'required',
            'photo' => 'required|image|mimes:jpg,jpeg,png',
        ]);

        if ($request->digital) {
            if ($request->file_type == 1) {
                $request->validate([
                    'file' => 'required|mimes:zip,rar',
                ]);
            } else {
                $request->validate([
                    'link' => 'required|url',
                ]);
            }
        }

        $attributes_id = null;
        $variations_id = null;
        if (is_array($request->input('attributes'))) {
            $attributes_id = implode(',', $request->input('attributes'));
        }

        if (is_array($request->variations)) {
            $variations_id = json_encode($request->variations, true);
            $variations = [];

            foreach ($request->variations as $key => $value) {
                foreach ($value as $v) {
                    $variations[] = $v;
                }
            }
            $variations = array_unique($variations);
            $variations = implode(',', $variations);
        }

        if ($request['photo']) {
            $status = MediaHelper::ExtensionValidation($request['photo']);
            if (!$status) {
                return ['errors' => [0 => 'file format not supported']];
            }
            $photo = MediaHelper::sellerHandleMakeImage($request['photo']);
        }

        if ($request['file']) {
            $status = MediaHelper::ExtensionFileValidation($request['file']);
            if (!$status) {
                return ['errors' => [0 => 'file format not supported']];
            }
            $file = MediaHelper::sellerHandleMakeFile($request['file']);
        }

        $tags = tagFormat($request->tags);
        $meta_tag = tagFormat($request->meta_tag);
        $details = clean($request->details);
        $product = new Product();
        $product->user_id = seller()->id;
        $product->name = $request->name;
        $product->slug = Str::slug($request->slug);
        $product->current_price = sellerStoreAmount($request->current_price);
        $product->previous_price = sellerStoreAmount($request->previous_price);

        $product->stock = $request->stock;
        $product->details = $details;
        $product->brand_id = $request->brand_id;
        $product->category_id = $request->category_id;
        $product->subcategory_id = $request->subcategory_id;
        $product->photo = $photo;
        $product->sku = $request->sku;
        $product->type = $request->digital ? 1 : 0;
        $product->file_type = $request->file_type;
        if ($request->digital) {
            if ($request->file_type == 1) {
                $product->file = $file;
            } else {
                $product->link = $request->link;
            }
        }
        $product->tags = $tags;
        $product->meta_tag = $meta_tag;
        $product->meta_content = $request->meta_content;
        $product->status = $request->status;
        $product->save();

        $product_attribute = new ProductAttribute();
        $product_attribute->product_id = $product->id;
        $product_attribute->attribute_id = $attributes_id;
        $product_attribute->variation_id = $variations_id;
        $product_attribute->variations = @$variations ? $variations : null;
        $product_attribute->colors = $request->color ? implode(',', $request->colors) : null;
        $product_attribute->save();
        $base_price = productBasePrice($product, 1);
        $product->base_price = $base_price;
        $product->save();


        if($request->gallery){
            foreach($request->gallery as $gallery){
                $status = MediaHelper::ExtensionValidation($gallery);
                if (!$status) {
                    return ['errors' => [0 => 'file format not supported']];
                }
                $photo = MediaHelper::sellerHandleMakeImage($gallery);
                $product->galleries()->create([
                    'photo' => $photo
                ]);
            }
        }

        cacheRemove('products');

        return redirect()->route('seller.product.index')->with('success', 'Product added successfully');
    }

    public function getVariation(Request $request)
    {
        $attribute = [];
        foreach ($request->attribute_ids as $id) {
            $attribute = Attribute::with('variations')->findOrFail($id);
            $variations = $attribute->variations;
            $datas[] = $variations;
            $attributes[] = $attribute;
        }
        return view('seller.products.inc.variation', compact('datas', 'attributes'));
    }

    public function getSubcategory(Request $request)
    {
        $category = Category::findOrFail($request->category_id);
        $subcategories = $category->subcategories;
        return view('seller.products.inc.subcategory', compact('subcategories'));
    }

    public function edit($id)
    {
        $categories = Category::whereUserId(auth()->id())->get();
        $brands = Brand::whereUserId(auth()->id())->get();
        $product = Product::findOrFail($id);
        $subcategories = $product->category->subcategories;
        return view('seller.products.edit', compact('categories', 'product', 'subcategories', 'brands'));
    }

    public function update(Request $request, $id)
    {
        
        $product = Product::findOrFail($id);

        $request->validate([
            'name' => 'required',
            'slug' => 'required|unique:products,slug,' . $id,
            'current_price' => 'required|numeric|min:1',
            'previus_price' => 'nullable|numeric|min:0',
            'details' => 'required|min:10',
            'category_id' => 'required',
            'photo' => 'nullable|image|mimes:jpg,jpeg,png',
        ]);

        if ($request->digital) {
            if ($request->file_type == 1) {
                $required = $product->file ? 'nullable' : 'required';
                $request->validate([
                    'file' => $required . '|mimes:zip,rar',
                ]);
            } else {
                $request->validate([
                    'link' => 'required|url',
                ]);
            }
        }

        $attributes_id = null;
        $variations_id = null;
        if (is_array($request->input('attributes'))) {
            $attributes_id = implode(',', $request->input('attributes'));
        }

        if (is_array($request->variations)) {
            $variations_id = json_encode($request->variations, true);
            $variations = [];

            foreach ($request->variations as $key => $value) {
                foreach ($value as $v) {
                    $variations[] = $v;
                }
            }
            $variations = array_unique($variations);
            $variations = implode(',', $variations);
        }

        if ($request['photo']) {
            $status = MediaHelper::ExtensionValidation($request['photo']);
            if (!$status) {
                return ['errors' => [0 => 'file format not supported']];
            }
            $photo = MediaHelper::sellerHandleUpdateImage($request['photo'], $product->photo);
        }

        if ($request['file']) {
            $status = MediaHelper::ExtensionFileValidation($request['file']);
            if (!$status) {
                return ['errors' => [0 => 'file format not supported']];
            }
            $file = MediaHelper::sellerHandleUpdateFile($request['file'], $product->file);
        }

        $tags = tagFormat($request->tags);
        $meta_tag = tagFormat($request->meta_tag);
        $details = clean($request->details);

        $product->user_id = seller()->id;
        $product->name = $request->name;
        $product->slug = Str::slug($request->slug);
        $product->current_price = sellerStoreAmount($request->current_price);
        $product->previous_price = sellerStoreAmount($request->previous_price);
        $product->stock = $request->stock;
        $product->details = $details;
        $product->brand_id = $request->brand_id;
        $product->category_id = $request->category_id;
        $product->subcategory_id = $request->subcategory_id;
        if ($request->photo) {
            $product->photo = $photo;
        }
        $product->sku = $request->sku;
        $product->type = $request->digital ? 1 : 0;
        if ($request->digital) {
            if ($request->file_type == 0) {
                $locaion = base_path('../assets/images/' . seller()->id . '/files/');
                if ($product->file && file_exists($locaion . $product->file)) {
                    @unlink($locaion . $product->file);
                }
                $product->file = null;
            }

            $product->link = $request->link;
            if ($request->file) {
                $product->file = $file;
                $product->link = null;
            }
        }
        $product->file_type = $request->file_type;
        $product->status = $request->status;
        $product->tags = $tags;
        $product->meta_tag = $meta_tag;
        $product->meta_content = $request->meta_content;
        $product->update();

        $base_price = productBasePrice($product, 1);
        $product->base_price = $base_price;
        $product->save();

        $product_attribute = ProductAttribute::whereProductId($product->id)->first();
        if ($product_attribute) {
            $product_attribute->product_id = $product->id;
            $product_attribute->attribute_id = $attributes_id;
            $product_attribute->variation_id = $variations_id;
            $product_attribute->variations = @$variations;
            $product_attribute->colors = @implode(',', $request->colors);
            $product_attribute->update();
        } else {
            $product_attribute = new ProductAttribute();
            $product_attribute->product_id = $product->id;
            $product_attribute->attribute_id = $attributes_id;
            $product_attribute->variation_id = $variations_id;
            $product_attribute->variations = @$variations;
            $product_attribute->colors = @implode(',', $request->colors);
            $product_attribute->save();
        }

        if($request->gallery){
            foreach($request->gallery as $gallery){
                $status = MediaHelper::ExtensionValidation($gallery);
                if (!$status) {
                    return ['errors' => [0 => 'file format not supported']];
                }
                $photo = MediaHelper::sellerHandleMakeImage($gallery);
                $product->galleries()->create([
                    'photo' => $photo
                ]);
            }
        }

        cacheRemove('products');
        return redirect()->route('seller.product.index')->with('success', 'Product updated successfully');

    }

    public function highlight(Request $request)
    {
        $product = Product::findOrFail($request->product_id);
        return view('seller.products.highlight', compact('product'));
    }

    public function highlightSubmit(Request $request)
    {
        $product = Product::findOrFail($request->product_id);
        if ($request->new) {
            $product->new = 1;
        } else {
            $product->new = 0;
        }
        if ($request->trending) {
            $product->trending = 1;
        } else {
            $product->trending = 0;
        }
        if ($request->best) {
            $product->best = 1;
        } else {
            $product->best = 0;
        }
        if ($request->featured) {
            $product->featured = 1;
        } else {
            $product->featured = 0;
        }

        $product->update();
        cacheRemove('products');
        return redirect()->route('seller.product.index')->with('success', 'Product highlight updated successfully');

    }

    public function destroy(Request $request)
    {
        $product = Product::findOrFail($request->id);
        $product_attribute = ProductAttribute::whereProductId($product->id)->first();
        if ($product_attribute) {
            $product_attribute->delete();
        }
        $locaion = base_path('../assets/images/' . seller()->id . '/files/');
        if ($product->file && file_exists($locaion . $product->file)) {
            @unlink($locaion . $product->file);
        }
        MediaHelper::sellerhandleDeleteImage($product->photo);
        $product->delete();
        cacheRemove('products');
        return redirect()->route('seller.product.index')->with('success', 'Product deleted successfully');
    }


    public function galleryDelete($id)
    {
        $gallery = Gallery::findOrFail($id);
        MediaHelper::sellerhandleDeleteImage($gallery->photo);
        $gallery->delete();
        return response()->json(['success' => 'Gallery deleted successfully']);
    }

}
