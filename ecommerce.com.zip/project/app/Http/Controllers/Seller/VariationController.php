<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Variation;
use Illuminate\Http\Request;

class VariationController extends Controller
{

    public function index($id)
    {
        $attribute_id = $id;
        $variations = Variation::with('attribute')->where('attribute_id',$id)->orderby('id','desc')->paginate(15);
        return view('seller.products.attributes.variations.index', compact('variations','attribute_id'));
    }

    public function store(Request $request)
    {
        $variations = new Variation();
        $this->storeData($variations, $request);
        return back()->with('success', __('Variation added successfully'));
    }

    public function update(Request $request, $id)
    {
        $variations = Variation::findOrFail($id);
        $this->storeData($variations, $request);
        return back()->with('success', __('Variation updated successfully'));
    }

    public function destory(Request $request)
    {
        $variations = Variation::findOrFail($request->id);
        $variations->delete();
        return back()->with('success', __('Variation deleted successfully'));
    }


    public function storeData($variations,$request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'price' => 'required|numeric',
        ]);
        $variations->name = $request->name;
        $variations->price = $request->price;
        $variations->attribute_id = $request->attribute_id;
        $variations->user_id = auth()->user()->id;
        $variations->save();
    }
}
