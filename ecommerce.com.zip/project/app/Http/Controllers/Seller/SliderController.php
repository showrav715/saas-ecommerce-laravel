<?php

namespace App\Http\Controllers\Seller;
use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\Slider;
use Illuminate\Http\Request;

class SliderController extends Controller
{
    public function index()
    {
        $sliders = Slider::whereUserId(auth()->user()->id)->get();
        return view('seller.slider.index', compact('sliders'));
    }

    public function create()
    {
        return view('seller.slider.create');
    }

    public function store(Request $request)
    {
        $this->storeData($request, new Slider);
        return redirect()->route('seller.slider.index')->with('success', 'Slider created successfully');
    }

    public function edit($id)
    {
        $data = Slider::findOrFail($id);
        return view('seller.slider.edit',compact('data'));
    }

    public function update(Request $request,$id)
    {
        $slider = Slider::findOrFail($id);
        $this->storeData($request, $slider);
        return redirect()->route('seller.slider.index')->with('success', 'Slider updated successfully');
    }

    public function destroy(Request $request)
    {
        $slider = Slider::findOrFail($request->id);
        MediaHelper::sellerhandleDeleteImage($slider->photo);
        $slider->delete();
        cacheRemove('slider');
        return back()->with('success', 'Slider deleted successfully');
        
    }


    public function storeData($request,$data)
    {
        $request->validate([
            'title' => 'required',
            'text' => 'required',
            'photo' => 'mimes:jpg,jpeg,png',
            'btn_text' => 'required',
            'url' => 'required',
            'type' => 'required',
            'status' => 'required',
        ]);

        if($request['photo']){
            $status = MediaHelper::ExtensionValidation($request['photo']);
            if(!$status){
                return ['errors' => [0=>'file format not supported']];
            }
            $data->photo = MediaHelper::sellerHandleMakeImage($request['photo']);
        }

        $data->title = $request->title;
        $data->text = $request->text;
        $data->btn_text = $request->btn_text;
        $data->url = $request->url;
        $data->type = $request->type;
        $data->status = $request->status;
        $data->user_id = auth()->user()->id;
        $data->save();
        cacheRemove('slider');
    }

}
