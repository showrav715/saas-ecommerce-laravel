<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\Request;

class CouponController extends Controller
{

    public function index()
    {
        $coupons = Coupon::orderby('id','desc')->paginate(15);
        return view('seller.coupon.index', compact('coupons'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'code' => 'required|string|max:255|unique:coupons,code',
            'expired' => 'required|date',
            'percentage' => 'required|numeric',
            'status' => 'required|boolean',
        ]);

        $coupon = new Coupon();
        $coupon->code = $request->code;
        $coupon->status = $request->status;
        $coupon->expired = $request->expired;
        $coupon->percentage = $request->percentage;
        $coupon->user_id = seller()->id;
        $coupon->save();
        
        return back()->with('success', __('Coupon added successfully'));
    }

    public function update(Request $request, $id)
    {
        $coupon = Coupon::findOrFail($id);
        $request->validate([
            'code' => 'required|string|max:255|unique:coupons,code,' . $coupon->id,
            'expired' => 'required|date',
            'status' => 'required|boolean',
        ]);
        $coupon->code = $request->code;
        $coupon->status = $request->status;
        $coupon->expired = $request->expired;
        $coupon->percentage = $request->percentage;
        $coupon->user_id = seller()->id;
        $coupon->save();
        return back()->with('success', __('Coupon updated successfully'));
    }

    public function destory(Request $request)
    {
        $coupon = Coupon::findOrFail($request->id);
        $coupon->delete();
        return back()->with('success', __('Coupon deleted successfully'));
    }
}
