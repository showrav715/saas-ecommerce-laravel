<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use App\Models\Color;
use App\Models\ProductAttribute;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ColorController extends Controller
{

    public function index()
    {
        $colors = Color::orderby('id', 'desc')->paginate(15);
        
        return view('seller.products.color.index', compact('colors'));
    }

    public function store(Request $request)
    {
        $this->storeData($request, new Color());
        return back()->with('success', __('Color added successfully'));
    }

    public function update(Request $request, $id)
    {
        $color = Color::findOrFail($id);
        $this->storeData($request, $color, $id);
        return back()->with('success', __('Color updated successfully'));
    }

    public function destory(Request $request)
    {
        $color = Color::findOrFail($request->id);
        $product_attributes = ProductAttribute::whereIn('colors', [$color->id])->get();
        if($product_attributes->count() > 0){
            return back()->with('error', __('This color is used in some products'));
        }
        $color->delete();
        return back()->with('success', __('Color deleted successfully'));
    }

    public function storeData($request, $color, $id = null)
    {
        $request->validate([
            'color_name' => 'required|string|max:255|unique:colors,color_name' . ($id ? ',' . $id : ''),
            'color_code' => 'required|string',
        ]);

        $color->color_name = $request->color_name;
        $color->color_code = $request->color_code;
        $color->user_id = auth()->user()->id;
        $color->color_slug = Str::slug($request->color_name);
        $color->save();
    }
}
