<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    public function index()
    {
        $brands = Brand::orderby('id','desc')->paginate(15);
        return view('seller.brand.index',compact('brands'));
    }

    public function store(Request $request)
    {

        if(Brand::where('user_id',seller()->id)->count() >= getPackage('brand_limit')){
            return back()->with('error', __('You have reached your brand limit'));
        }

        $request->validate([
            'name' => 'required|string|max:255|unique:brands,name',
            'status' => 'required|boolean',
        ]);

        $brand = new Brand();
        $brand->name = $request->name;
        $brand->status = $request->status;
        $brand->user_id = seller()->id;
        $brand->save();
        
        return back()->with('success', __('Brand added successfully'));
    }

    public function update(Request $request, $id)
    {
        $brand = Brand::findOrFail($id);
        $request->validate([
            'name' => 'required|string|max:255|unique:brands,name,' . $brand->id,
            'status' => 'required|boolean',
        ]);
        $brand->name = $request->name;
        $brand->status = $request->status;
        $brand->save();
        return back()->with('success', __('Brand updated successfully'));
    }

    public function destory(Request $request)
    {
        $brand = Brand::findOrFail($request->id);
        $brand->delete();
        return back()->with('success', __('Brand deleted successfully'));
    }


}
