<?php

namespace App\Http\Controllers\SellerUser;

use App\Http\Controllers\Controller;
use App\Http\Helpers\MediaHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{

    public function index()
    {
        $user = Auth::user();
        $orders = auth()->user()->orders()->orderBy('id', 'DESC')->take(5)->get();
        $total_order_count = auth()->user()->orders()->count();
        $total_pending_order_count = auth()->user()->orders()->where('order_status', 0)->count();
        return view('sellerUser.dashboard', compact('user', 'orders','total_order_count','total_pending_order_count'));
    }

    public function profile()
    {
        $user = Auth::user();
        return view('sellerUser.profile', compact('user'));
    }

    public function profileUpdate(Request $request)
    {
        $request->validate([
            'photo' => 'mimes:jpeg,jpg,png,svg',
            'email' => 'unique:users,email,' . Auth::id(),
        ]);

        $input = $request->all();
        $data = Auth::user();
        if ($request->file('photo')) {
            $name = MediaHelper::sellerHandleUpdateImage($request['photo'], $data->photo);
            $input['photo'] = $name;
        }
        $data->update($input);
        return back()->with('success', 'Profile Updated Successfully!');
    }

    public function reset()
    {
        return view('sellerUser.reset_password');
    }

    public function resetSubmit(Request $request)
    {
        $request->validate([
            'cpass' => 'required',
            'newpass' => 'required|min:4',
            'renewpass' => 'required|same:newpass',
        ]);
        $user = Auth::user();
        if ($request->cpass) {
            if (Hash::check($request->cpass, $user->password)) {
                if ($request->newpass == $request->renewpass) {
                    $input['password'] = Hash::make($request->newpass);
                } else {
                    return back()->with('error', 'New Password and Re-type New Password does not match');
                }
            } else {
                return back()->with('error', 'Current Password does not match');
            }
        }
        $user->update($input);
        return back()->with('success', 'Password Changed Successfully');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('seller.front.index');
    }

}
