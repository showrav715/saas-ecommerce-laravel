<?php

namespace App\Http\Controllers\SellerUser;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    
    public function index()
    {
        $orders = auth()->user()->orders()->orderBy('id', 'DESC')->paginate(10);
        return view('sellerUser.order.index', compact('orders'));
    }


    public function orderDetails($id)
    {
        $order = auth()->user()->orders()->where('id', $id)->first();
        return view('sellerUser.order.details', compact('order'));
    }

    public function print($id)
    {
        $order = auth()->user()->orders()->where('id', $id)->first();
        return view('sellerUser.order.print', compact('order'));
    }

}
