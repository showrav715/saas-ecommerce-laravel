<?php

namespace App\Http\Controllers\SellerUser;

use Illuminate\Http\Request;
use App\{
    Models\Product,
    Models\Wishlist
};
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class WishlistController extends Controller
{

    public function wishlists(Request $request)
    {
     
        $sort = '';
        $pageby = $request->pageby;
        $user = Auth::user();
        $wishes = Wishlist::where('user_id','=',$user->id)->pluck('product_id');
       
        if(!empty($request->sort))
        {
            $sort = $request->sort;
            if($sort == "id_desc")
            {
            $wishlists = Product::where('status','=',1)->whereIn('id',$wishes)->latest('id');
            }
            else if($sort == "id_asc")
            {
            $wishlists = Product::where('status','=',1)->whereIn('id',$wishes);
            }
            else if($sort == "price_asc")
            {
            $wishlists = Product::where('status','=',1)->whereIn('id',$wishes)->oldest('price');
            }
            else if($sort == "price_desc")
            {
            $wishlists = Product::where('status','=',1)->whereIn('id',$wishes)->latest('price');
            }
            if($request->ajax())
            {
                return view('sellerUser.inc.wishlist',compact('user','wishlists','sort','pageby'));
            }
            return view('sellerUser.wishlist',compact('user','wishlists','sort','pageby'));
        }

        $wishlists = Product::where('status','=',1)->whereIn('id',$wishes)->latest('id')->get();
        if($request->ajax())
        {
            return view('sellerUser.inc.wishlist',compact('user','wishlists','sort','pageby'));
        }
       
        return view('sellerUser.wishlist',compact('user','wishlists','sort','pageby'));
    }

    public function addwish($id)
    {
        $user = Auth::user();
        try {
        $ck = Wishlist::where('user_id','=',$user->id)->where('product_id','=',$id)->get()->count();
        if($ck > 0)
        {
            $data['error'] = __('Already Added To The Wishlist.');
            return response()->json($data);
        }
        $wish = new Wishlist();
        $wish->user_id = $user->id;
        $wish->product_id = $id;
        $wish->save();
        return response()->json(['success'=> __('Successfully Added To The Wishlist.')]);
        } catch (\Exception $e) {
            return response()->json(['error'=> __('Something Went Wrong.')]);
        }

    }

    public function removewish($id)
    {
        
        $wish = Wishlist::whereProductId($id)->first();
        $wish->delete();
        return back()->with('success',__('Successfully Removed From The Wishlist.'));
      

    }

}
