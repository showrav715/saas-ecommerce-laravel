<?php

namespace App\Http\Controllers\SellerUser;

use App\Http\Controllers\Controller;
use App\Http\Helpers\EmailHelper;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{

    public function login()
    {
        // if(url()->previous() != route('seller.user.login') && url()->previous() != route('seller.user.register'))
        //     session()->put('url.__intended', url()->previous()
        // );

        return view('sellerUser.login');
    }

    public function loginSubmit(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $check = Auth::attempt(['email' => $request->email, 'password' => $request->password]);
        if ($check) {
            if (session()->has('redirect_url')) {
                return redirect(Session::get('redirect_url'));
            }
            return redirect()->route('seller.user.dashboard');
        } else {
            return redirect()->back()->with('error', 'Invalid Credentials');
        }
    }

    public function register()
    {
        return view('sellerUser.register');
    }

    public function registerSubmit(Request $request)
    {
        if (User::where('owner_id', sellerId())->count() >= getPackage('customer_id')) {
            return back()->with('error', __('Owner has reached his customer limit'));
        }

        $request->validate([
            'name' => 'required|max:55',
            'email' => 'required|unique:users|max:155',
            'phone' => 'required|max:55',
            'password' => 'required|min:4',
            'password_confirmation' => 'required|same:password',
        ]);

        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->password = Hash::make($request->password);
        $user->role = 'user';
        $user->owner_id = getUser('user_id');
        $code = rand(100000, 999999);
        $user->verify_code = $code;
        $user->save();
        $link = route('seller.user.verify.email', $code);

        $data = [
            'name' => $user->name,
            'email' => $user->email,
            'subject' => 'Verify Your Email Address',
            'body' => 'Please click the link to verify your email address. <a href="' . $link . '">Verify Now</a>',
        ];

        $mailData = new EmailHelper();
        $mailData->customMail($data);
        return redirect()->back()->with('success', 'Please check your email for verification code');

    }

    public function verifyEmail($code)
    {
        $user = User::where('verify_code', $code)->first();
        if ($user) {
            $user->email_verified = 1;
            $user->verify_code = null;
            $user->save();
            return redirect()->route('seller.user.login')->with('success', 'Your email has been verified successfully');
        } else {
            return redirect()->route('seller.user.login')->with('error', 'Invalid verification code');
        }
    }

    public function forgotPassword()
    {
        return view('sellerUser.forgot');
    }

    public function forgotPasswordSubmit(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $user = User::where('email', $request->email)->first();
        if ($user) {
            $code = rand(100000, 999999);
            $user->verify_code = $code;
            $user->save();
            $link = route('seller.user.reset.password', $code);
            $data = [
                'name' => $user->name,
                'email' => $user->email,
                'subject' => 'Forgot Your Password',
                'body' => 'Please click the link to reset your password. <a href="' . $link . '">Reset Now</a>',
            ];

            $mailData = new EmailHelper();
            $mailData->customMail($data);
            return redirect()->back()->with('success', 'Please check your email for reset password link');
        } else {
            return redirect()->back()->with('error', 'Invalid email address');
        }
    }

    public function resetPassword($code)
    {
        $user = User::where('verify_code', $code)->first();
        if ($user) {
            return view('sellerUser.forgot_reset', compact('code'));
        } else {
            return redirect()->route('seller.user.login')->with('error', 'Invalid verification code');
        }
    }

    public function resetPasswordSubmit(Request $request)
    {
        $request->validate([
            'password' => 'required|min:4',
            'password_confirmation' => 'required|same:password',
        ]);

        $user = User::where('verify_code', $request->code)->first();
        if ($user) {
            $user->password = Hash::make($request->password);
            $user->verify_code = null;
            $user->save();
            return redirect()->route('seller.user.login')->with('success', 'Your password has been reset successfully');
        } else {
            return redirect()->route('seller.user.login')->with('error', 'Invalid verification code');
        }

    }

}
