<?php

namespace App\Http\Controllers\LandingPayment;

use App\Http\Controllers\Controller;
use App\Models\Domain;
use App\Models\Package;
use App\Models\PaymentGateway;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use PayPal\Api\Amount;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;

class PaypalController extends Controller
{

    public $_api_context;
    public $support_currencies;
    public function __construct()
    {
        $data = PaymentGateway::whereKeyword('paypal')->first();
        $this->support_currencies = $data->currency_id ?? [];
        $paydata = $data->convertAutoData();
        $paypal_conf = Config::get('paypal');
        $paypal_conf['client_id'] = $paydata['client_id'];
        $paypal_conf['secret'] = $paydata['client_secret'];
        $paypal_conf['settings']['mode'] = $paydata['sandbox_check'] == 1 ? 'sandbox' : 'live';

        $this->_api_context = new ApiContext(new OAuthTokenCredential(
            $paypal_conf['client_id'],
            $paypal_conf['secret'])
        );

        $this->_api_context->setConfig($paypal_conf['settings']);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6|confirmed',
            'domain' => 'regex:/^[a-zA-Z0-9]+$/u|required',
        ]);

        $main_domain = env('MAIN_DOMAIN');
        $domain = $request->domain;
        $final = $domain . '.' . $main_domain;
        $domain_exists = Domain::where('domain', $final)->first();
        if ($domain_exists) {
            return back()->with('error', __('Domain already exists.'));
        }

        if (landingCheckCurrency($this->support_currencies) == false) {
            return back()->with('error', __('This gateway does not support your currency.'));
        }

        $notify_url = route('landing.paypal.notify');
        $cancel_url = url()->previous();

        $package = Package::findOrFail($request->package_id);

        $payer = new Payer();
        $payer->setPaymentMethod('paypal');
        $item_1 = new Item();
        $item_1->setName($package->name)
            ->setCurrency(landingCurrency()->code)
            ->setQuantity(1)
            ->setPrice(landingShowAmount($package->price, true));
        $item_list = new ItemList();
        $item_list->setItems(array($item_1));
        $amount = new Amount();
        $amount->setCurrency(landingCurrency()->code)
            ->setTotal(landingShowAmount($package->price, true));
        $transaction = new Transaction();
        $transaction->setAmount($amount)
            ->setItemList($item_list)
            ->setDescription($package->name);
        $redirect_urls = new RedirectUrls();
        $redirect_urls->setReturnUrl($notify_url)
            ->setCancelUrl($cancel_url);
        $payment = new Payment();
        $payment->setIntent('Sale')
            ->setPayer($payer)
            ->setRedirectUrls($redirect_urls)
            ->setTransactions(array($transaction));

        try {
            $payment->create($this->_api_context);
        } catch (Exception $ex) {
            return redirect()->back()->with('unsuccess', $ex->getMessage());
        }
        foreach ($payment->getLinks() as $link) {
            if ($link->getRel() == 'approval_url') {
                $redirect_url = $link->getHref();
                break;
            }
        }

        Session::put('input_data', $request->all());
        Session::put('paypal_payment_id', $payment->getId());
        if (isset($redirect_url)) {
            return redirect($redirect_url);
        }
        return redirect()->back()->with('unsuccess', __('Unknown error occurred'));
    }

    public function notify(Request $request)
    {
        $input = $request->all();
        $inputData = Session::get('input_data');
        $payment_id = Session::get('paypal_payment_id');

        if (empty($input['PayerID']) || empty($input['token'])) {
            return redirect()->back()->with('error', __('Payment failed'));
        }
        $payment = Payment::get($payment_id, $this->_api_context);
        $execution = new PaymentExecution();
        $execution->setPayerId($request['PayerID']);
        $result = $payment->execute($execution, $this->_api_context);
        if ($result->getState() == 'approved') {
            $resp = json_decode($payment, true);
            $subscription = createStore($inputData, $resp['transactions'][0]['related_resources'][0]['sale']['id'], 'Paypal', 1);
            if ($subscription) {
                return redirect()->route('landing.login')->with('success', __('Registration successful. Please login to continue.'));
            } else {
                return back()->with('error', __('Something is wrong.'));
            }
        } else {
            return redirect()->back()->with('error', __('Payment failed'));
        }

    }
}
