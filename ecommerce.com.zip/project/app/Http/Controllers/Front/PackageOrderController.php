<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\PaymentGateway;
use Illuminate\Http\Request;

class PackageOrderController extends Controller
{
    public function packageOrder(Request $request)
    {
        dd($request->all());
    }

    public function getForm($keyword)
    {
        $gateway = PaymentGateway::where('keyword',$keyword)->first();
        return view('front.payment_form',compact('gateway'));
    }
}
