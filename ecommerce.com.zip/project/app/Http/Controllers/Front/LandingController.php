<?php
namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\BlogCategory;
use App\Models\Package;
use App\Models\Page;
use App\Models\PaymentGateway;
use App\Models\Service;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class LandingController extends Controller
{

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (!Session::has('popup')) {
                view()->share('visited', 1);
            }
            Session::put('popup', 1);
            return $next($request);
        });
    }

    public function index(Request $request)
    {
        $services = Service::where('status', 1)->orderBy('id', 'desc')->get();
        $blogs = Blog::with('category')->where('status', 1)->take(3)->orderBy('id', 'desc')->get();
        $testimonails = Testimonial::orderBy('id', 'desc')->get();
        $packages = Package::whereIsFeatured(1)->where('status', 1)->orderBy('id', 'desc')->get();
        return view('front.index', compact('services', 'testimonails', 'blogs', 'packages'));
    }

    public function contact()
    {
        return view('front.contact');
    }

    public function blogs()
    {
        $blogs = Blog::with('category')->where('status', 1)->orderBy('id', 'desc')->paginate(10);
        return view('front.blogs', compact('blogs'));
    }

    public function blogShow($slug)
    {
        $blog = Blog::where('slug', $slug)->first();
        $categories = BlogCategory::withCount('blogs')->where('status', 1)->get();
        $latetes = Blog::where('status', 1)->where('slug', '!=', $slug)->orderBy('id', 'desc')->limit(5)->get();
        return view('front.blog_details', compact('blog', 'latetes', 'categories'));
    }

    public function page($slug)
    {
        $page = Page::where('slug', $slug)->first();
        return view('front.page', compact('page'));
    }

    public function pricing()
    {
        $packages = Package::where('status', 1)->orderBy('id', 'desc')->get();
        return view('front.pricing', compact('packages'));
    }

    public function pricing_order($id)
    {
        $gateways = PaymentGateway::where('status', 1)->get();
        $gatewaye = PaymentGateway::where('keyword', 'paystack')->first();
        $paystackData = json_decode($gatewaye->information, true);
        $package = Package::findOrFail($id);
        return view('front.pricing_order', compact('package', 'gateways', 'paystackData'));
    }

    public function currencySetup(Request $request)
    {
        session()->put('landing_currency', $request->currency_id);
        return back();
    }

    public function login()
    {
        return view('front.login');
    }
    public function loginSubmit(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        $credentials = $request->only('email', 'password');
        if (auth()->guard('web')->attempt($credentials)) {
            $domain = auth()->guard('web')->user()->domain;
            $user = auth()->guard('web')->user();
            $user->force_login = 1;
            $user->save();
            if (request()->secure()) {
                return redirect('https://' . $domain->domain . '/seller');
            } else {
                return redirect('http://' . $domain->domain . '/seller');
            }
        }

    }

}
