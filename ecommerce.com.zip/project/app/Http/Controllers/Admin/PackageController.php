<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Package;
use Illuminate\Http\Request;

class PackageController extends Controller
{

    public function index()
    {
        $packages = Package::orderby('id', 'desc')->paginate(15);
        return view('admin.package.index', compact('packages'));
    }

    public function create()
    {
        return view('admin.package.create');
    }

    public function store(Request $request)
    {
        $this->validation($request);
        $package = new Package();
        $this->saveData($package, $request);
        return back()->with('success', __('Package added successfully'));
    }

    public function edit($id)
    {
        $data = Package::findOrFail($id);
        return view('admin.package.edit', compact('data'));
    }

    public function update(Request $request, $id)
    {
        $this->validation($request, $id);
        $package = Package::findOrFail($id);
        $this->saveData($package, $request);
        return back()->with('success', __('Package updated successfully'));
    }

    public function destory(Request $request)
    {
        $package = Package::findOrFail($request->id);
        $package->delete();
        return back()->with('success', __('Package deleted successfully'));
    }

    // both validation
    public function validation($request, $id = null)
    {
        return $request->validate([
            'name' => 'required|string|max:255|unique:packages,name,' . $id,
            'description' => 'required',
            'price' => 'required',
            'days' => 'required',
            'category_limit' => 'required',
            'product_limit' => 'required',
            'customer_limit' => 'required',
            'brand_limit' => 'required',
            'variant_limit' => 'required',
            'custom_domain' => 'required',
            'customer_panel_access' => 'required',
            'support' => 'required',
            'qr_code' => 'required',
            'facebook_pixel' => 'required',
            'google_analytics' => 'required',
            'is_featured' => 'required',
            'status' => 'required',
        ]);
    }

    public function saveData($package, $request)
    {
        $package->name = $request->name;
        $package->description = $request->description;
        $package->price = $request->price;
        $package->days = $request->days;
        $package->category_limit = $request->category_limit;
        $package->product_limit = $request->product_limit;
        $package->customer_limit = $request->customer_limit;
        $package->brand_limit = $request->brand_limit;
        $package->variant_limit = $request->variant_limit;
        $package->custom_domain = $request->custom_domain;
        $package->customer_panel_access = $request->customer_panel_access;
        $package->support = $request->support;
        $package->qr_code = $request->qr_code;
        $package->facebook_pixel = $request->facebook_pixel;
        $package->google_analytics = $request->google_analytics;
        $package->is_featured = $request->is_featured;
        $package->status = $request->status;
        $package->save();
    }

}
