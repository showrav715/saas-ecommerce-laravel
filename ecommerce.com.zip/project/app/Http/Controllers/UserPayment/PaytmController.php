<?php

namespace App\Http\Controllers\UserPayment;

use App\Http\{
    Traits\Paytm,
	
};
use App\Http\Controllers\Controller;
use App\Models\Package;
use App\Models\UserPaymentGateway;
use Illuminate\{
	Http\Request,
};
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class PaytmController extends Controller
{

    use Paytm;
    public function store(Request $request)
    {

        checkoutValidate($request);

       $data = UserPaymentGateway::whereKeyword('paytm')->first();
       $support_currencies = $data->currency_id ? explode(',', $data->currency_id) : [];
       if (sellerCheckCurrency($support_currencies) == false) {
           return back()->with('error', __('This gateway does not support your currency.'));
       }
        $process = checkoutProcess($request);
       
	    $data_for_request = $this->handlePaytmRequest( Str::random(9), sellerConvertAmount($process['item_amount']), 'checkout','user' );
	    $paytm_txn_url = 'https://securegw-stage.paytm.in/theia/processTransaction';
	    $paramList = $data_for_request['paramList'];
	    $checkSum = $data_for_request['checkSum'];
        Session::put('input_data', $request->all());
	    return view( 'sellerFront.paytm-merchant-form', compact( 'paytm_txn_url', 'paramList', 'checkSum' ) );
    }


	public function paytmCallback( Request $request ) {

        $inputData = Session::get('input_data');

		if ( 'TXN_SUCCESS' === $request['STATUS'] ) {
			$transaction_id = $request['TXNID'];
            $process = checkoutProcess($inputData,'paytm');
            $order = createOrder($inputData, $process, ['txn' => $transaction_id, 'payment_method' => 'Paytm', 'payment_status' => 1, 'method' => 'paytm']);
            return redirect()->route('seller.front.cart.index')->with('success', __('Order successfully. Your order number is ') . $order->order_number);

		} else if( 'TXN_FAILURE' === $request['STATUS'] ){
            return redirect()->route('seller.front.cart.index')->with('error', __('Payment failed.'));
		}
    }
}