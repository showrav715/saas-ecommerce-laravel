<?php

namespace App\Http\Controllers\UserPayment;

use App\Http\Controllers\Controller;
use App\Models\UserPaymentGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;

class AuthorizeController extends Controller
{
    public function store(Request $request)
    {
        //dd($request->all());
       //dd('authorize');
        $data = UserPaymentGateway::whereKeyword('authorize')->first();
        $paydata = $data->convertAutoData();
        $support_currencies = $data->currency_id ? explode(',', $data->currency_id) : [];
        if (sellerCheckCurrency($support_currencies) == false) {
            return back()->with('error', __('This gateway does not support your currency.'));
        }
            checkoutValidate($request);
            $validator = Validator::make($request->all(),[
                'card' => 'required',
                'cvc' => 'required',
                'month' => 'required',
                'year' => 'required',
            ]);

            if (!$validator->passes()) {
                return redirect()->route('seller.front.checkout.index')->with('error', 'Payment Unsuccessful');
            }

            $process = checkoutProcess($request);
            
            $paydata = $data->convertAutoData();
            $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
            $merchantAuthentication->setName($paydata['login_id']);
            $merchantAuthentication->setTransactionKey($paydata['txn_key']);

            // Set the transaction's refId
            $refId = 'ref' . time();

            // Create the payment data for a credit card
            $creditCard = new AnetAPI\CreditCardType();
            $creditCard->setCardNumber(str_replace(' ', '', $request->card));
            $year = $request->year;
            $month = $request->month;
            $creditCard->setExpirationDate($year.'-'.$month);
            $creditCard->setCardCode($request->cvc);

            // Add the payment data to a paymentType object
            $paymentOne = new AnetAPI\PaymentType();
            $paymentOne->setCreditCard($creditCard);
        
            // Create order information
            $order = new AnetAPI\OrderType();
            $order->setInvoiceNumber($process['item_number']);
            $order->setDescription($process['item_name']);

            // Create a TransactionRequestType object and add the previous objects to it
            $transactionRequestType = new AnetAPI\TransactionRequestType();
            $transactionRequestType->setTransactionType("authCaptureTransaction"); 
            $transactionRequestType->setAmount(sellerConvertAmount($process['item_amount']));
            $transactionRequestType->setOrder($order);
            $transactionRequestType->setPayment($paymentOne);
            // Assemble the complete transaction request
            $requestt = new AnetAPI\CreateTransactionRequest();
            $requestt->setMerchantAuthentication($merchantAuthentication);
            $requestt->setRefId($refId);
            $requestt->setTransactionRequest($transactionRequestType);
        
            // Create the controller and get the response
            $controller = new AnetController\CreateTransactionController($requestt);
            if($paydata['sandbox_check'] == 1){
                $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
            }
            else {
                $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::PRODUCTION);                
            }
        

            if ($response != null) {
                // Check to see if the API request was successfully received and acted upon
                if ($response->getMessages()->getResultCode() == "Ok") {
                    $tresponse = $response->getTransactionResponse();
                
                    if ($tresponse != null && $tresponse->getMessages() != null) {
                        // $tresponse->getTransId();
                        $order = createOrder($request, $process, ['txn' => $tresponse->getTransId(), 'payment_method' => 'Authorize.net', 'payment_status' => 1, 'method' => 'paytm']);
                        return redirect()->route('seller.front.cart.index')->with('success', __('Order successfully. Your order number is ') . $order->order_number);

                    } else {
                        return back()->with('unsuccess', __('Payment Failed.'));
                    }
                    // Or, print errors if the API request wasn't successful
                } else {
                    return back()->with('unsuccess', __('Payment Failed.'));
                }      
            } else {
                return back()->with('unsuccess', __('Payment Failed.'));
            }


    }
}
