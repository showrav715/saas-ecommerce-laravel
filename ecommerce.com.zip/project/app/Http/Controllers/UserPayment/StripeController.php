<?php

namespace App\Http\Controllers\UserPayment;

use App\Http\Controllers\Controller;
use App\Models\UserPaymentGateway;
use Cartalyst\Stripe\Laravel\Facades\Stripe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class StripeController extends Controller
{
    public $support_currencies;
    public $seller;
    public function __construct()
    {
        $this->seller = getUser('user_id');
        $data = UserPaymentGateway::whereKeyword('stripe')->first();
        $this->support_currencies = $data->currency_id ? explode(',', $data->currency_id) : [];
        $paydata = $data->convertAutoData();
        Config::set('services.stripe.key', $paydata['key']);
        Config::set('services.stripe.secret', $paydata['secret']);
    }

    public function store(Request $request)
    {
        
        if (sellerCheckCurrency($this->support_currencies) == false) {
            return back()->with('error', __('This gateway does not support your currency.'));
        }
        checkoutValidate($request);

        if (!Session::has('cart' . $this->seller)) {
            return redirect()->route('seller.front.cart.index');
        }

        $validator = Validator::make($request->all(), [
            'card' => 'required|',
            'month' => 'required',
            'year' => 'required',
            'cvc' => 'required',
        ]);

        if ($validator->passes()) {
            $stripe = Stripe::make(Config::get('services.stripe.secret'));
            try {
                $process = checkoutProcess($request);
                $input = $request->all();
                $token = $stripe->tokens()->create([
                    'card' => [
                        'number' => $input['card'],
                        'exp_month' => $input['month'],
                        'exp_year' => $input['year'],
                        'cvc' => $input['cvc'],
                    ],
                ]);

                if (!isset($token['id'])) {
                    return back()->with('error', __('Token Problem With Your Token.'));
                }

                $charge = $stripe->charges()->create([
                    'card' => $token['id'],
                    'currency' => sellerCurrencyCode(),
                    'amount' =>  sellerConvertAmount($process['item_amount']),
                    'description' => $process['item_name'],
                ]);

                if ($charge['status'] == 'succeeded') {
                    try {
                        $order = createOrder($request, $process, ['txn' => $charge['balance_transaction'], 'payment_method' => 'Stripe','payment_status' => 1]);
                        return redirect()->route('seller.front.cart.index')->with('success', __('Payment successfully. Your order number is ') . $order->order_number);
                    } catch (Exception $e) {
                        return back()->with('error', $e->getMessage());
                    }

                }

            } catch (Exception $e) {
                return back()->with('error', $e->getMessage());
            } catch (\Cartalyst\Stripe\Exception\CardErrorException $e) {
                return back()->with('error', $e->getMessage());
            } catch (\Cartalyst\Stripe\Exception\MissingParameterException $e) {
                return back()->with('error', $e->getMessage());
            }
        } else {
            return response()->json(['error' => $validator->errors()->all()]);
        }

    }
}
