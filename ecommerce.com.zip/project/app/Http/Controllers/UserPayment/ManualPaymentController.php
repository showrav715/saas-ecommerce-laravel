<?php
namespace App\Http\Controllers\UserPayment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ManualPaymentController extends Controller {
    public function store(Request $request)
    {
      
        checkoutValidate($request);

        if (!Session::has('cart' . sellerId())) {
            return redirect()->route('seller.front.cart.index');
        }
        $process = checkoutProcess($request);
        try {
            $order = createOrder($request, $process, ['txn' => $request->transaction_id, 'payment_method' => $request->payment_method,'payment_status' => 0]);
            return redirect()->route('seller.front.cart.index')->with('success', __('Order successfully. Your order number is ') . $order->order_number);
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    
}