<?php

namespace App\Http\Controllers\UserPayment;

use App\Http\Controllers\Controller;
use App\Models\UserPaymentGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use PayPal\Api\Amount;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;

class PaypalController extends Controller
{

    private $_api_context;
    public $support_currencies;
    public function __construct()
    {
        
        $data = UserPaymentGateway::whereKeyword('paypal')->first();
        $this->support_currencies =$data->currency_id ? explode(',', $data->currency_id) : [];
        $paydata = $data->convertAutoData();
        $paypal_conf = Config::get('paypal');
        $paypal_conf['client_id'] = $paydata['client_id'];
        $paypal_conf['secret'] = $paydata['client_secret'];
        $paypal_conf['settings']['mode'] = $paydata['sandbox_check'] == 1 ? 'sandbox' : 'live';

        $this->_api_context = new ApiContext(new OAuthTokenCredential(
            $paypal_conf['client_id'],
            $paypal_conf['secret'])
        );

        $this->_api_context->setConfig($paypal_conf['settings']);
    }

    public function store(Request $request)
    {
        if (sellerCheckCurrency($this->support_currencies) == false) {
            return back()->with('error', __('This gateway does not support your currency.'));
        }
        checkoutValidate($request);

        $notify_url = route('seller.front.paypal.notify');
        $cancel_url = route('seller.front.checkout.index');
        $process = checkoutProcess($request);

        $payer = new Payer();
        $payer->setPaymentMethod('paypal');
        $item_1 = new Item();
        $item_1->setName($process['item_name'])
            ->setCurrency(sellerCurrencyCode())
            ->setQuantity(1)
            ->setPrice( sellerConvertAmount($process['item_amount']));
        $item_list = new ItemList();
        $item_list->setItems(array($item_1));
        $amount = new Amount();
        $amount->setCurrency(sellerCurrencyCode())
            ->setTotal( sellerConvertAmount($process['item_amount']));
        $transaction = new Transaction();
        $transaction->setAmount($amount)
            ->setItemList($item_list)
            ->setDescription($process['item_name']);
        $redirect_urls = new RedirectUrls();
        $redirect_urls->setReturnUrl($notify_url)
            ->setCancelUrl($cancel_url);
        $payment = new Payment();
        $payment->setIntent('Sale')
            ->setPayer($payer)
            ->setRedirectUrls($redirect_urls)
            ->setTransactions(array($transaction));

        try {
            $payment->create($this->_api_context);
        } catch (\PayPal\Exception\PPConnectionException $ex) {
            return redirect()->back()->with('unsuccess', $ex->getMessage());
        }
        foreach ($payment->getLinks() as $link) {
            if ($link->getRel() == 'approval_url') {
                $redirect_url = $link->getHref();
                break;
            }
        }

        Session::put('input_data', $request->all());
        Session::put('paypal_payment_id', $payment->getId());
        if (isset($redirect_url)) {
            return redirect($redirect_url);
        }
        return redirect()->back()->with('unsuccess', __('Unknown error occurred'));
    }

    public function notify(Request $request)
    {
        $input = $request->all();
        $inputData = Session::get('input_data');
        $payment_id = Session::get('paypal_payment_id');

        if (empty($input['PayerID']) || empty($input['token'])) {
            return redirect()->route('seller.front.checkout.index')->with('error', __('Payment failed'));
        }
        $payment = Payment::get($payment_id, $this->_api_context);
        $execution = new PaymentExecution();
        $execution->setPayerId($request['PayerID']);
        $result = $payment->execute($execution, $this->_api_context);
        if ($result->getState() == 'approved') {
            $resp = json_decode($payment, true);
            $process = checkoutProcess($inputData,'paypal');
            $order = createOrder($inputData, $process, ['txn' => $resp['transactions'][0]['related_resources'][0]['sale']['id'], 'payment_method' => 'Paypal', 'payment_status' => 1, 'method' => 'paypal']);
            return redirect()->route('seller.front.cart.index')->with('success', __('Order successfully. Your order number is ') . $order->order_number);

        } else {
            return redirect()->route('seller.front.checkout.index')->with('error', __('Payment failed'));
        }

    }
}
