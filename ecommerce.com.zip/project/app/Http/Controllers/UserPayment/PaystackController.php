<?php

namespace App\Http\Controllers\UserPayment;

use App\Http\Controllers\Controller;
use App\Models\UserPaymentGateway;
use Illuminate\Http\Request;

class PaystackController extends Controller
{

    public function store(Request $request)
    {
        $data = UserPaymentGateway::whereKeyword('paystack')->first();
        $support_currencies = $data->currency_id ? explode(',', $data->currency_id) : [];
        if (sellerCheckCurrency($support_currencies) == false) {
            return back()->with('error', __('This gateway does not support your currency.'));
        }
        if($request->ref_id == null){
            return redirect()->back()->with('error', 'Payment failed');
        }
        $process = checkoutProcess($request);
        
        $order = createOrder($request, $process, ['txn' => $request->ref_id, 'payment_method' => 'Paystack','payment_status' => 1]);
        
        if($order){
            return redirect()->route('seller.front.cart.index')->with('success', __('Payment successfully. Your order number is ') . $order->order_number);
        }else{
             return back()->with('error', __('Something is wrong.'));
        }

    }

}
