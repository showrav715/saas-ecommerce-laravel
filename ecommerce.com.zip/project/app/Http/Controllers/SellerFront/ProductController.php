<?php

namespace App\Http\Controllers\SellerFront;

use App\Http\Controllers\Controller;
use App\Models\Attribute;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Color;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\Review;
use App\Models\Subcategory;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->seller = getUser('user_id');
    }

    public function index(Request $request)
    {

        $category = $request->has('category') ? Category::where('slug', $request->category)->first() : null;
        $subcategory = $request->has('subcategory') ? Subcategory::where('slug', $request->subcategory)->first() : null;
        $brand = $request->has('brand') ? Brand::where('id', $request->brand)->first() : null;
        $sort = $request->has('sort') ? $request->sort : 'latest';
        $pagination = $request->has('pagination') ? $request->pagination : 9;
        $search = $request->has('search') ? $request->search : null;
        $color = $request->has('color') && $request->color ? ProductAttribute::where('colors', 'like', '%' . $request->color . '%')->get(['product_id'])->toArray() : null;
        $attributes = $request->has('attribute') && $request->attribute ? $request->attribute : null;

        $varations = [];
        if ($attributes) {
            $attributes = explode(',', $attributes);
            foreach ($attributes as $attribute) {
                $varations[] = explode('_', $attribute)[1];
            }
        }

        $varations = implode(',', $varations);
        if ($varations) {
            $varations = ProductAttribute::where('variations', 'like', '%' . $varations . '%')->get(['product_id'])->toArray();
        }

        $products = Product::withCount('reviews')->with('category')->where('user_id', $this->seller)
            ->when($category, function ($query) use ($category) {
                return $query->where('category_id', $category->id);
            })
            ->when($subcategory, function ($query) use ($subcategory) {
                return $query->where('subcategory_id', $subcategory->id);
            })
            ->when($brand, function ($query) use ($brand) {
                return $query->where('brand_id', $brand->id);
            })

            ->when($color, function ($query) use ($color) {
                return $query->whereIn('id', $color);
            })
            ->when($varations, function ($query) use ($varations) {

                return $query->whereIn('id', $varations);
            })

            ->when($search, function ($query) use ($search) {
                return $query->where('name', 'like', '%' . $search . '%');
            })
            ->when($sort, function ($query) use ($sort) {
                if ($sort == 'latest') {
                    return $query->orderBy('id', 'desc');
                } elseif ($sort == 'Oldest') {
                    return $query->orderBy('id', 'asc');
                } elseif ($sort == 'low_to_high') {
                    return $query->orderBy('base_price', 'asc');
                } elseif ($sort == 'high_to_low') {
                    return $query->orderBy('base_price', 'desc');
                } elseif ($sort == 'name_a_z') {
                    return $query->orderBy('name', 'asc');
                } elseif ($sort == 'name_z_a') {
                    return $query->orderBy('name', 'desc');
                }
            })

            ->paginate($pagination);

        $product_colors = Color::whereUserId(sellerId())->get();
        $product_brands = Brand::whereUserId(sellerId())->whereStatus(1)->get();
        $product_attrbutes = Attribute::with('variations')->withCount('variations')->whereUserId(sellerId())->get();
        return view('sellerFront.product.catalog', compact('products', 'product_colors', 'product_brands', 'product_attrbutes'));
    }

    public function details($slug)
    {
        $product = Product::withCount('reviews')->whereUserId($this->seller)->where('slug', $slug)->first();

        $related_products = Product::withCount('reviews')->where('category_id', $product->category_id)->where('id', '!=', $product->id)->where('status', 1)->orderBy('id', 'DESC')->take(6)->get();
       
        $reviews = Review::with('user')->where('product_id', $product->id)->where('status', 1)->get();
      
        if ($product) {
            return view('sellerFront.product.details', compact('product', 'related_products','reviews'));
        } else {
            return redirect()->route('error');
        }
    }

    public function highlight($type)
    {
        $products = Product::withCount('reviews')->where('status', 1)->where($type, 1)->where('user_id', $this->seller)->orderBy('id', 'DESC')->paginate(10);
        return view('sellerFront.product.highlight', compact('products'));
    }


    public function reviewSubmit(Request $request)
    {
        
        if(!auth()->check()){
            return back()->with('error', 'Please Login First');
        }


        $ck = 0;
        $orders = Order::where('user_id', '=', Auth::id())->where('order_status', '=', '2')->get();

        foreach ($orders as $order) {
            $cart = json_decode($order->cart, true);
            foreach ($cart as $key => $product) {
                if ($request->product_id == getCartItemId($key)) {
                    $ck = 1;
                    break;
                }
            }
        }

        if ($ck == 0) {
            return back()->with('error', 'You have not purchased this product');
        }

        if(!Review::where('user_id', auth()->id())->where('product_id', $request->product_id)->first()){
            // validator 
            $validator = Validator::make($request->all(), [
                'rating' => 'required',
                'review' => 'required',
            ]);
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()->all()[0]]);
            }
        }
        
        $product = Product::whereUserId($this->seller)->where('id', $request->product_id)->first();
        if ($product) {
            $product->reviews()->create([
                'user_id' => Auth::id(),
                'seller_id' => sellerId(),
                'product_id' => $request->product_id,
                'rating' => $request->rating,
                'review' => $request->review,
                'status' => 1,
                'created_at' => Carbon::now(),
            ]);

            $product->update([
                'rating' => $product->reviews()->avg('rating'),
            ]);
            return response()->json(['success' => 'Review Added Successfully']);
        } else {
            return response()->json(['error' => 'Something Went Wrong']);
        }
    }

}
