<?php

namespace App\Http\Controllers\SellerFront;

use App\Http\Controllers\Controller;
use App\Models\Compare;

use App\Models\Product;
use Illuminate\Support\Facades\Session;

class CompareController extends Controller
{

    public function compare()
    {

        if (!Session::has('compare' . sellerId())) {
            return view('sellerFront.compare');
        }
        $oldCompare = Session::get('compare' . sellerId());
        
        $compare = new Compare($oldCompare);
        
        $products = $compare->items;
        
        return view('sellerFront.compare', compact('products'));
    }

    public function addcompare($id)
    {
        $data[0] = 0;
        $prod = Product::findOrFail($id);
        $oldCompare = Session::has('compare' . sellerId()) ? Session::get('compare' . sellerId()) : null;
        $compare = new Compare($oldCompare);
        $compare->add($prod, $prod->id);
        Session::put('compare' . sellerId(), $compare);
        if ($compare->items[$id]['ck'] == 1) {
            $data[0] = 1;
        }
        $data[1] = count($compare->items);
        $data['success'] = __('Successfully Added To Compare.');
        $data['error'] = __('Already Added To Compare.');
        return response()->json($data);
    }

    public function removecompare($id)
    {
        $oldCompare = Session::has('compare' . sellerId()) ? Session::get('compare' . sellerId()) : null;
        $compare = new Compare($oldCompare);
        $compare->removeItem($id);
        Session::put('compare' . sellerId(), $compare);
        return redirect()->back()->with('success', __('Successfully Removed From Compare.'));

    }

}
