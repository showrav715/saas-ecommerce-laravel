<?php

namespace App\Http\Controllers\SellerFront;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\BottomBanner;
use App\Models\Category;
use App\Models\ContactMessage;
use App\Models\ContactPage;
use App\Models\Product;
use App\Models\Slider;
use App\Models\UserBlog;
use App\Models\UserBlogCategory;
use App\Models\UserPage;
use App\Models\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class FrontendController extends Controller
{
    public $seller;
    public function __construct()
    {
        $this->seller = getUser('user_id');
    }
    public function index()
    {
       



        $sliders = cache()->remember('slider' . getUser('domain'), now()->addDay(), function () {
            return Slider::where('user_id', $this->seller)->get();
        });

        $feature_category = cache()->remember('feature_category' . getUser('domain'), now()->addDay(), function () {
            return Category::withCount('products')->where('user_id', $this->seller)->whereFeature(1)->orderby('serial', 'desc')->get();
        });

        $banners = cache()->remember('banners' . getUser('domain'), now()->addDay(), function () {
            return Banner::where('user_id', $this->seller)->get();
        });

        $services = cache()->remember('services' . getUser('domain'), now()->addDay(), function () {
            return UserService::where('user_id', $this->seller)->whereStatus(1)->get();
        });

        $blogs = cache()->remember('front_blogs' . getUser('domain'), now()->addDay(), function () {
            return UserBlog::with('category')->where('user_id', $this->seller)->whereStatus(1)->take(3)->get();
        });

        $new_products = cache()->remember('new_products' . getUser('domain'), now()->addDay(), function () {
            return Product::withCount('reviews')->with('product_attrs')->where('user_id', $this->seller)->whereStatus(1)->whereNew(1)->take(10)->get();
        });
        $best_sellings = cache()->remember('best_sellings' . getUser('domain'), now()->addDay(), function () {
            return Product::withCount('reviews')->with('product_attrs')->where('user_id', $this->seller)->whereBest(1)->whereStatus(1)->take(10)->get();
        });

        $bottom_banner = BottomBanner::where('user_id', $this->seller)->first();

        return view('sellerFront.index', compact('sliders', 'feature_category', 'banners', 'services', 'blogs', 'new_products', 'best_sellings', 'bottom_banner'));
    }

    public function page($slug)
    {
        $page = UserPage::where('slug', $slug)->whereUserId(getUser('user_id'))->first();
        return view('sellerFront.page', compact('page'));
    }

    public function blog()
    {
        $blog_categories = cache()->remember('blog_categories' . getUser('domain'), now()->addDay(), function () {
            return UserBlogCategory::withCount('blogs')->whereUserId($this->seller)->whereStatus(1)->get();
        });

        $recent_blogs = cache()->remember('recent_blogs' . getUser('domain'), now()->addDay(), function () {
            return UserBlog::with('category')->where('user_id', $this->seller)->whereStatus(1)->orderby('id', 'desc')->take(5)->get();
        });

        $blogs = UserBlog::with('category')->where('user_id', $this->seller)->whereStatus(1)
            ->when(request()->category, function ($query) {
                $category = UserBlogCategory::whereSlug(request()->category)->first();
                $query->where('category_id', $category->id);
            })
            ->when(request()->search, function ($query) {
                $query->where('title', 'like', '%' . request()->search . '%');
            })
            ->get();

        return view('sellerFront.blog.index', compact('blogs', 'blog_categories', 'recent_blogs'));
    }

    public function blogShow($slug)
    {
        $blog = UserBlog::with('category')->where('user_id', $this->seller)->whereStatus(1)->whereSlug($slug)->first();
        $blog_categories = cache()->remember('blog_categories' . getUser('domain'), now()->addDay(), function () {
            return UserBlogCategory::withCount('blogs')->whereUserId($this->seller)->whereStatus(1)->get();
        });

        $recent_blogs = cache()->remember('recent_blogs' . getUser('domain'), now()->addDay(), function () {
            return UserBlog::with('category')->where('user_id', $this->seller)->whereStatus(1)->orderby('id', 'desc')->take(5)->get();
        });
        return view('sellerFront.blog.show', compact('blog', 'blog_categories', 'recent_blogs'));
    }

    public function contact()
    {
        $contactPage = ContactPage::where('user_id', $this->seller)->first();
        return view('sellerFront.contact', compact('contactPage'));
    }

    public function contactSubmit(Request $request)
    {
        $this->validate(request(), [
            'name' => 'required',
            'email' => 'required|email',
            'subject' => 'required',
            'message' => 'required',
        ]);

        $message = new ContactMessage();
        $message->name = $request->name;
        $message->email = $request->email;
        $message->subject = $request->subject;
        $message->message = $request->message;
        $message->user_id = $this->seller;
        $message->save();
        return back()->with('success', 'Your message has been sent successfully');
    }

    public function setCurrency($id)
    {
        Session::put('currency' . $this->seller, $id);
        return back();
    }

    public function setlanguage($code)
    {
        Session::put('lang', $code);
        return back();
    }
}
