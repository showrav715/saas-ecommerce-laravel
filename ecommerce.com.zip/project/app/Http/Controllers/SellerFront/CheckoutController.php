<?php

namespace App\Http\Controllers\SellerFront;

use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\Shipping;
use App\Models\UserPaymentGateway;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class CheckoutController extends Controller
{
    public function __construct()
    {
        $this->seller = getUser('user_id');
    }
    
    public function index()
    {
        if(!Auth::check()){
            // get the intended url
            Session::put('redirect_url', url()->current());
            return redirect()->route('seller.user.login');
        }
        
        if(!Session::has('cart'.getUser('user_id'))){
            return view('sellerFront.cart.index');
        }

        if(Session::has('discount'.$this->seller)){
            $discount = Session::get('discount'.$this->seller);
        }else{
            $discount = [];
        }

        $gatewaye = UserPaymentGateway::where('keyword','paystack')->first();
        $paystackData = json_decode($gatewaye->information,true);
        $locations = Location::where('user_id',$this->seller)->get();
        $user = Auth::user();
        
        $payment_gatewayes = UserPaymentGateway::where('currency_id', 'like', '%' . sellerCurrencyData()->id . '%')->orwhere('currency_id','*')->where('user_id',$this->seller)->whereStatus(1)->get();

        return view('sellerFront.checkout',compact('discount','locations','payment_gatewayes','user','paystackData'));
    }


    public function getShipping($location_id)
    {
       $shippings = Shipping::where('locations','like','%'.$location_id.'%')->get();
       return view('sellerFront.includes.shipping',compact('shippings'));
    }


    public function getForm($keyword)
    {
        $gateway = UserPaymentGateway::where('keyword',$keyword)->first();
        return view('sellerFront.includes.payment_form',compact('gateway'));
    }
}
