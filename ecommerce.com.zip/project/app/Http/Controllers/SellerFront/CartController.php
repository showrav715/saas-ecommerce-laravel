<?php

namespace App\Http\Controllers\SellerFront;

use App\Http\Controllers\Controller;
use App\Models\Color;
use App\Models\Coupon;
use App\Models\Product;
use App\Models\Variation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{

    public function __construct()
    {
        $this->seller = getUser('user_id');
    }

    public function index()
    {
        Session::forget('discount' . $this->seller);
        $discount = [];

        return view('sellerFront.cart.index', compact('discount'));
    }

    public function refreshCart()
    {
        if (Session::has('discount' . $this->seller)) {
            $discount = Session::get('discount' . $this->seller);
        } else {
            $discount = [];
        }
        return view('sellerFront.inc.cart', compact('discount'));
    }

    public function headerCart()
    {
        return view('sellerFront.inc.header_cart');
    }

    public function store(Request $request)
    {

        $quantity = $request->has('quantity') ? $request->quantity : 1;
        $color = $request->has('color') && $request->color ? Color::findOrFail($request->color) : null;
        $base_variation = $request->has('variation') ? $request->variation : null;

        if ($request->has('type') && $request->type == 'quantity_update') {
            $item_id = getCartItemId($request->itemId);
            $product = $request->has('itemId') && $item_id ? Product::with('product_attrs')->findOrFail($item_id) : null;
        } else {
            $product = $request->has('product_id') && $request->product_id ? Product::with('product_attrs')->findOrFail($request->product_id) : null;
        }

        $attributes = [];
        
        if ($base_variation) {
            foreach (explode(',', $base_variation) as $value) {
                $option = Variation::with('attribute')->findOrFail($value);
                $attributes[$option->attribute->name] = $option->toArray();
            }
        } else {
            
            if ($attrs = $product->product_attrs) {
                $product_attributes = json_decode($attrs->variation_id, true);
                if($product_attributes){
                    foreach ($product_attributes as $value) {
                        $option = Variation::with('attribute')->findOrFail($value[0]);
                        $attributes[$option->attribute->name] = $option->toArray();
                    }
                }
               
            }
        }

        if (!$color) {
            if ($colors = $product->product_attrs) {
                if ($colors->colors) {
                    $color = Color::findOrFail(explode(',', $colors->colors)[0])->toArray();
                }
            }
        }

        $cart_price = attributePrice($attributes, $product);
        $cart_index = generateIndex($attributes, $color);

        $cart = Session::get('cart' . $this->seller);

        if (isset($cart[$product->id . '-' . $cart_index])) {

            if($product->type == 1){
                if ($request->ajax()) {
                    return response()->json(['success' => 'Product already Added']);
                } else {
                    if ($request->buy_now == 1) {
                        return redirect()->route('seller.front.cart.index')->with('success', 'Product already Added');
                    }
                    return redirect()->back()->with('success', 'Product already Added');
                }
            }

            if ($request->has('type') && $request->type == 'quantity_update') {
                $cart[$product->id . '-' . $cart_index]['quantity'] = $quantity;
            } else {
                $cart[$product->id . '-' . $cart_index]['quantity'] += $quantity;
            }
            $cart[$product->id . '-' . $cart_index]['cart_single_price'] = $cart_price;
            $cart[$product->id . '-' . $cart_index]['cart_item_price'] = $cart_price * $cart[$product->id . '-' . $cart_index]['quantity'];

            Session::put('cart' . $this->seller, $cart);
            if ($request->has('type') && $request->type == 'quantity_update') {
                return view('sellerFront.inc.cart');
            }

            if ($request->ajax()) {
                return response()->json(['success' => 'Product added to cart successfully!']);
            } else {
                if ($request->buy_now == 1) {
                    return redirect()->route('seller.front.cart.index')->with('success', 'Product added to cart successfully!');
                }
                return redirect()->back()->with('success', 'Product added to cart successfully!');
            }
        }

        $cart[$product->id . '-' . $cart_index] =
            [
            "name" => $product->name,
            'slug' => $product->slug,
            'type' => $product->type,
            "quantity" => $quantity,
            "item_stock" => $product->stock,
            "main_price" => $product->current_price,
            "cart_single_price" => $cart_price,
            "cart_item_price" => $cart_price * $quantity,
            "photo" => getPhoto($product->photo, $this->seller),
            "color" => $color,
            "attributes" => $attributes,
        ];

        Session::put('cart' . $this->seller, $cart);
        if ($request->ajax()) {
            return response()->json(['success' => 'Product added to cart successfully!']);
        } else {
            if ($request->buy_now == 1) {
                return redirect()->route('seller.front.cart.index')->with('success', 'Product added to cart successfully!');
            }
            return redirect()->back()->with('success', 'Product added to cart successfully!');
        }

    }

    public function cartRemove($key)
    {
        try {
            $cart = Session::get('cart' . $this->seller);
            unset($cart[$key]);
            Session::put('cart' . $this->seller, $cart);
            return view('sellerFront.inc.cart');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', 'Something went wrong!');
        }

    }

    public function applyCoupon(Request $request)
    {
        $coupon = $request->has('coupon_code') ? $request->coupon_code : null;
        if (!$coupon) {
            return response()->json(['error' => 'Coupon code is required!']);
        }

        $cart = Session::get('cart' . $this->seller);
        $total = 0;
        foreach ($cart as $key => $value) {
            $total += $value['cart_item_price'];
        }

        $coupon = Coupon::where('code', $coupon)->where('status', 1)->where('expired', '>=', date('Y-m-d'))->first();
        if (!$coupon) {
            return response()->json(['error' => 'Invalid coupon code!']);
        }

        Session::forget('discount' . $this->seller);

        $discount = ($total * $coupon->percentage) / 100;

        $discount = [
            'coupon' => $coupon,
            'discount' => $discount,
        ];
        Session::put('discount' . $this->seller, $discount);

        return response()->json(['success' => 'Coupon applied successfully!']);
    }

}
