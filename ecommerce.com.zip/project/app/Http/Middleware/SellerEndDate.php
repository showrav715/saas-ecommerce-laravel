<?php

namespace App\Http\Middleware;

use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SellerEndDate
{
    public function handle(Request $request, Closure $next, ...$guards)
    {
        if (Auth::guard('web')->check()) {
            if(checkSellerEndData()){
                return redirect()->route('seller.subscription.index')->with('error','Your subscription has been expired. Please renew your subscription to continue using our services.');
            }
        }
        return $next($request);
    }
}
