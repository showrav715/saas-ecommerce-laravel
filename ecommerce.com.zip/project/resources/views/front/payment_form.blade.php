@if (in_array($gateway->keyword, ['stripe', 'authorize']))
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>@lang('Card Number')</label>
                <input class="form-control" type="text" name="card" placeholder="Enter Card Number">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>@lang('Month')</label>
                <input class="form-control" type="text" name="month" placeholder="Month">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>@lang('Year')</label>
                <input class="form-control" type="text" name="year" placeholder="Year">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>@lang('CVC')</label>
                <input class="form-control" type="text" name="cvc" placeholder="Enter CVC">
            </div>
        </div>
    </div>
@endif

