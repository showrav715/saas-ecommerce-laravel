@extends('layouts.front')

@section('content')
     <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h2 class="hero-title">Pricing Plan</h2>
                <ul class="breadcrumb">
                    <li>
                        <a href="{{route('landing.index')}}">Home</a>
                    </li>
                    <li>
                        Pricing Plan
                    </li>
                </ul>
            </div>
        </div>
        <span class="banner-elem elem1">&nbsp;</span>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem7">&nbsp;</span>
    </section>
 
    <section class="pricing-plan pt-5 pb-100">
        <div class="container">
            <div class="row g-4 justify-content-center">
                @foreach ($packages as $package)
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="pricing-items">
                        <div class="pricing-head">
                            <h4>
                                {{$package->name}}
                            </h4>
                            @if ($package->days == 7)
                                <div class="pricing-detail text-white"><strong>@lang('Per Week')</strong></div>
                            @elseif($package->days == 30)
                                <div class="pricing-detail text-white"><strong>@lang('Per Month')</strong></div>
                            @elseif($package->days == 365)
                                <div class="pricing-detail text-white"><strong>@lang('Per Year')</strong></div>
                            @endif
                            <p class="px-2 m-2 mt-0"> {{ $package->description }}</p>
                        </div>
                       
                        <div class="pricing-content">
                           <div class="content-body">
                            
                                <ul class="pricing-list">
                                    <li>
                                        <span>Category Limit {{$package->category_limit}}</span>
                                    </li>
                                    <li>
                                        <span>Product Limit {{$package->product_limit}}</span>
                                    </li>
                                    <li>
                                        <span>Customer Limit {{$package->customer_limit}}</span>
                                    </li>
                                    <li>
                                        <span>Brand Limit {{$package->brand_limit}}</span>
                                    </li>
                                    
                                    <li>
                                        <span>Variant Limit {{$package->variant_limit}}</span>
                                    </li>
                                   
                                    @if ($package->custom_domain == 1)
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Custom Domain</span>
                                    </li>
                                    @else
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Custom Domain</span>
                                    </li>
                                    @endif

                                    @if ($package->customer_panel_access == 1)
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Customer Panel Access</span>
                                    </li>
                                    @else
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Customer Panel Access</span>
                                    </li>
                                    @endif

                                    @if ($package->support == 1)
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Support Module</span>
                                    </li>
                                    @else
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Support Module</span>
                                    </li>
                                    @endif

                                    @if ($package->qr_code == 1)
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>QR Code</span>
                                    </li>
                                    @else
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>QR Code</span>
                                    </li>
                                    @endif

                                    @if ($package->facebook_pixel == 1)
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Facebook Pixel</span>
                                    </li>
                                    @else
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Facebook Pixel</span>
                                    </li>
                                    @endif

                                    @if ($package->google_analytics == 1)
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Google Analytics</span>
                                    </li>
                                    @else
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Google Analytics</span>
                                    </li>
                                    @endif
                                </ul>
                                <h2>
                                    {{landingShowAmount($package->price)}}
                                </h2>
                                <div class="pricing-btn">
                                    <a href="{{route('landing.package.order',$package->id)}}" class="cmn--btn">
                                        Purchase now
                                    </a>
                                </div>
                           </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
@endsection