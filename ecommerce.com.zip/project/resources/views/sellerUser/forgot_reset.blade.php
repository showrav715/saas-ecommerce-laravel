@extends('layouts.sellerFront')

@section('content')
    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Reset Password')</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Reset Password')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <div class="full-row">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="woocommerce">
                        <div class="row">
                            <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                <div class="sign-in-form">
                                    <h3>@lang('User Reset Password')</h3>
                                    <form class="woocommerce-form-login" action="{{ route('seller.user.reset.password.submit') }}"
                                        method="post">
                                        @csrf
                                        <input type="hidden" name="code" value="{{$code}}">
                                        <p>
                                            <label for="password">@lang('New Password')&nbsp;<span class="required">*</span></label>
                                            <input class="form-control" type="password" name="password" id="password" />
                                            @error('password')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror

                                        </p>

                                        <p>
                                            <label for="password_confirmation">@lang('Confirm Password')&nbsp;<span
                                                    class="required">*</span></label>
                                            <input class="form-control" type="password" name="password_confirmation"
                                                id="password_confirmation" />
                                            @error('password_confirmation')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror

                                        </p>
                                        <button type="submit"
                                            class="woocommerce-form-login__submit btn btn-primary rounded-0">@lang('Reset
                                            Password')</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
