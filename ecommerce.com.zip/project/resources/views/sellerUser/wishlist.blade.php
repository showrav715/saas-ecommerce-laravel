@extends('layouts.sellerFront')

@section('content')
    <div class="full-row bg-light py-5">
      <div class="container">
          <div class="row text-secondary">
              <div class="col-sm-6">
                  <h3 class="mb-2 text-secondary">@lang('Wishlist')</h3>
              </div>
              <div class="col-sm-6">
                  <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                      <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                          <li class="breadcrumb-item"><a href="{{ route('seller.user.dashboard') }}"><i
                                      class="fas fa-home me-1"></i>@lang('Dashboard')</a></li>
                          <li class="breadcrumb-item active" aria-current="page">@lang('Wishlist')</li>
                      </ol>
                  </nav>
              </div>
          </div>
      </div>
  </div>

    <div class="full-row">
        <div class="container" id="ajaxContent">
           <div class="mb-4 d-xl-none">
              <button class="dashboard-sidebar-btn btn bg-primary rounded">
              <i class="fas fa-bars"></i>
              </button>
           </div>
           <div class="row wish_load">
            <div class="col-xl-4">
               @include('sellerUser.inc.user-sidebar')
            </div>
              <div class="col-xl-8">
               <div class="table-responsive">
                  <table class="shop_table __table wishlist_table wishlist_view traditional table" data-pagination="no"
                     data-per-page="5" data-page="1" data-id="3989" data-token="G5CZRAZPRKEY">
                     <thead>
                        <tr>
                           <th class="product-thumbnail">{{ __('Product Image') }}</th>
                           <th class="product-name"> <span class="nobr"> {{ __('Product name') }} </span></th>
                           <th class="product-price"> <span class="nobr"> {{ __('Unit price') }} </span></th>
                           <th class="product-stock-status"> <span class="nobr"> {{ __('Stock status') }} </span>
                           </th>
                           <th class="product-add-to-cart"> <span class="nobr"> </span>{{ __('Actions') }}</th>
                        </tr>
                     </thead>
                     <tbody class="wishlist-items-wrapper">
                        @forelse ($wishlists as $wishlist)
                        
                        <tr>
                           <td class="product-thumbnail">
                              <a href="{{ route('seller.front.product.details', $wishlist->slug) }}"> <img
                                 src="{{ getPhoto($wishlist->photo, sellerId()) }}" alt=""> </a>
                           </td>
                           <td class="product-name"> <a
                              href="{{ route('seller.front.product.details', $wishlist->slug) }}">{{ mb_strlen($wishlist->name, 'UTF-8') > 35 ? mb_substr($wishlist->name, 0, 35, 'UTF-8') . '...' : $wishlist->name }}</a>
                           </td>
                           <td class="product-price">
                              <span class="woocommerce-Price-amount amount">
                              <bdi>
                              <span
                                 class="woocommerce-Price-currencySymbol">{{ sellerShowAmount($wishlist->base_price) }}
                              <small>
                              <del>
                              {{ sellerShowAmount($wishlist->previous_price) }}
                              </del>
                              </small>
                              </span>
                              </bdi>
                              </span>
                           </td>
                           <td class="product-stock-status">
                              @if ($wishlist->stock == 0)
                              <div class="stock-availability out-stock">{{ 'Out Of Stock' }}</div>
                              @else
                              <div class="stock-availability in-stock text-bold">{{ 'In Stock' }}
                              </div>
                              @endif
                           </td>
                           <td class="product-remove">
                              <div>
                                 <a href="{{ route('seller.user.wishlist.remove',$wishlist->id) }}"
                                    class="remove wishlist-remove remove_from_wishlist"
                                    title="Remove this product">×</a>
                              </div>
                           </td>
                           
                        </tr>

                        @empty
                        <tr>
                           <td colspan="5" class="text-center">
                              <h3 class="text-danger">{{ __('No Wishlist Found') }}</h3>
                           </td>
                        </tr>
                        @endforelse
                     </tbody>
                  </table>
                 </div>
              </div>
           </div>
        </div>
     </div>
@endsection
