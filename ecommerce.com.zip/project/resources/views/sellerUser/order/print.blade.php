<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="GeniusOcean">

    <title>{{ $gs->title }}</title>
 
    <link rel="stylesheet" href="{{ asset('assets/print/css/style.css') }}">
    <link href="{{ asset('assets/print/css/print.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link rel="icon" type="image/png" href="{{ asset('assets/images/' . $gs->favicon) }}">
    <style type="text/css">
        #color-bar {
            display: inline-block;
            width: 20px;
            height: 20px;
            margin-left: 5px;
            margin-top: 5px;
        }

        @page {
            size: auto;
            margin: 0mm;
        }

        @page {
            size: A4;
            margin: 0;
        }

        @media print {

            html,
            body {
                width: 210mm;
                height: 287mm;
            }

            html {}

            ::-webkit-scrollbar {
                width: 0px;
                /* remove scrollbar space */
                background: transparent;
                /* optional: just make scrollbar invisible */
            }
        }
    </style>
</head>

<body onload="window.print();">
   <div class="container-fluid">
   <div class="row">
   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <!-- Starting of Dashboard data-table area -->
      <div class="section-padding add-product-1">
         <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="product__header">
                  <div class="row reorder-xs">
                     <div class="row">
                        <div class="col-md-10">
                           <div class="dashboard-content">
                              <div class="view-order-page">
                                 <h3 class="order-code">{{ __('Order#') }} {{ $order->order_number }} @if ($order->order_status == '0')
                                    [<span class="text-danger">{{ __('Pending') }}</span>]
                                    @elseif($order->order_status == '1')
                                    [<span class="">{{ __('Processing') }}</span>]
                                    @elseif($order->order_status == '2')
                                    [<span class="">{{ __('Completed') }}</span>]
                                    @endif
                                 </h3>
                                
                                 <p class="order-date">{{ __('Order Date') }}
                                    {{ date('d-M-Y', strtotime($order->created_at)) }}
                                 </p>
                                 <div class="shipping-add-area">
                                    <div class="row">
                                       <div class="col-md-6">
                                          <h5>{{ __('PickUp Location') }}</h5>
                                          <address>
                                             {{ __('Address:') }} {{ $order->pickup_location }}<br>
                                          </address>
                                       </div>
                                       <div class="col-md-6">
                                          <h5>{{ __('Shipping Method') }}</h5>
                                          @if ($order->shipping == 'shipto')
                                          <p>{{ __('Ship To Address') }}</p>
                                          @else
                                          <p>{{ __('Pick Up') }}</p>
                                          @endif
                                       </div>
                                    </div>
                                 </div>
                                 <div class="billing-add-area">
                                    <div class="row">
                                       <div class="col-md-6">
                                          <h5>{{ __('Billing Address') }}</h5>
                                          <address>
                                             {{ __('Name:') }} {{ $order->name }}<br>
                                             {{ __('Email:') }} {{ $order->email }}<br>
                                             {{ __('Phone:') }} {{ $order->phone }}<br>
                                             {{ __('Address:') }} : {{ $order->delivery_address }}<br>
                                          </address>
                                       </div>
                                       <div class="col-md-6">
                                          <h5>{{ __('Payment Information') }}</h5>
                                          <p>{{ __('Payment Status') }}  :
                                             @if ($order->payment_status == 0)
                                             <b >{{ __('Unpaid') }}</b>
                                             @else
                                             <b>{{ __('Paid') }}</b>
                                             @endif
                                          </p>
                                          <p>{{ __('Paid Amount:') }}
                                             {{ sellerOrderAmount($order) }}
                                          </p>
                                          <p>{{ __('Payment Method:') }} {{ $order->payment_method }}</p>
                                          <p>Transaction Id : {{$order->txn_id}}</p>
                                       </div>
                                    </div>
                                 </div>
                                 <br>
                                 <div class="table-responsive">
                                    <h5>{{ __('Ordered Products:') }}</h5>
                                    <table class="table veiw-details-table">
                                       <thead>
                                          <tr>
                                             <th>{{ __('Image') }}</th>
                                             <th>{{ __('Name') }}</th>
                                             <th>{{ __('Qty') }}</th>
                                             <th>{{ __('Price') }}</th>
                                             <th>{{ __('Total') }}</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          @foreach (json_decode($order->cart, true) as $product)
                                          <tr>
                                             <td data-label="{{ __('Photo') }}">
                                                <img width="100" src="{{ $product['photo'] }}"
                                                   alt="Image">
                                             </td>
                                             <td data-label="{{ __('Name') }}">
                                                <div>
                                                   {{ $product['name'] }}
                                                </div>
                                             </td>
                                             <td data-label="{{ __('Qty') }}">
                                                <div>
                                                   {{ $product['quantity'] }}
                                                </div>
                                             </td>
                                             <td data-label="{{ __('Price') }}">
                                                <div>
                                                   {{ sellerShowAmount($product['cart_single_price']) }}
                                                </div>
                                             </td>
                                             <td data-label="{{ __('Total') }}">
                                                <div>
                                                   {{ sellerShowAmount($product['cart_item_price']) }}
                                                </div>
                                             </td>
                                          </tr>
                                          @endforeach
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Ending of Dashboard data-table area -->
   </div>
   <script type="text/javascript">
      (function($) {
          "use strict";
          setTimeout(function() {
              window.close();
          }, 500);
      
      })(jQuery);
   </script>
</body>

</html>
