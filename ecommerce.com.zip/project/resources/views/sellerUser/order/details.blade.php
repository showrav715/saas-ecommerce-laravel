@extends('layouts.sellerFront')

@section('content')

    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Purchased Item :') </h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.user.dashboard') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Dashboard')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Purchased Item') -> {{$order->order_number}}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->

    <!--==================== Blog Section Start ====================-->
    <div class="full-row">
        <div class="container">
            <div class="mb-4 d-xl-none">
                <button class="dashboard-sidebar-btn btn bg-primary rounded">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="row">
                <div class="col-xl-4">
                    @include('sellerUser.inc.user-sidebar')
                </div>
                <div class="col-xl-8">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="widget border-0 p-40 widget_categories bg-light account-info">
                                <div class="process-steps-area">
                                    @include('sellerUser.inc.order-process')
                                </div>
                                <h4 class="widget-title down-line mb-30">{{ __('Purchased Items') }}</h4>
                                <div class="view-order-page">
                                    <h3 class="order-code">{{ __('Order#') }} {{ $order->order_number }} @if ($order->order_status == '0')
                                            [<span class="text-danger">{{ __('Pending') }}</span>]
                                        @elseif($order->order_status == '1')
                                            [<span class="">{{ __('Processing') }}</span>]
                                        @elseif($order->order_status == '2')
                                            [<span class="">{{ __('Completed') }}</span>]
                                        @endif
                                    </h3>
                                    <div class="print-order text-right">
                                        <a href="{{route('seller.user.order.print',$order->id)}}" target="_blank" class="print-order-btn">
                                            <i class="fa fa-print"></i> {{ __('Print Order') }}
                                        </a>
                                    </div>
                                    <p class="order-date">{{ __('Order Date') }}
                                        {{ date('d-M-Y', strtotime($order->created_at)) }}
                                    </p>

                                    @php
                                        $order_shipp = json_decode($order->shipping,true);
                                        $shipping = $order_shipp['shipping'];
                                        $location = $order_shipp['location'];
                                    @endphp

                                    <div class="shipping-add-area">
                                        <div class="row">
                                            <div class="col-md-6">
                                             <h5>{{ __('Location') }}</h5>
                                             <address>
                                                 {{ __('Location:') }} {{ $location['location'] }}<br>
                                                 {{ __('Address:') }} : {{ $order->delivery_address }}<br>
                                             </address>
                                            </div>
                                            <div class="col-md-6">
                                                <h5>{{ __('Shipping Method') }}</h5>
                                                <p>{{ $shipping['shipping'] }}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="billing-add-area">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h5>{{ __('Billing Address') }}</h5>
                                                <address>
                                                    {{ __('Name:') }} {{ $order->name }}<br>
                                                    {{ __('Email:') }} {{ $order->email }}<br>
                                                    {{ __('Phone:') }} {{ $order->phone }}<br>
                                                    {{ __('Address:') }} : {{ $order->delivery_address }}<br>
                                                </address>
                                            </div>
                                            <div class="col-md-6">
                                                <h5>{{ __('Payment Information') }}</h5>
                                                <p>{{ __('Payment Status') }}  :
                                                   
                                                    @if ($order->payment_status == 0)
                                                        <b >{{ __('Unpaid') }}</b>
                                                    @else
                                                        <b>{{ __('Paid') }}</b>
                                                    @endif
                                                </p>
                                               
                                                <p>{{ __('Shipping Amount:') }}
                                                    {{ sellerOrderShippingAmount($order) }}
                                                </p>
                                                <p>{{ __('Paid Amount:') }}
                                                    {{ sellerOrderAmount($order) }}
                                                </p>
                                                <p>{{ __('Payment Method:') }} {{ $order->payment_method }}</p>
                                                <p>@lang('Transaction Id') : {{$order->txn_id}}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="table-responsive">
                                        <h5>{{ __('Ordered Products:') }}</h5>
                                        <table class="table __table veiw-details-table">
                                            <thead>
                                                <tr>
                                                    <th>{{ __('Image') }}</th>
                                                    <th>{{ __('Name') }}</th>
                                                    <th>{{ __('Qty') }}</th>
                                                    <th>{{ __('Price') }}</th>
                                                    <th>{{ __('Total') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (json_decode($order->cart, true) as $product)
                                                    <tr>
                                                        <td data-label="{{ __('Photo') }}">
                                                            <img width="100" src="{{ $product['photo'] }}"
                                                                alt="Image">
                                                        </td>
                                                        <td data-label="{{ __('Name') }}">
                                                            <div>
                                                                {{ $product['name'] }}
                                                            </div>
                                                        </td>
                                                        <td data-label="{{ __('Qty') }}">
                                                            <div>
                                                                {{ $product['quantity'] }}
                                                            </div>
                                                        </td>
                                                        <td data-label="{{ __('Price') }}">
                                                            <div>
                                                                {{ sellerShowAmount($product['cart_single_price']) }}
                                                            </div>
                                                        </td>
                                                        <td data-label="{{ __('Total') }}">
                                                            <div>
                                                                {{ sellerShowAmount($product['cart_item_price']) }}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <a class="btn btn-primary mt-4" href="{{ route('seller.user.order.index') }}">
                                    {{ __('Back') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection
