<div class="dashboard-overlay">&nbsp;</div>
<div id="sidebar" class="sidebar-blog bg-light p-30 mt-0">
  <div class="dashbaord-sidebar-close d-xl-none">
    <i class="fas fa-times"></i>
  </div>
    <div class="widget border-0 py-0 widget_categories">
        <h4 class="widget-title down-line">{{ __('Dashboard') }}</h4>
        <ul>
            <li class=""><a class="{{ Request::url() == route('seller.user.dashboard') ? 'active':'' }}" href="{{ route('seller.user.dashboard') }}">@lang('Dashboard')</a></li>
         
            <li class=""><a class="{{ Request::url() == route('seller.user.order.index') ? 'active':'' }}" href="{{ route('seller.user.order.index') }}">{{ __('Orders') }}</a></li>
            <li class=""><a class="{{ Request::url() == route('seller.user.profile') ? 'active':'' }}" href="{{ route('seller.user.profile') }}">{{ __('Edit Profile') }}</a></li>
            <li class=""><a class="{{ Request::url() == route('seller.user.reset') ? 'active':'' }}" href="{{ route('seller.user.reset') }}">{{ __('Reset Password') }}</a></li> 
            <li class=""><a class="{{ Request::url() == route('seller.user.wishlist.index') ? 'active':'' }}" href="{{ route('seller.user.wishlist.index') }}">{{ __('Wishlists') }}</a></li>
            <li class=""><a class="" href="{{ route('seller.user.logout') }}">{{ __('Logout') }}</a></li>
        </ul>
    </div>
</div>
