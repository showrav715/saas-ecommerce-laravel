@extends('layouts.sellerFront')

@section('content')
    <!-- breadcrumb -->
    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Login')</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Login')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <div class="full-row">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="woocommerce">
                        <div class="row">
                            <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                <div class="sign-in-form">
                                    <h3>@lang('User Login')</h3>
                                    <form class="woocommerce-form-login" action="{{ route('seller.user.login.submit') }}"
                                        method="post">
                                        @csrf
                                        <p>
                                            <label for="email">@lang('Email')<span class="required">*</span></label>
                                            <input type="email" class="form-control" name="email" id="email" />
                                            @error('email')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </p>
                                        <p>
                                            <label for="password">@lang('Password')&nbsp;<span
                                                    class="required">*</span></label>
                                            <input class="form-control" type="password" name="password" id="password" />
                                            @error('password')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </p>
                                        <p class="form-row">
                                            <label class="woocommerce-form__label-for-checkbox">
                                                <input name="rememberme" type="checkbox" />
                                                <span>@lang('Remember me')</span>
                                            </label>
                                            <button type="submit"
                                                class="woocommerce-form-login__submit btn btn-primary rounded-0">@lang('Log in')</button>
                                        </p>
                                        <p>
                                            <a href="{{ route('seller.user.forgot.password') }}"
                                                class="text-secondary">@lang('Lost your password?')</a>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
