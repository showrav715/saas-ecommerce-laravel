@extends('layouts.sellerFront')

@section('content')
    <!-- breadcrumb -->
    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Forgot Password')</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{route('seller.front.index')}}"><i class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Forgot Password')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

   
    <div class="full-row">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="woocommerce">
                        <div class="row">
                            <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                <div class="sign-in-form">
                                    <h3>@lang('Forgot Password')</h3>
                                    <form class="woocommerce-form-login" action="{{route('seller.user.forgot.submit')}}" method="post">
                                        @csrf
                                        <p>
                                            <label for="email">Email<span class="required">*</span></label>
                                            <input type="email" class="form-control" name="email" id="email" />
                                            @error('email')
                                                <span class="text-danger">{{$message}}</span>
                                            @enderror
                                         </p>
                                         <button type="submit" class="woocommerce-form-login__submit btn btn-primary rounded-0">Submit</button>
                                        <p>
                                            <a href="{{route('seller.user.login')}}" class="text-secondary">@lang('Back to login')</a>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection