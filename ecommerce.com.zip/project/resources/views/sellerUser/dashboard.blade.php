@extends('layouts.sellerFront')

@section('content')
<div class="full-row bg-light py-5">
   <div class="container">
       <div class="row text-secondary">
           <div class="col-sm-6">
               <h3 class="mb-2 text-secondary">@lang('Wishlist')</h3>
           </div>
           <div class="col-sm-6">
               <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                   <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                       <li class="breadcrumb-item"><a href="{{ route('seller.user.dashboard') }}"><i
                                   class="fas fa-home me-1"></i>@lang('Dashboard')</a></li>
                   </ol>
               </nav>
           </div>
       </div>
   </div>
</div>
 <!--==================== Blog Section Start ====================-->
 <div class="full-row">
    <div class="container">
         <div class="mb-4 d-xl-none">
             <button class="dashboard-sidebar-btn btn bg-primary rounded">
                 <i class="fas fa-bars"></i>
             </button>
         </div>
       <div class="row">
          <div class="col-xl-4">
             @include('sellerUser.inc.user-sidebar')
          </div>
          <div class="col-xl-8">
             @if (Session::has('success'))
             <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>{{__('Success')}}</strong> {{Session::get('success')}}
             </div>
             @endif
             <div class="row">
                <div class="col-lg-12">
                   <div class="widget border-0 p-30 widget_categories bg-light account-info">
                      <h4 class="widget-title down-line mb-30">{{ __('Account Information') }}</h4>
                      <div class="user-info">
                         <h5 class="title">{{ $user->name }}</h5>
                         <p><span class="user-title">{{ __('Email') }}:</span> {{ $user->email }}</p>
                         @if($user->phone != null)
                         <p><span class="user-title">{{ __('Phone') }}:</span> {{ $user->phone }}</p>
                         @endif
                         @if($user->fax != null)
                         <p><span class="user-title">{{ __('Fax') }}:</span> {{ $user->fax }}</p>
                         @endif
                         @if($user->city != null)
                         <p><span class="user-title">{{ __('City') }}:</span> {{ $user->city }}</p>
                         @endif
                         @if($user->zip != null)
                         <p><span class="user-title">{{ __('Zip') }}:</span> {{ $user->zip }}</p>
                         @endif
                         @if($user->address != null)
                         <p><span class="user-title">{{ __('Address') }}:</span> {{ $user->address }}</p>
                         @endif
                      </div>
                   </div>
                </div>
                
             </div>
             {{-- Statistic section --}}
             <div class="row mt-3">
                <div class="col-lg-6">
                   <div class="widget border-0 p-30 widget_categories bg-light account-info card c-info-box-area">
                      <div class="c-info-box box2">
                         <p>{{$total_order_count}}</p>
                      </div>
                      <div class="c-info-box-content">
                         <h6 class="title">{{ __('Total Orders') }}</h6>
                         <p class="text">{{ __('All Time') }}</p>
                      </div>
                   </div>
                </div>
                <div class="col-lg-6">
                   <div class="widget border-0 p-30 widget_categories bg-light account-info card c-info-box-area">
                      <div class="c-info-box box1">
                         <p>{{$total_pending_order_count}}</p>
                      </div>
                      <div class="c-info-box-content">
                         <h6 class="title">{{ __('Pending Orders') }}</h6>
                         <p class="text">{{ __('All Time') }}</p>
                      </div>
                   </div>
                </div>
             </div>
             {{-- Statistic section End--}}
             <div class="row table-responsive-lg mt-3">
                <div class="col-lg-12">
                   <div class="widget border-0 p-30 widget_categories bg-light account-info">
                      <h4 class="widget-title down-line mb-30">{{ __('Recent Orders') }}</h4>
                        <div class="table--mobile">
                           <table class="table __table order-table" cellspacing="0" id="example" width="100%">
                              <thead>
                              <tr>
                                 <th>{{ __('#Order') }}</th>
                                 <th>{{ __('Date') }}</th>
                                 <th>{{ __('Order Total') }}</th>
                                 <th>{{ __('Order Status') }}</th>
                                 <th>{{ __('View') }}</th>
                              </tr>
                              </thead>
                              <tbody>
                                 @forelse($orders as $order)
                              <tr>
                                 <td data-label="{{ __('#Order') }}">
                                    {{$order->order_number}}
                                 </td>
                                 <td data-label="{{ __('Date') }}">
                                    {{date('d M Y',strtotime($order->created_at))}}
                                 </td>
                                 <td data-label="{{ __('Order Total') }}">
                                    {{ sellerOrderAmount($order) }}
                                 </td>
                                 <td data-label="{{ __('Order Status') }}">
                                    <div class="">
                                    @if($order->order_status == '0')
                                    <span class="text-danger">{{ __('Pending') }}</span>
                                    @elseif($order->order_status == '1')
                                    <span class="">{{ __('Processing') }}</span>
                                    @elseif($order->order_status == '2')
                                    <span class="">{{ __('Completed') }}</span>
                                    @endif
                                    </div>
                                 </td>
                                 <td data-label="{{ __('View') }}">
                                    <a class="btn icon-btn" href="{{route('seller.user.order.details',$order->id)}}">
                                    <i class="fas fa-eye"></i>
                                    </a>
                                 </td>
                              </tr>
                                 @empty
                                 <tr>
                                    <td colspan="5" class="text-center">
                                          {{ __('No Order Found') }}
                                    </td>
                              @endforelse
                              </tbody>
                           </table>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!--==================== Blog Section End ====================-->
@endsection