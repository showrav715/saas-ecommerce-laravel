@extends('layouts.sellerFront')
@section('content')
<div class="full-row bg-light py-5">
   <div class="container">
       <div class="row text-secondary">
           <div class="col-sm-6">
               <h3 class="mb-2 text-secondary">@lang('Edit Profile')</h3>
           </div>
           <div class="col-sm-6">
               <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                   <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                       <li class="breadcrumb-item"><a href="{{ route('seller.user.dashboard') }}"><i
                                   class="fas fa-home me-1"></i>@lang('Dashboard')</a></li>
                       <li class="breadcrumb-item active" aria-current="page">@lang('Edit Profile')</li>
                   </ol>
               </nav>
           </div>
       </div>
   </div>
</div>


<div class="full-row">
   <div class="container">
        <div class="mb-4 d-xl-none">
            <button class="dashboard-sidebar-btn btn bg-primary rounded">
                <i class="fas fa-bars"></i>
            </button>
        </div>
      <div class="row">
         <div class="col-xl-4">
            @include('sellerUser.inc.user-sidebar')
         </div>
         <div class="col-xl-8">
            <div class="row">
               <div class="col-lg-12">
                  <div class="widget border-0 p-40 widget_categories bg-light account-info">
                     <h4 class="widget-title down-line mb-30">{{ __('Edit Profile') }}
                     </h4>
                     <div class="edit-info-area">
                        <div class="body">
                           <div class="edit-info-area-form">
                              <div class="gocover"
                                 style="background: url({{ asset('assets/images/'.$gs->loader) }}) no-repeat scroll center center">
                              </div>
                              <form id="userform" action="{{route('seller.user.profile.update')}}" method="POST" enctype="multipart/form-data">
                                 @csrf
                                 <div class="upload-img">
                                    <div class="img"><img  src="{{ getPhoto($user->photo,sellerId()) }}">
                                    </div>
                                    <div class="file-upload-area">
                                       <div class="upload-file">
                                          <label>{{ __('Upload') }}
                                          <input type="file" size="60" name="photo" class="upload form-control">
                                          </label>
                                          @error('photo')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                          @enderror
                                       </div>
                                    </div>
                                    
                                 </div>
                                 
                                 <div class="row mb-4">
                                    <div class="col-lg-6">
                                       <label for="name">@lang('Name')</label>
                                       <input name="name" type="text" class="input-field form-control border bg-white"
                                          placeholder="{{ __('Name') }}" id="name" required=""
                                          value="{{ $user->name }}">
                                          @error('name')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                          @enderror
                                    </div>
                                    <div class="col-lg-6">
                                       <label for="email">@lang('Email')</label>
                                       <input name="email" type="email" class="input-field form-control border bg-white"
                                          placeholder="{{ __('Email Address') }}" id="email" required=""
                                          value="{{ $user->email }}">
                                          @error('email')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                          @enderror
                                    </div>
                                 </div>
                                 <div class="row mb-4">
                                    <div class="col-lg-6">
                                       <label for="phone">@lang('Phone Number')</label>
                                       <input name="phone" type="text" class="input-field form-control border bg-white"
                                          placeholder="{{ __('Phone Number') }}" id="phone" required=""
                                          value="{{ $user->phone }}">

                                          @error('phone')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                          @enderror
                                    </div>
                                    <div class="col-lg-6">
                                       <label for="zip">@lang('Zip')</label>
                                       <input name="zip" type="text" id="zip" class="input-field form-control border bg-white"
                                          placeholder="{{ __('Zip') }}" value="{{ $user->zip }}">
                                          @error('zip')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                          @enderror
                                    </div>
                                 </div>
                                 <div class="row mb-4">
                                    <div class="col-lg-6">
                                       <label for="city">@lang('City')</label>
                                       <input name="city" type="text" id="city" class="input-field form-control border bg-white"
                                          placeholder="{{ __('City') }}" value="{{ $user->city }}">
                                          @error('city')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                          @enderror
                                    </div>
                                    <div class="col-lg-6">
                                       <label for="country">@lang('Country')</label>
                                       <select class="input-field form-control border bg-white" id="country" name="country">
                                          <option value="">{{ __('Select Country') }}</option>
                                          @foreach (DB::table('countries')->get() as $data)
                                          <option value="{{ $data->name }}" {{ $user->country == $data->name ? 'selected' : '' }}>
                                          {{ $data->name }}
                                          </option>
                                          @endforeach
                                       </select>
                                       @error('country')
                                          <p class="text-danger mb-0">{{ $message }}</p>
                                       @enderror
                                    </div>
                                 </div>
                                
                                 <div class="row mb-4">
                                    <div class="col-lg-12">
                                       <label for="address">@lang('Address')</label>
                                       <textarea class="input-field form-control border bg-white" id="address" name="address" placeholder="{{ __('Address') }}" cols="30" rows="5" required>{{ $user->address }}</textarea>
                                       @error('address')
                                       <p class="text-danger mb-0">{{ $message }}</p>
                                       @enderror
                                    </div>
                                 </div>
                                 <div class="form-links">
                                    <button class="submit-btn btn btn-primary" type="submit">{{ __('Save') }}</button>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>


@endsection

