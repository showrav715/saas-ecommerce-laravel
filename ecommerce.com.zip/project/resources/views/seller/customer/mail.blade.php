@extends('layouts.seller')
@section('title')
    @lang('Send Mail')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header  d-flex justify-content-between">
            <h1>@lang('Send Mail')</h1>
            <a href="{{ route('seller.customer.index') }}" class="btn btn-primary"><i class="fas fa-backward"></i>
                @lang('Back')</a>
        </div>
    </section>
@endsection
@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8 offset-md-1">
            <!-- Form Basic -->
            <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">{{ __('Send Mail') }}</h6>
                </div>
                <div class="card-body">

                    <form action="{{ route('seller.customer.mail.send', $customer->id) }}" enctype="multipart/form-data"
                        method="POST">
                        @csrf
                        
                        <div class="form-group">
                            <label>@lang('Customer Email')</label>
                            <input class="form-control" readonly value="{{ old('to', $customer->email) }}">
                        </div>

                        <div class="form-group">
                            <label>@lang('Subject')</label>
                            <input class="form-control" name="subject" placeholder="@lang('Enter Subject')" value="{{ old('subject') }}">
                        </div>

                        <div class="form-group">
                            <label>@lang('Body')</label>
                            <textarea name="body" class="form-control" placeholder="@lang('Enter Message')"></textarea>
                        </div>
                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-primary btn-lg">@lang('Submit')</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
