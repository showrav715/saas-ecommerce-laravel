@extends('layouts.seller')

@section('title')
    @lang('Manage Customers')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Manage Customers')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="table-responsive p-3">
                    <table class="table table-striped" id="table">
                        <thead>
                            <tr>
                                <th>@lang('Name')</th>
                                <th>@lang('Email')</th>
                                <th>@lang('Phone')</th>
                                <th>@lang('Total Orders')</th>
                                <th>@lang('Created at')</th>
                                <th>@lang('Action')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($customers as $customer)
                            <tr>
                                <td data-label="@lang('Method')">
                                    {{ $customer->name }}
                                </td>
                                <td data-label="@lang('Customer Emial')">
                                    {{ $customer->email }}
                                </td>
                                <td data-label="@lang('Method')">
                                    {{ $customer->phone }}
                                </td>

                                <td data-label="@lang('Method')">
                                    {{ $customer->orders_count }}
                                </td>

                                <td data-label="@lang('REGISTERED AT')">
                                    {{ $customer->created_at->format('d M Y') }}
                                </td>

                                <td>
                                    <div class="btn-group mb-2">
                                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            @lang('Action')
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="{{route('seller.customer.edit',$customer->id)}}">@lang('Edit Account')</a>
                                            <a class="dropdown-item" href="{{route('seller.customer.details',$customer->id)}}">@lang('View User')</a>
                                            @if (getPackage('customer_panel_access') == 1)
                                            <a class="dropdown-item" href="{{route('seller.customer.login',$customer->id)}}">@lang('Login User Panel')</a>
                                            @endif
                                            <a class="dropdown-item" href="{{route('seller.customer.mail',$customer->id)}}">@lang('Send Mail')</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                       
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
