@extends('layouts.seller')
@section('title')
   @lang('Edit Customer')
@endsection

@section('breadcrumb')
 <section class="section">
    <div class="section-header  d-flex justify-content-between">
        <h1>@lang('Edit Customer')</h1>
        <a href="{{route('seller.customer.index')}}" class="btn btn-primary"><i class="fas fa-backward"></i> @lang('Back')</a>
    </div>
</section>
@endsection
@section('content')

<div class="row justify-content-center">
   <div class="col-md-12">
      <!-- Form Basic -->
      <div class="card mb-4">
         <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">{{ __('Edit Customer') }}</h6>
         </div>
         <div class="card-body">
           
            <form action="{{route('seller.customer.update',$customer->id)}}" enctype="multipart/form-data" method="POST">
                @csrf
                @method('PUT')
                
                <div class="form-group">
                    <label>@lang('Customer Name')</label>
                    <input class="form-control" type="text" name="name"  value="{{old('name',$customer->name)}}">
                    @error('name')
                        <span class="text-danger">{{$message}}</span>
                    @enderror
                </div>
                <div class="form-group">
                    <label>@lang('Customer Email')</label>
                    <input class="form-control" type="email" name="email" value="{{old('email',$customer->email)}}">
                    @error('email')
                        <span class="text-danger">{{$message}}</span>
                    @enderror
                </div>
                <div class="form-group">
                    <label>@lang('Customer Password')</label>
                    <input class="form-control" type="password" name="password">
                    @error('password')
                        <span class="text-danger">{{$message}}</span>
                    @enderror
                </div>
                <div class="form-group text-right">
                    <button type="submit" class="btn btn-primary btn-lg">@lang('Submit')</button>
                </div>
            </form>
         </div>
      </div>
   </div>
</div>

@endsection