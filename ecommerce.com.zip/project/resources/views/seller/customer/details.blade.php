@extends('layouts.seller')

@section('title')
    @lang('Manage Customers')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Manage Customers')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">

                    <h5></h5>
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Name'): <b>{{ $customer->name }}</b>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Email'): <b>{{ $customer->email }}</b>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Phone'): <b>{{ $customer->phone }}</b>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Registered At'): <b>{{ $customer->created_at->format('d M Y') }}</b>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Total Orders')
                            <span class="badge badge-info badge-pill">{{ $total_order }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Total Processing Orders')
                            <span class="badge badge-warning badge-pill">{{ $process_order }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Total Complete Orders')
                            <span class="badge badge-success badge-pill">{{ $complete_order }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            @lang('Total Spend Of Amount')
                            <span class="badge badge-primary badge-pill">{{ sellerShowAmount($total_amount) }}</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="table-responsive p-3">
                    <table class="table table-striped">
                        <tr>
                            <th>@lang('Oder Id')</th>
                            <th>@lang('Customer Email')</th>
                            <th>@lang('Method')</th>
                            <th>@lang('Total')</th>
                            <th>@lang('Pay Status')</th>
                            <th>@lang('Status')</th>
                            <th class="text-right">@lang('Action')</th>
                        </tr>
                        @forelse ($customer->orders as $item)
                   <tr>
                        <td data-label="@lang('Method')">
                          {{$item->order_number}}
                        </td>
                        <td data-label="@lang('Customer Emial')">
                           {{$item->email}}
                         </td>
                        <td data-label="@lang('Method')">
                          {{$item->payment_method}}
                        </td>
                      
                        <td data-label="@lang('Amount')">
                           {{sellerShowAmount($item->order_total)}}
                        </td>

                        <td data-label="@lang('Pay Status')">
                           @if ($item->payment_status == 1)
                           <span class="badge badge-success"> @lang('Paid') </span>
                           @else
                           <span class="badge badge-warning"> @lang('Unpaid') </span>
                           @endif
                        </td>
                     
                        <td data-label="@lang('Status')">
                           @if ($item->status == 0)
                           <span class="badge badge-primary"> @lang('Pending') </span>
                           @elseif($item->status == 1)
                           <span class="badge badge-info"> @lang('Processing') </span>
                           @else
                           <span class="badge badge-success"> @lang('Completed') </span>
                           @endif
                        </td>

                        <td data-label="@lang('Action')" class="text-right">
                           <a href="{{route('seller.order.details',$item->id)}}" class="btn btn-primary btn-sm mb-1"><i class="fas fa-eye"></i> @lang('Details')</a>
                        </td>
                   </tr>
                @empty
                   <tr>
                       <td class="text-center" colspan="100%">@lang('No Data Found')</td>
                   </tr>

               @endforelse
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
