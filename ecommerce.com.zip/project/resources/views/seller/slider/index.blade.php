
@extends('layouts.seller')

@section('title')
   @lang('Sliders')
@endsection

@section('breadcrumb')
 <section class="section">
    <div class="section-header d-flex justify-content-between">
        <h1>@lang('Sliders')</h1>
        <a href="{{route('seller.slider.create')}}" class="btn btn-primary"><i class="fas fa-plus"></i> @lang('Create New') </a>
    </div>
</section>
@endsection

@section('content')

<div class="row mt-3">
   <div class="col-lg-12">
      <div class="card mb-4">
         <div class="table-responsive p-3">
            <table class="table table-striped">
                <tr>
                    <th>@lang('Image')</th>
                    <th>@lang('Title')</th>
                    <th>@lang('Text')</th>
                    <th>@lang('Status')</th>
                    <th  class="text-right">@lang('Actions')</th>
                </tr>
                @forelse ($sliders as $item)
                    <tr>
                        <td data-label="@lang('Photo')">
                           <img width="120" src="{{getPhoto($item->photo,seller()->id)}}" alt="">
                        </td>
                         <td data-label="@lang('Title')">
                           {{$item->title	}}
                         </td>
                         <td data-label="@lang('Text')">
                           {{$item->text	}}
                         </td>
                           
                        <td data-label="@lang('Status')">
                           @if ($item->status == 1)
                           <span class="badge badge-success"> @lang('Active') </span>
                           @else
                           <span class="badge badge-warning"> @lang('Inactive') </span>
                           @endif
                        </td>
                        <td data-label="@lang('Action')" class="text-right">
                           <a href="{{route('seller.slider.edit',$item->id)}}" class="btn btn-primary btn-sm edit mb-1" title="@lang('Edit')"><i class="fas fa-edit"></i></a>
                           <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1" data-id="{{$item->id}}"  data-toggle="tooltip" title="@lang('Remove')"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                 @empty

                    <tr>
                        <td class="text-center" colspan="100%">@lang('No Data Found')</td>
                    </tr>

                @endforelse
            </table>
        </div>
      </div>
   </div>
</div>

<!-- Modal -->
<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
   <div class="modal-dialog" role="document">
      <form action="{{route('seller.slider.destroy')}}" method="POST">
         @csrf
         <input type="hidden" name="id">
         <div class="modal-content">
            <div class="modal-body">
               <h5>@lang('Are you sure to remove?')</h5>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
               <button type="submit" class="btn btn-danger">@lang('Confirm')</button>
            </div>
         </div>
      </form>
   </div>
</div>

@endsection

@push('script')
    <script>
       'use strict';
       $('.remove').on('click',function () { 
         $('#removeMod').find('input[name=id]').val($(this).data('id'))
         $('#removeMod').modal('show')
       })
    </script>
@endpush
