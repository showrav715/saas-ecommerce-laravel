@extends('layouts.seller')
@section('title')
   @lang('Edit Slider')
@endsection

@section('breadcrumb')
 <section class="section">
    <div class="section-header d-flex justify-content-between">
        <h1>@lang('Edit Slider')</h1>
        <a href="{{route('seller.slider.index')}}" class="btn btn-primary"><i class="fas fa-backward"></i> @lang('Back') </a>
    </div>
</section>
@endsection
@section('content')

<div class="row justify-content-center">
   <div class="col-md-12">
      <!-- Form Basic -->
      <div class="card mb-4">
         <div class="card-body">
           
            <form action="{{route('seller.slider.update',$data->id)}}" method="POST" enctype="multipart/form-data">
               @csrf
               <div class="col-md-12 ShowImage mb-3  text-center">
                  <img src="{{ getPhoto($data->photo,seller()->id) }}" class="img-fluid" alt="image" width="400">
               </div>
               <div class="form-group">
                  <label for="image">{{ __('Slider Photo') }}</label>
                  <span class="ml-3">{{ __('(Extension:jpeg,jpg,png)') }}</span>
                  <div class="custom-file">
                      <input type="file" class="custom-file-input" name="photo" id="image" accept="image/*">
                      <label class="custom-file-label" for="photo">{{ __('Choose file') }}</label>
                  </div>
              </div>
               <div class="form-group">
                  <label for="inp-name">{{ __('Title') }}</label>
                  <input type="text" class="form-control" id="inp-name" name="title" value="{{$data->title}}">
               </div>
               <div class="form-group">
                  <label for="inp-name">{{ __('Text') }}</label>
                  <input type="text" class="form-control" id="inp-name" name="text" value="{{$data->text}}">
               </div>
               <div class="form-group">
                  <label for="inp-name">{{ __('Button Text') }}</label>
                  <input type="text" class="form-control" id="inp-name" name="btn_text"value="{{$data->btn_text}}">
               </div>
               <div class="form-group">
                  <label for="inp-name">{{ __('Button Link') }}</label>
                  <input type="text" class="form-control" id="inp-name" name="url" value="{{$data->url}}">
               </div>

               <div class="form-group">
                  <label for="inp-name">{{ __('Position') }}</label>
                  <select name="type" class="form-control">
                     <option value="center"{{$data->type == 'center' ? 'selected' : ''}}>{{ __('Center') }}</option>
                     <option value="left"  {{$data->type == 'left' ? 'selected' : ''}}>{{ __('Left') }}</option>
                     <option value="right" {{$data->type == 'right' ? 'selected' : ''}}>{{ __('Right') }}</option>
                  </select>
               </div>

               <div class="form-group">
                  <label for="inp-name">{{ __('Status') }}</label>
                  <select name="status" class="form-control">
                     <option value="1" {{$data->status == 1 ? 'selected' : '' }}>{{ __('Active') }}</option>
                     <option value="0" {{$data->status == 0 ? 'selected' : '' }}>{{ __('Inactive') }}</option>
                  </select>
               </div>

         
         
               <button type="submit"  class="btn btn-primary">{{ __('Submit') }}</button>
            </form>
         </div>
      </div>
      <!-- Form Sizing -->
      <!-- Horizontal Form -->
   </div>
</div>
<!--Row-->
@endsection