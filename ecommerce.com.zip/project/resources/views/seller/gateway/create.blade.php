@extends('layouts.seller')
@section('title')
    @lang('Add Payment Gateway')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1>@lang('Add Payment Gateway')</h1>
            <a href="{{ route('seller.payment.method.index') }}" class="btn btn-primary"><i class="fas fa-backward"></i>
                @lang('Back') </a>
        </div>
    </section>
@endsection
@section('content')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">

                    <form action="{{route('seller.payment.method.store')}}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="title">{{ __('Name') }}</label>
                            <input type="text" class="form-control" id="title" name="title"
                                placeholder="{{ __('Enter Title') }}" value="" required>
                        </div>

                        <div class="form-group">
                            <label for="subtitle">{{ __('Subtitle') }}</label>
                            <input type="text" class="form-control" id="subtitle" name="subtitle"
                                placeholder="{{ __('Enter Subtitle') }}" value="" required>
                        </div>

                        <div class="form-group">
                            <label for="details">{{ __('Description') }}</label>
                            <textarea name="details" class="form-control" id="details"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="status">{{ __('Status') }}</label>
                            <select name="status" class="form-control" id="status">
                                <option value="1">@lang('Active')</option>
                                <option value="0">@lang('Inactive')</option>
                            </select>
                        </div>

                        <button type="submit" id="submit-btn" class="btn btn-primary">{{ __('Submit') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
