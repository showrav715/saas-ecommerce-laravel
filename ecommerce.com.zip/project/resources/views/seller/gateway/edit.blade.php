@extends('layouts.seller')
@section('title')
    @lang('Edit Payment Gateway')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1>@lang('Edit Payment Gateway')</h1>
            <a href="{{ route('seller.payment.method.index') }}" class="btn btn-primary"><i class="fas fa-backward"></i>
                @lang('Back') </a>
        </div>
    </section>
@endsection
@section('content')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">

                    <form action="{{ route('seller.payment.method.update', $data->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        @if ($data->type == 'automatic')

                            <div class="form-group">
                                <label for="inp-name">{{ __('Title') }}</label>
                                <input type="text" class="form-control" id="inp-name" name="title"
                                    placeholder="{{ __('Enter Title') }}" value="{{ $data->name }}" required>
                            </div>

                            @if ($data->information != null)
                                @foreach ($data->convertAutoData() as $pkey => $pdata)
                                    @if ($pkey == 'sandbox_check')
                                        <div class="form-group">
                                            <label>{{ __($data->name . ' ' . ucwords(str_replace('_', ' ', $pkey))) }}
                                                *</label>
                                            <input type="checkbox" class="form-control" name="pkey[{{ __($pkey) }}]"
                                                value="1" {{ $pdata == 1 ? 'checked' : '' }}>
                                        </div>
                                    @else
                                        <div class="form-group">
                                            <label
                                                for="inp-name">{{ __($data->name . ' ' . ucwords(str_replace('_', ' ', $pkey))) }}
                                                *</label>
                                            <input type="text" class="form-control" name="pkey[{{ __($pkey) }}]"
                                                placeholder="{{ __($data->name . ' ' . ucwords(str_replace('_', ' ', $pkey))) }}"
                                                value="{{ $pdata }}" required="">
                                        </div>
                                    @endif
                                @endforeach

                                <div class="form-group">
                                    <label>@lang('Currency')</label>
                                    <select name="currency_id[]" class="select2" multiple id="">
                                        @foreach ($currencies as $currency)
                                            <option value="{{ $currency->id }}" {{in_array($currency->id,explode(',',$data->currency_id)) ? 'selected' : ''}} >{{ $currency->code }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif
                        @else
                            <div class="form-group">
                                <label for="title">{{ __('Name') }}</label>
                                <input type="text" class="form-control" id="title" name="title"
                                    placeholder="{{ __('Enter Title') }}" value="{{ $data->title }}" required>
                            </div>

                            <div class="form-group">
                                <label for="subtitle">{{ __('Subtitle') }}</label>
                                <input type="text" class="form-control" id="subtitle" name="subtitle"
                                    placeholder="{{ __('Enter Subtitle') }}" value="{{ $data->subtitle }}" required>
                            </div>

                            <div class="form-group">
                                <label for="details">{{ __('Description') }}</label>
                                <textarea name="details" class="form-control" id="details">{{ $data->details }}</textarea>
                            </div>
                        @endif

                        <div class="form-group">
                            <label for="status">{{ __('Status') }}</label>
                            <select name="status" class="form-control" id="status">
                                <option value="1" {{$data->status == 1 ? 'selected' : ''}} >@lang('Active')</option>
                                <option value="0" {{$data->status == 0 ? 'selected' : ''}}>@lang('Inactive')</option>
                            </select>
                        </div>

                        <button type="submit" id="submit-btn" class="btn btn-primary">{{ __('Submit') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
