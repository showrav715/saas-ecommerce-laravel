@extends('layouts.seller')

@section('title')
    @lang('Payment gateway')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Payment Gateway')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-end">
                    <a href="{{ route('seller.payment.method.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> @lang('Add New')
                    </a>
                </div>
                <div class="table-responsive p-3">
                    <table class="table table-striped">
                        <tr>
                            <th width="20%">{{ __('Name') }}</th>
                            <th width="30%">{{ __('Details') }}</th>
                            <th width="30%">{{ __('Status') }}</th>
                            <th class="text-right">@lang('Action')</th>
                        </tr>
                        @forelse ($gatewayes as $data)
                            <tr>
                                <td data-label="@lang('Code')">
                                    @if ($data->type == 'automatic')
                                        {{ $data->name }}
                                    @else
                                        {{ $data->title }}
                                    @endif
                                </td>
                                <td data-label="@lang('Expired Date')">
                                    @if ($data->type == 'automatic')
                                        {{ $data->getAutoDataText() }}
                                    @else
                                        @if ($data->keyword == 'cod')
                                            {{ $data->subtitle }}
                                        @else
                                            @php
                                                $details = mb_strlen(strip_tags($data->details), 'utf-8') > 250 ? mb_substr(strip_tags($data->details), 0, 250, 'utf-8') . '...' : strip_tags($data->details);
                                            @endphp
                                            {{ $details }}
                                        @endif
                                    @endif
                                </td>

                                <td>
                                    @if ($data->status == 1)
                                        <span class="badge badge-success">@lang('Active')</span>
                                    @else
                                        <span class="badge badge-danger">@lang('Inactive')</span>
                                    @endif
                                </td>

                                <td data-label="@lang('Action')" class="text-right">
                                    <a href="{{ route('seller.payment.method.edit', $data->id) }}"
                                        class="btn btn-primary btn-sm edit mb-1" data-toggle="tooltip"
                                        title="@lang('Edit')"><i class="fas fa-edit"></i></a>
                                    @if ($data->type == 'manual' && $data->keyword != 'cod')
                                        <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                            data-id="{{ $data->id }}" data-toggle="tooltip"
                                            title="@lang('Remove')"><i class="fas fa-trash"></i></a>
                                    @endif

                                </td>
                            </tr>
                        @empty

                            <tr>
                                <td class="text-center" colspan="100%">@lang('No Data Found')</td>
                            </tr>
                        @endforelse
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="{{ route('seller.payment.method.delete') }}" method="POST">
                @method('DELETE')
                @csrf
                <input type="hidden" name="id">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5>@lang('Are you sure to remove?')</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                        <button type="submit" class="btn btn-danger">@lang('Confirm')</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('script')
    <script>
        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
    </script>
@endpush
