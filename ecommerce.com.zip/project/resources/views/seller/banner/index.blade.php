@extends('layouts.seller')

@section('title')
   @lang('Banners')
@endsection

@section('breadcrumb')
 <section class="section">
    <div class="section-header">
        <h1>@lang('Banners')</h1>
    </div>
</section>
@endsection

@section('content')
<div class="row">
   <div class="col-lg-12">
      <div class="card mb-4">
         <div class="table-responsive p-3">
            <table class="table table-striped">
               <tr>
                   <th>@lang('Banner')</th>
                   <th>@lang('Header')</th>
                   <th>@lang('Title')</th>
                   <th>@lang('Subtile')</th>
                   <th class="text-right">@lang('Action')</th>
               </tr>
               @forelse ($banners as $item)
                   <tr>
                        <td data-label="@lang('Header')">
                          <img width="120" src="{{getPhoto($item->photo,auth()->id())}}" alt="">
                        </td>
                        <td data-label="@lang('Title')">
                          {{$item->header}}
                        </td>
                        <td data-label="@lang('Text')">
                          {{$item->title}}
                        </td>
                        <td data-label="@lang('Subtile')">
                           {{$item->subtitle}}
                        </td>
                        <td data-label="@lang('Action')" class="text-right">
                           <a href="javascript:void()" class="btn btn-primary approve btn-sm edit mb-1" data-route="{{route('seller.banner.update',$item->id)}}" data-item="{{$item}}" data-path="{{sellerpath()}}" data-toggle="tooltip" title="@lang('Edit')"><i class="fas fa-edit"></i></a>
                        </td>
                   </tr>
                @empty
                   <tr>
                       <td class="text-center" colspan="100%">@lang('No Data Found')</td>
                   </tr>
               @endforelse
           </table>
         </div>
      </div>
   </div>
</div>


<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
       <form action="" method="POST" enctype="multipart/form-data">
          @csrf
          @method('PUT')
          <div class="modal-content">
             <div class="modal-header">
                <h5 class="modal-title">@lang('Edit Banner')</h5>
                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                   </button>
             </div>
             <div class="modal-body">
               <div class="form-group">
                  <label>@lang('Feature Photo')</label>
                  <div class="form-group d-flex justify-content-center">
                     <div id="image-preview" class="image-preview image-preview_alt"
                         style="">
                         <label for="image-upload" id="image-labe">@lang('Choose File')</label>
                         <input type="file" name="photo" id="image-upload" />
                     </div>
                  </div>
               </div>
                <div class="form-group">
                   <label>@lang('Header')</label>
                   <input class="form-control" type="text" name="header">
                </div>
                <div class="form-group">
                   <label>@lang('Title')</label>
                   <input class="form-control" type="text" name="title">
                </div>
                <div class="form-group">
                   <label>@lang('Subtitle')</label>
                   <input class="form-control" type="text" name="subtitle">
                </div>
                <div class="form-group">
                   <label>@lang('Link')</label>
                   <input class="form-control" type="text" name="link">
                </div>
             </div>
             <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                <button type="submit" class="btn btn-primary">@lang('Submit')</button>
             </div>
          </div>
       </form>
    </div>
 </div>


@endsection

@push('script')
    <script>
       'use strict';

       $.uploadPreview({
                input_field: "#image-upload",
                preview_box: "#image-preview",
                label_field: "#image-label",
                label_default: "{{__('Choose File')}}",
                label_selected: "{{__('Update Image')}}",
                no_label: false,
                success_callback: null
            });

        $('.edit').on('click',function () { 
            var data = $(this).data('item')
            $('#edit').find('input[name=header]').val(data.header)
            $('#edit').find('input[name=title]').val(data.title)
            $('#edit').find('input[name=subtitle]').val(data.subtitle)
            $('#edit').find('input[name=link]').val(data.link)
            let path = $(this).attr('data-path');
          $('#edit').find('#image-preview').css('background-image', `url('${path}/${data.photo}')`);
            $('#edit').find('form').attr('action',$(this).data('route'))
            $('#edit').modal('show')
        })

      
    </script>
@endpush

