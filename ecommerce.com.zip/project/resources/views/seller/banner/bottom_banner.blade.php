
@extends('layouts.seller')
@section('breadcrumb')
 <section class="section">
        <div class="section-header">
        <h1>@lang('Bottom Banner')</h1>
        </div>
</section>
@endsection
@section('title')
   @lang('Bottom Banner')
@endsection
@section('content')

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
               <h6 class="text-primary"> @lang('Bottom Banner')</h6>
            </div>
            <div class="card-body">
              <form  action="{{ route('seller.bottom-banner.update',auth()->id()) }}" enctype="multipart/form-data" method="POST">
                @csrf
                @method('PUT')
                 <div class="form-group d-flex justify-content-center">
                    <div id="image-preview" 
                     class="image-preview image-preview-990 image-preview_alt"
                        style="background-image:url({{ @getPhoto($banner->photo,auth()->id()) }});">
                        <label for="image-upload" id="image-label">@lang('Choose File')</label>
                        <input type="file" name="photo" id="image-upload" />
                    </div>
                 </div>
                 <div class="form-group">
                    <label>@lang('Title')</label>
                    <input class="form-control" type="text" name="title" value="{{@$banner->title}}">
                 </div>
                 <div class="form-group">
                    <label>@lang('Text')</label>
                    <input class="form-control" type="text" name="text" value="{{@$banner->text}}">
                 </div>
                 <div class="form-group">
                    <label>@lang('Button Text')</label>
                    <input class="form-control" type="text" name="btn_text" value="{{@$banner->btn_text}}">
                 </div>
                 <div class="form-group">
                    <label>@lang('Button Link')</label>
                    <input class="form-control" type="text" name="btn_link" value="{{@$banner->btn_link}}">
                 </div>
                   <div class="form-group row">
                    <div class="col-sm-12 text-center">
                      <button type="submit" class="btn btn-primary btn-block">{{ __('Update') }}</button>
                    </div>
                  </div>
              </form>
            </div>
        </div>
    </div>

</div>



@endsection

@push('script')
    <script>
      'use strict';
      $.uploadPreview({
                input_field: "#image-upload", // Default: .image-upload
                preview_box: "#image-preview", // Default: .image-preview
                label_field: "#image-label", // Default: .image-label
                label_default: "{{__('Choose File')}}", // Default: Choose File
                label_selected: "{{__('Update Image')}}", // Default: Change File
                no_label: false, // Default: false
                success_callback: null // Default: null
            });
    </script>
@endpush