@extends('layouts.seller')
@section('title')
    @lang('Seller Dashboard')
@endsection
@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Dashboard')</h1>
        </div>
    </section>
@endsection
@section('content')

    <div class="row">
        <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>@lang('Total Earning')</h4>
                    </div>
                    <div class="card-body">
                        {{sellerShowAmount($total_sales)}}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>@lang('Total Orders')</h4>
                    </div>
                    <div class="card-body">
                        {{$total_orders}}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="fas fa-coins"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>@lang('Total Users')</h4>
                    </div>
                    <div class="card-body">
                        {{$total_customers}}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 col-12">
            <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                    <i class="fas fa-globe"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                        <h4>@lang('Total Products')</h4>
                    </div>
                    <div class="card-body">
                        {{$total_products}}
                    </div>
                </div>
            </div>
        </div>


    </div>

    <div class="row">
        <div class="col-12 col-xl-9">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4>@lang('Recent Orders')</h4>
                        </div>
                        <div class="table-responsive p-3">
                            <table class="table table-striped">
                                <tr>
                                    <th>@lang('Oder Id')</th>
                                    <th>@lang('Customer Email')</th>
                                    <th>@lang('Method')</th>
                                    <th>@lang('Total')</th>
                                    <th>@lang('Pay Status')</th>
                                    <th>@lang('Status')</th>
                                    <th class="text-right">@lang('Action')</th>
                                </tr>
                                @forelse ($recent_orders as $item)
                                    <tr>
                                        <td data-label="@lang('Method')">
                                            {{ $item->order_number }}
                                        </td>
                                        <td data-label="@lang('Customer Emial')">
                                            {{ $item->email }}
                                        </td>
                                        <td data-label="@lang('Method')">
                                            {{ $item->payment_method }}
                                        </td>

                                        <td data-label="@lang('Amount')">
                                            {{ sellerShowAmount($item->order_total) }}
                                        </td>

                                        <td data-label="@lang('Pay Status')">
                                            @if ($item->payment_status == 1)
                                                <span class="badge badge-success"> @lang('Paid') </span>
                                            @else
                                                <span class="badge badge-warning"> @lang('Unpaid') </span>
                                            @endif
                                        </td>

                                        <td data-label="@lang('Status')">
                                            @if ($item->status == 0)
                                                <span class="badge badge-primary"> @lang('Pending') </span>
                                            @elseif($item->status == 1)
                                                <span class="badge badge-info"> @lang('Processing') </span>
                                            @else
                                                <span class="badge badge-success"> @lang('Completed') </span>
                                            @endif
                                        </td>

                                        <td data-label="@lang('Action')" class="text-right">
                                            <a href="{{ route('seller.order.details', $item->id) }}"
                                                class="btn btn-primary btn-sm mb-1"><i class="fas fa-eye"></i>
                                                @lang('Details')</a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td class="text-center" colspan="100%">@lang('No Data Found')</td>
                                    </tr>
                                @endforelse
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h4>@lang('Recent Customers')</h4>
                        </div>
                        <div class="table-responsive p-3">
                            <table class="table table-striped">
                                <tr>
                                    <th>@lang('Name')</th>
                                    <th>@lang('Email')</th>
                                    <th>@lang('Phone')</th>
                                    <th>@lang('Total Orders')</th>
                                    <th>@lang('Created at')</th>
                                    <th>@lang('Action')</th>
                                </tr>
                                @forelse ($recent_customers as $customer)
                                    <tr>
                                        <td data-label="@lang('Method')">
                                            {{ $customer->name }}
                                        </td>
                                        <td data-label="@lang('Customer Emial')">
                                            {{ $customer->email }}
                                        </td>
                                        <td data-label="@lang('Method')">
                                            {{ $customer->phone }}
                                        </td>
        
                                        <td data-label="@lang('Method')">
                                            {{ $customer->orders_count }}
                                        </td>
        
                                        <td data-label="@lang('REGISTERED AT')">
                                            {{ $customer->created_at->format('d M Y') }}
                                        </td>
        
                                        <td>
                                            <div class="btn-group mb-2">
                                                <button class="btn btn-primary btn-sm dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    @lang('Action')
                                                </button>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="{{route('seller.customer.edit',$customer->id)}}">@lang('Edit Account')</a>
                                                    <a class="dropdown-item" href="{{route('seller.customer.details',$customer->id)}}">@lang('View User')</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td class="text-center" colspan="100%">@lang('No Data Found')</td>
                                    </tr>
                                @endforelse
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

   
        <div class="col-12 col-xl-3">
            <div class="row">
                <div class="col-12">
                    <div class="card ">
                        <div class="card-header">
                            <h4 class="card-header-title plan_name">{{ $domain_info['name'] }}</h4>
                            <span
                                class="badge badge-soft-secondary plan_expire">{{ dateFormat($domain->will_expire) }}</span>
                            <img src="https://bigbag.dukans.xyz/uploads/loader.gif" class="plan_load"
                                style="display: none;">
                        </div>
                        <div class="card-header">
                            <h4 class="card-header-title">@lang('Categories')</h4>
                            <span class="badge badge-soft-secondary"
                                id="storage_used">{{ Auth::user()->categories->count() }} /
                                {{ $domain_info['category_limit'] }}</span>
                        </div>
                        <div class="card-header">
                            <h4 class="card-header-title">@lang('Brands')</h4>
                            <span class="badge badge-soft-secondary" id="storage_used">{{ Auth::user()->brands->count() }} /
                                {{ $domain_info['brand_limit'] }}</span>
                        </div>
                        <div class="card-header">
                            <h4 class="card-header-title">@lang('Products')</h4>
                            <span class="badge badge-soft-secondary"
                                id="storage_used">{{ Auth::user()->products->count() }}
                                / {{ $domain_info['product_limit'] }}</span>
                        </div>

                        <div class="card-header">
                            <h4 class="card-header-title">@lang('Customers')</h4>
                            <span class="badge badge-soft-secondary posts_used">{{ Auth::user()->users->count() }} /
                                {{ $domain_info['customer_limit'] }}</span>
                        </div>
                    </div>
                </div>
            </div>
            @if (getPackage('qr_code') == 1)
            <div class="row">
                <div class="col-12">
                    <div class="card text-center">
                        <img src="{{asset('assets/qrcode/'.auth()->id().Str::slug(auth()->user()->name).'.png')}}" alt="">
                        <h4 class="mt-3">@lang('Scan this QR code to visit your store')</h4>
                        <a href="{{asset('assets/qrcode/'.auth()->id().Str::slug(auth()->user()->name).'.png')}}" download="" class="btn btn-primary m-2"><i class="fas fa-download"></i> @lang('Download')</a>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
@endsection


