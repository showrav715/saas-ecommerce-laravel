@extends('layouts.seller')

@section('title')
    @lang('Order Details')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Order Details')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row" id="order">
        <div class="col-12 col-lg-8">
            <div class="card card-info">
                <div class="card-body">
                    <ul class="list-group list-group-lg list-group-flush list">
                        <li class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col-6">
                                    <strong>@lang('Product')</strong>
                                </div>
                                <div class="col-3 text-right">
                                    <strong>@lang('Amount')</strong>
                                </div>
                                <div class="col-3 text-right">
                                    <strong>@lang('Total')</strong>
                                </div>
                            </div>
                        </li>
                        @foreach (json_decode($order->cart, true) as $item)
                            <li class="list-group-item">
                                <div class="row align-items-center">
                                    <div class="col-6">
                                        <b>{{ $item['name'] }}</b>
                                    </div>
                                    <div class="col-3 text-right">
                                        {{ sellerShowAmount($item['cart_item_price']) }} × {{ $item['quantity'] }}
                                    </div>
                                    <div class="col-3 text-right">
                                        {{ sellerShowAmount($item['cart_item_price'] * $item['quantity']) }}
                                    </div>
                                </div>
                            </li>
                        @endforeach
                        @php
                            $shipping = json_decode($order->shipping, true);
                        @endphp
                        <br>
                        <li class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col-6">
                                    {{ $shipping['shipping']['shipping'] }} ({{ $shipping['location']['location'] }})
                                </div>
                                <div class="col-3 text-right">
                                    @lang('Shipping Fee')
                                </div>
                                <div class="col-3 text-right">
                                    {{ sellerShowAmount($shipping['shipping']['price']) }}
                                </div>
                            </div>
                        </li>
                        @php
                            $discount = json_decode($order->discount, true);
                            
                        @endphp
                        <li class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col-9 text-right">@lang('Discount')</div>
                                <div class="col-3 text-right"> {{ @sellerShowAmount($discount['discount']) }}</div>
                            </div>
                        </li>


                        <li class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col-9 text-right">@lang('Total')</div>
                                <div class="col-3 text-right">{{ sellerShowAmount($order->order_total) }}</div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="card-footer">
                    <form method="POST" action="{{ route('seller.order.update', $order->id) }}" class="d-inline">
                        <div class="text-right">
                            @csrf

                            <div class="btn-group mx-2">
                                <div class="form-check">
                                    <input class="form-check-input" name="notify_mail" type="checkbox" id="notify_mail">
                                    <label class="form-check-label" for="notify_mail">
                                        @lang('Notify via Mail')
                                    </label>
                                </div>
                            </div>
                            
                            <div class="btn-group">
                                <select class="form-control" name="payment_status">
                                    <option disabled="">@lang('Payment Status')</option>
                                    <option value="0" {{ $order->payment_status == 0 ? 'selected' : '' }}>
                                        @lang('Unpaid')</option>
                                    <option value="1" {{ $order->payment_status == 1 ? 'selected' : '' }}>
                                        @lang('Paid')</option>
                                </select>
                            </div>
                            <div class="btn-group">
                                <select class="form-control" name="order_status">
                                    <option disabled="">@lang('Order Status')</option>
                                    <option value="0" {{ $order->order_status == 0 ? 'selected' : '' }}>
                                        @lang('Pending')</option>
                                    <option value="1" {{ $order->order_status == 1 ? 'selected' : '' }}>
                                        @lang('Processing')</option>
                                    <option value="2" {{ $order->order_status == 2 ? 'selected' : '' }}>
                                        @lang('Completed')</option>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary float-right mt-2 ml-2 ">@lang('Save Changes')</button>
                    </form>

                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4">
            <div class="card-grouping">
                <div class="card">
                    <div class="card-header">
                        <h4>@lang('Status')</h4>
                    </div>
                    <div class="card-body">
                        <p>@lang('Payment Status')
                            @if ($order->payment_status == 0)
                                <span class="badge badge-danger float-right">@lang('Unpaid')</span>
                            @else
                                <span class="badge badge-success float-right">@lang('Paid')</span>
                            @endif
                        </p>
                        <p>@lang('Order Status')
                            @if ($order->order_status == 0)
                                <span class="badge badge-primary float-right">@lang('Pending')</span>
                            @elseif($order->order_status == 1)
                                <span class="badge badge-info float-right">@lang('Processing')</span>
                            @else
                                <span class="badge badge-success float-right">@lang('Completed')</span>
                            @endif
                        </p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4>@lang('Payment Mode')</h4>
                    </div>
                    <div class="card-body">
                        <p>@lang('Transaction Method') <span class="badge  badge-success  float-right">{{ $order->payment_method }}
                            </span></p>
                        <p>@lang('Transaction Id') <span class="float-right">{{ $order->txn_id }}</span></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-header-title">@lang('Note')</h4>
                    </div>
                    <div class="card-body">
                        <p class="mb-0">{{ $order->note }}</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-header-title">@lang('Customer')</h4>
                    </div>
                    <div class="card-body">
                        <p class="mb-0">@lang('Name'): {{ $order->user->name }}</p>
                        <p class="mb-0">@lang('Email'): {{ $order->user->email }}</p>
                        <p class="mb-0">@lang('Phone'): {{ $order->user->phone }}</p>
                        <a href="{{route('seller.customer.details',$order->user->id)}}">@lang('View Profile')</a>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-header-title">@lang('Shipping details')</h4>
                    </div>
                    <div class="card-body">
                        <p class="mb-0">@lang('Customer Name'): {{ $order->name }}</p>
                        <p class="mb-0">@lang('Customer Email'): {{ $order->email }}</p>
                        <p class="mb-0">@lang('Customer Phone'): {{ $order->phone }}</p>
                        <p class="mb-0">@lang('Zip Code'): {{ $order->zip }}</p>
                       
                        
                        @php
                            $location = json_decode($order->shipping,true)['location'];
                            $shipping = json_decode($order->shipping,true)['shipping'];
                        @endphp
                        <p class="mb-0">@lang('Location'): <b>{{ $location['location'] }}</b></p>
                        <p class="mb-0">@lang('Customer Delivery Address'): <b>{{ $order->delivery_address }}</b></p>
                        <p class="mb-0">@lang('Shipping'): {{ $shipping['shipping'] }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
