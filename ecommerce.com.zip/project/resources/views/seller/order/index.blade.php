@extends('layouts.seller')

@section('title')
   @lang('Manage Orders')
@endsection

@section('breadcrumb')
 <section class="section">
    <div class="section-header">
        <h1>@lang('Manage Orders')</h1>
    </div>
</section>
@endsection

@section('content')


<div class="row">
   <div class="col-lg-12">
      <div class="card mb-4">
         <div class="table-responsive p-3">
            <table class="table table-striped" id="table">
               <thead>
                  <tr>
                     <th>@lang('Oder Id')</th>
                     <th>@lang('Customer Email')</th>
                   <th>@lang('Method')</th>
                   <th>@lang('Total')</th>
                   <th>@lang('Pay Status')</th>
                   <th>@lang('Status')</th>
                   <th class="text-right">@lang('Action')</th>
               </tr>
               </thead>
               
               <tbody>
                  @foreach ($orders as $item)
                   <tr>
                        <td data-label="@lang('Method')">
                          {{$item->order_number}}
                        </td>
                        <td data-label="@lang('Customer Emial')">
                           {{$item->email}}
                         </td>
                        <td data-label="@lang('Method')">
                          {{$item->payment_method}}
                        </td>
                      
                        <td data-label="@lang('Amount')">
                           {{sellerShowAmount($item->order_total)}}
                        </td>

                        <td data-label="@lang('Pay Status')">
                           @if ($item->payment_status == 1)
                           <span class="badge badge-success"> @lang('Paid') </span>
                           @else
                           <span class="badge badge-warning"> @lang('Unpaid') </span>
                           @endif
                        </td>
                     
                        <td data-label="@lang('Status')">
                           @if ($item->status == 0)
                           <span class="badge badge-primary"> @lang('Pending') </span>
                           @elseif($item->status == 1)
                           <span class="badge badge-info"> @lang('Processing') </span>
                           @else
                           <span class="badge badge-success"> @lang('Completed') </span>
                           @endif
                        </td>

                        <td data-label="@lang('Action')" class="text-right">
                           <a href="{{route('seller.order.details',$item->id)}}" class="btn btn-primary btn-sm mb-1"><i class="fas fa-eye"></i> @lang('Details')</a>
                        </td>
                   </tr>
           
               @endforeach
               </tbody>
           </table>
         </div>
      </div>
   </div>
</div>



@endsection

