<aside id="sidebar-wrapper">

    <ul class="sidebar-menu mb-5">
        <li class="menu-header">@lang('Dashboard')</li>
        <li class="nav-item {{ menu('admin.dashboard') }}">
            <a href="{{ route('seller.dashboard') }}" class="nav-link"><i
                    class="fas fa-fire"></i><span>@lang('Dashboard')</span></a>
        </li>

        <li class="menu-header">@lang('Products')</li>
        <li class="nav-item dropdown {{ menu(['seller.category.*']) }}">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fab fa-product-hunt"></i><span>@lang('Products')</span></a>
            <ul class="dropdown-menu">
                <li class="{{ menu('seller.category.index') }}"><a class="nav-link"
                        href="{{ route('seller.brand.index') }}">@lang('Brand')</a></li>
                <li class="{{ menu('seller.category.index') }}"><a class="nav-link"
                        href="{{ route('seller.category.index') }}">@lang('Category')</a></li>
                <li class="{{ menu('seller.attribute.index') }}"><a class="nav-link"
                        href="{{ route('seller.attribute.index') }}">@lang('Attributes')</a></li>
                <li class="{{ menu('seller.color.index') }}"><a class="nav-link"
                        href="{{ route('seller.color.index') }}">@lang('Colors')</a></li>
                <li class="{{ menu('seller.product.index') }}"><a class="nav-link"
                        href="{{ route('seller.product.index') }}">@lang('Products')</a></li>
            </ul>
        </li>

        <li class="nav-item {{ menu('seller.coupon.index') }}">
            <a href="{{ route('seller.coupon.index') }}" class="nav-link">
                <i class="fas fa-percentage"></i><span>@lang('Coupons')</span></a>
        </li>
        <li class="nav-item {{ menu('seller.customer.index') }}">
            <a href="{{ route('seller.customer.index') }}" class="nav-link">
                <i class="fas fa-users"></i><span>@lang('Customers')</span></a>
        </li>

        @if (getPackage('support') == 1)
            <li class="nav-item {{ menu('seller.ticket.index') }}">
                <a href="{{ route('seller.ticket.index') }}" class="nav-link">
                    <i class="fas fa-envelope"></i><span>@lang('Online Support')</span></a>
            </li>
        @endif


        <li class="nav-item {{ menu('seller.order.index') }}">
            <a href="{{ route('seller.order.index') }}" class="nav-link">
                <i class="fab fa-first-order"></i><span>@lang('Manage Orders')</span></a>
        </li>


        <li class="nav-item {{ menu('seller.domain.setting') }}">
            <a href="{{ route('seller.domain.setting') }}" class="nav-link">
                <i class="fab fa-first-order"></i><span>@lang('Domain Setting')</span></a>
        </li>

        <li class="nav-item {{ menu('seller.contact.messages') }}">
            <a href="{{ route('seller.contact.messages') }}" class="nav-link"><i
                    class="fas fa-envelope"></i><span>@lang('Contact Messages')</span></a>
        </li>

        <li class="nav-item dropdown {{ menu(['seller.payment.*']) }}">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown">
                <i class="fas fa-money-bill-wave"></i><span>@lang('Payment Settings')</span></a>
            <ul class="dropdown-menu">
                <li class="{{ menu('seller.currency.index') }}"><a class="nav-link"
                        href="{{ route('seller.currency.index') }}">@lang('Currency')</a></li>
                <li class="{{ menu('seller.location.index') }}"><a class="nav-link"
                        href="{{ route('seller.payment.method.index') }}">@lang('Payment Gateway')</a></li>
            </ul>
        </li>

        <li class="nav-item dropdown {{ menu(['seller.shipping.*']) }}">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fab fa-product-hunt"></i><span>@lang('Shipping')</span></a>
            <ul class="dropdown-menu">
                <li class="{{ menu('seller.location.index') }}"><a class="nav-link"
                        href="{{ route('seller.location.index') }}">@lang('Locations')</a></li>
                <li class="{{ menu('seller.location.index') }}"><a class="nav-link"
                        href="{{ route('seller.shipping.index') }}">@lang('Shipping')</a></li>
            </ul>
        </li>

        <li class="menu-header">@lang('General')</li>
        <li class="nav-item dropdown {{ menu(['seller.gs*', 'seller.cookie']) }}">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fas fa-cog"></i><span>@lang('General Settings')</span></a>
            <ul class="dropdown-menu">
                <li class="{{ menu('seller.gs.site.settings') }}"><a class="nav-link"
                        href="{{ route('seller.gs.site.settings') }}">@lang('Site Settings')</a></li>
                <li class="{{ menu('seller.gs.logo') }}"><a class="nav-link"
                        href="{{ route('seller.gs.logo') }}">@lang('Logo & Favicon')</a></li>
                <li class="{{ menu('seller.gs.other.settings') }}"><a class="nav-link"
                        href="{{ route('seller.gs.other.settings') }}">@lang('Other Setting')</a></li>
                <li class="{{ menu('seller.subscription.index') }}"><a class="nav-link"
                        href="{{ route('seller.subscription.index') }}">@lang('Subscription')</a></li>
                <li class="{{ menu('seller.language.index') }}"><a class="nav-link"
                        href="{{ route('seller.language.index') }}">@lang('Language')</a></li>
                @if (getPackage('facebook_pixel') == 1)
                    <li class="{{ menu('seller.gs.facebookPixel') }}"><a class="nav-link" href="{{ route('seller.gs.facebookPixel') }}">@lang('Facebook Pixel')</a>
                    </li>
                @endif
                @if (getPackage('google_analytics') == 1)
                    <li class="{{ menu('seller.gs.google_analytics') }}"><a class="nav-link" href="{{ route('seller.gs.google_analytics') }}">@lang('Google Analytics')</a></li>
                @endif
            </ul>
        </li>


        <li class="nav-item dropdown {{ menu(['seller.shipping.*']) }}">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fas fa-cog"></i><span>@lang('Site Settings')</span></a>
            <ul class="dropdown-menu">
                <li class="{{ menu('seller.slider.index') }}"><a class="nav-link"
                        href="{{ route('seller.slider.index') }}">@lang('Sliders')</a></li>
                <li class="{{ menu('seller.page.index') }}"><a class="nav-link"
                        href="{{ route('seller.page.index') }}">@lang('Pages')</a></li>
                <li class="{{ menu('seller.bcategory.index') }}"><a class="nav-link"
                        href="{{ route('seller.bcategory.index') }}">@lang('Blog Category')</a></li>
                <li class="{{ menu('seller.blog.index') }}"><a class="nav-link"
                        href="{{ route('seller.blog.index') }}">@lang('Blogs')</a></li>
                <li class="{{ menu('seller.service.index') }}"><a class="nav-link"
                        href="{{ route('seller.service.index') }}">@lang('Services')</a></li>
                <li class="{{ menu('seller.banner.index') }}"><a class="nav-link"
                        href="{{ route('seller.banner.index') }}">@lang('Banners')</a></li>
                <li class="{{ menu('seller.bottom-banner.index') }}"><a class="nav-link"
                        href="{{ route('seller.bottom-banner.index') }}">@lang('Bottom Banner')</a></li>
                <li class="{{ menu('seller.contact.page.index') }}"><a class="nav-link"
                        href="{{ route('seller.contact.page.index') }}">@lang('Contact Page')</a></li>
            </ul>
        </li>


    </ul>
</aside>
