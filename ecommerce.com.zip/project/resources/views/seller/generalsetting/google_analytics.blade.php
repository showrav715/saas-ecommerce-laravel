@extends('layouts.seller')
@section('title')
    @lang('Google Analytics')
@endsection
@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Google Analytics')</h1>
        </div>
    </section>
@endsection
@section('title')
    @lang('Google Analytics')
@endsection

@section('content')
    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h6>@lang('Google Analytics')</h6>
                </div>
                <div class="card-body">

                    <form action="{{ route('seller.gs.update') }}" enctype="multipart/form-data" method="POST">
                        @csrf
                        <input type="hidden" value="1" name="google_form">
                        @include('admin.partials.form-both')

                        <div class="form-group row mb-3">
                            <label for="google_analytics" class="col-sm-3 col-form-label">{{ __('Google Analytics ID') }}</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="google_analytics" name="google_analytics"
                                    placeholder="{{ __('Google Analytics ID') }}" value="{{ $gs->google_analytics }}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12 text-right">
                                <button type="submit" class="btn btn-primary">{{ __('Update Settings') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
@endsection
