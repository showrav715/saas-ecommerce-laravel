@extends('layouts.seller')

@section('title')
    @lang('General Settings')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Site Settings')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row">
        
         <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>@lang('Basic Settings')</h4>
                </div>
                <div class="card-body">
                    <form action="{{ route('seller.gs.update') }}" method="POST">
                        @csrf
                        <input type="hidden" name="basic" value="1">
                
                            <div class="form-group mb-3 ">
                                <label for="title" class="col-form-label">{{ __('Website Title') }}</label>

                                <input type="text" class="form-control" id="title" name="title"
                                    placeholder="{{ __('Website Title') }}" value="{{ $setting->title }}">

                            </div>

                            <div class="form-group  mb-3 ">
                                <label for="title" class="col-form-label">{{ __('Contact No') }}</label>

                                <input type="text" class="form-control" id="title" name="contact_no"
                                    placeholder="{{ __('Contact No') }}" value="{{ $setting->contact_no }}">
                            </div>

                            <div class="form-group  mb-3 ">
                                <label for="order_prefix" class="col-form-label">{{ __('Order Number Format (Prefix)') }}</label>

                                <input type="text" class="form-control" id="order_prefix" name="order_prefix"
                                    placeholder="{{ __('Enter Prefix') }}" value="{{ $setting->order_prefix }}">
                            </div>

                            <div class="form-group  mb-3 ">
                                <label for="email" class="col-form-label">{{ __('Notification & Reply-to Email') }}</label>

                                <input type="text" class="form-control" id="email" name="email"
                                    placeholder="{{ __('Enter Email') }}" value="{{ $setting->email }}">
                            </div>



                            <div class="form-group  mb-3">
                                <label for="currency_possition"
                                    class="col-form-label">{{ __('Currency Possition') }}</label>
                                <select name="currency_possition" class="form-control" id="currency_possition">
                                    <option value="left" {{ $setting->currency_possition == 'left' ? 'selected' : '' }}>left
                                    </option>
                                    <option value="right" {{ $setting->currency_possition == 'right' ? 'selected' : '' }}>right
                                    </option>
                                </select>
                            </div>


                            <div class="form-group">
                                <label for="theme_color" class="col-form-label">{{ __('Theme Color') }}</label>
                                <div class="input-group cp">
                                    <input type="text" class="form-control colorpicker-element"
                                        value="{{ $setting->theme_color }}" id="theme_color" name="theme_color"
                                        placeholder="{{ __('Theme Color') }}">
                                    <span class="input-group-append">
                                        <span class="input-group-text colorpicker-input-addon"><i></i></span>
                                    </span>
                                </div>
                            </div>

                        <div class="form-group text-right">
                            <button class="btn btn-primary">@lang('Update')</button>
                        </div>
                    </form>
                </div>
            </div>
         </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('assets/admin/js/colorpicker.js') }}"></script>
    <script>
        'use strict';
        $(document).ready(function() {
            $(".cp").colorpicker({
                format: "auto",
            });

            $('input[name=allowed_email]').tagify();

            $('#select2-basic').select2();
        });
    </script>
@endpush
