@extends('layouts.seller')

@section('title')
    @lang('General Settings')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Other Settings')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('seller.gs.update') }}" method="POST">
                        @csrf
                        <div class="col-12 col-sm-12 col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4>@lang('Other Settings')</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-4">
                                            <ul class="nav nav-pills flex-column" id="myTab4" role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link active show" id="header-tab4" data-toggle="tab" href="#header4"
                                                        role="tab" aria-controls="header"
                                                        aria-selected="false">@lang('Header')</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="footer-tab4" data-toggle="tab" href="#footer4"
                                                        role="tab" aria-controls="footer"
                                                        aria-selected="false">@lang('Footer')</a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link " id="contact-tab4" data-toggle="tab"
                                                        href="#contact4" role="tab" aria-controls="contact"
                                                        aria-selected="true">@lang('Social Links')</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-8">
                                            <div class="tab-content no-padding" id="myTab2Content">
                                                <div class="tab-pane fade active show" id="header4" role="tabpanel"
                                                    aria-labelledby="header-tab4">
                                                    <form action="">
                                                      <input type="hidden" name="header" value="1">
                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-12">
                                                                <label for="support_number"
                                                                    class="col-form-label">{{ __('Help & Support Number') }}</label>
                                                                <input type="text" class="form-control"
                                                                    id="support_number" name="support_number"
                                                                    placeholder="{{ __('Help & Support Number') }}"
                                                                    value="{{ $setting->support_number }}">
                                                            </div>
                                                            <div class="form-group mb-3 col-md-12">
                                                                <label for="currency_show"
                                                                    class="col-form-label">{{ __('Currency Show') }}</label>
                                                                <select name="currency_show" class="form-control"
                                                                    id="currency_show">
                                                                    <option value="1" {{$setting->currency_show == 1 ? 'selected' : ''}}>@lang('Yes')</option>
                                                                    <option value="0" {{$setting->currency_show == 0 ? 'selected' : ''}}>@lang('No')</option>
                                                                </select>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-12">
                                                                <label for="language_show"
                                                                    class="col-form-label">{{ __('Language Show') }}</label>
                                                                <select name="language_show" class="form-control"
                                                                    id="language_show">
                                                                    <option value="1" {{$setting->language_show == '1' ? 'selected' : ''}}>@lang('Yes')</option>
                                                                    <option value="0" {{$setting->language_show == '0' ? 'selected' : ''}}>@lang('No')</option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row">
                                                            <div class="col-sm-12 text-center">
                                                                <button type="submit"
                                                                    class="btn btn-primary btn-block">{{ __('Update') }}</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="tab-pane fade" id="footer4" role="tabpanel"
                                                    aria-labelledby="footer-tab4">
                                                    <form action="{{route('seller.gs.update')}}" method="POST">
                                                        @csrf
                                                      <input type="hidden" name="footer" value="1">
                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-12">
                                                                <label for="footer_text"
                                                                    class="col-form-label">{{ __('Footer Text') }}</label>
                                                                <textarea name="footer_text" id="footer_text" class="form-control" placeholder="Enter Footer Text">{{ $setting->footer_text }}</textarea>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-12">
                                                                <label for=""
                                                                    class="col-form-label">{{ __('Copyright Text') }}</label>
                                                                <textarea name="copyright_text" class="form-control" id="copyright_text" placeholder="Enter Copyright Text">{{ $setting->copyright_text }}</textarea>
                                                            </div>

                                                            <div class="form-group mb-3 col-md-12">
                                                                <label for="copyright_show"
                                                                    class="col-form-label">{{ __('Copyright Show') }}</label>
                                                                <select name="copyright_show" class="form-control"
                                                                    id="copyright_show">
                                                                    <option value="1"
                                                                        {{ $setting->copyright_show == 1 ? 'selected' : '' }}>
                                                                        @lang('Yes')</option>
                                                                    <option value="0"
                                                                        {{ $setting->copyright_show == 1 ? 'selected' : '' }}>
                                                                        @lang('No')</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <div class="col-sm-12 text-center">
                                                                <button type="submit"
                                                                    class="btn btn-primary btn-block">{{ __('Update') }}</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="tab-pane fade  " id="contact4" role="tabpanel"
                                                    aria-labelledby="contact-tab4">

                                                    <form action="{{route('seller.gs.update')}}" method="POST">
                                                        @csrf
                                                      <input type="hidden" name="social_link" value="1">
                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-4">
                                                                <label for="">@lang('Icon')</label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control"
                                                                        id="value" readonly name="icon"
                                                                        value="{{@$socialLink->icon}}">
                                                                    <span class="input-group-append">
                                                                        <button
                                                                            class="btn btn-outline-secondary iconpicker"
                                                                            data-icon="{{@$socialLink->icon}}"
                                                                            role="iconpicker"></button>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-8">
                                                                <label for="url"
                                                                    class="col-form-label">{{ __('URL') }}</label>
                                                                <input type="text" class="form-control" id="url"
                                                                    name="url" placeholder="{{ __('URL') }}"
                                                                    value="{{@$socialLink->url}}">
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-4">
                                                                <label for="">@lang('Icon')</label>
                                                                <div class="input-group">
                                                                    <input type="text" class="form-control"
                                                                        id="value1" readonly name="icon1"
                                                                        value="{{@$socialLink->icon1}}">
                                                                    <span class="input-group-append">
                                                                        <button
                                                                            class="btn btn-outline-secondary iconpicker"
                                                                            data-icon="{{@$socialLink->icon1}}"
                                                                            role="iconpicker"></button>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-8">
                                                                <label for="url1"
                                                                    class="col-form-label">{{ __('URL') }}</label>
                                                                <input type="text" class="form-control" id="url1"
                                                                    name="url1" placeholder="{{ __('URL') }}"
                                                                    value="{{@$socialLink->url1}}">
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-4">
                                                                <label for="">@lang('Icon')</label>
                                                                <div class="input-group">
                                                                    <input type="icon2" class="form-control"
                                                                        id="icon2" readonly name="icon2"
                                                                        value="{{@$socialLink->icon2}}">
                                                                    <span class="input-group-append">
                                                                        <button
                                                                            class="btn btn-outline-secondary iconpicker"
                                                                            data-icon="{{@$socialLink->icon2}}"
                                                                            role="iconpicker"></button>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-8">
                                                                <label for="url2"
                                                                    class="col-form-label">{{ __('URL') }}</label>
                                                                <input type="text" class="form-control" id="url2"
                                                                    name="url2" placeholder="{{ __('URL') }}"
                                                                    value="{{@$socialLink->url2}}">
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-4">
                                                                <label for="">@lang('Icon')</label>
                                                                <div class="input-group">
                                                                    <input type="icon3" class="form-control "
                                                                        id="icon3" readonly name="icon3"
                                                                        value="{{@$socialLink->icon3}}">
                                                                    <span class="input-group-append">
                                                                        <button
                                                                            class="btn btn-outline-secondary iconpicker"
                                                                            data-icon="{{@$socialLink->icon3}}"
                                                                            role="iconpicker"></button>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-8">
                                                                <label for="url3"
                                                                    class="col-form-label">{{ __('URL') }}</label>
                                                                <input type="text" class="form-control" id="url3"
                                                                    name="url3" placeholder="{{ __('URL') }}"
                                                                    value="{{@$socialLink->url3}}">
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="form-group mb-3 col-md-4">
                                                                <label for="">@lang('Icon')</label>
                                                                <div class="input-group">
                                                                    <input type="icon4" class="form-control "
                                                                        id="icon4" readonly name="icon4"
                                                                        value="{{@$socialLink->icon4}}">
                                                                    <span class="input-group-append">
                                                                        <button
                                                                            class="btn btn-outline-secondary iconpicker"
                                                                            data-icon="{{@$socialLink->icon4}}"
                                                                            role="iconpicker"></button>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group mb-3 col-md-8">
                                                                <label for="url3"
                                                                    class="col-form-label">{{ __('URL') }}</label>
                                                                <input type="text" class="form-control" id="url4"
                                                                    name="url4" placeholder="{{ __('URL') }}"
                                                                    value="{{@$socialLink->url4}}">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <div class="col-sm-12 text-center">
                                                                <button type="submit"
                                                                    class="btn btn-primary btn-block">{{ __('Update') }}</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script>
        $(document).on('change', '.iconpicker', function() {
            var icon = $(this).find('i').attr('class');
            $(this).parent().parent().find('input').val(icon);
        });
    </script>
@endpush
