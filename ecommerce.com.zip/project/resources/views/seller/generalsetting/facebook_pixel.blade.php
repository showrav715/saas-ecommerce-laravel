@extends('layouts.seller')
@section('title')
    @lang('Facebook Pixel')
@endsection
@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Facebook Pixel')</h1>
        </div>
    </section>
@endsection
@section('title')
    @lang('Facebook Pixel')
@endsection

@section('content')
    <div class="row">
        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h6>@lang('Facebook Pixel')</h6>
                </div>
                <div class="card-body">

                    <form action="{{ route('seller.gs.update') }}" enctype="multipart/form-data" method="POST">
                        @csrf
                        <input type="hidden" name="facebok_form" value="1">
                        @include('admin.partials.form-both')
                        
                        <div class="form-group row mb-3">
                            <label for="facebook_pixel" class="col-sm-3 col-form-label">{{ __('Facebook Pixel ID') }}</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="facebook_pixel" name="facebook_pixel"
                                    placeholder="{{ __('Facebook Pixel ID') }}" value="{{ $gs->facebook_pixel }}">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12 text-right">
                                <button type="submit" class="btn btn-primary">{{ __('Update') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
@endsection
