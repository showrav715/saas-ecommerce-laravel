@extends('layouts.seller')
@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Update Contact Page')</h1>
        </div>
    </section>
@endsection
@section('title')
    @lang('Contact Page')
@endsection
@section('content')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">{{ __('Update Contact Page') }}</h6>
                </div>
                <div class="card-body">

                    <form action="{{ route('seller.contact.page.update') }}" enctype="multipart/form-data" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label for="title">{{ __('Content Title') }}</label>
                            <input type="text" class="form-control" name="title" id="title"
                                placeholder="{{ __('Content Title') }}" value="{{ @$contactPage->title }}">
                        </div>
                        <div class="form-group">
                            <label for="text">{{ __('Content Text') }}</label>
                            <input type="text" class="form-control" name="text" id="text"
                                placeholder="{{ __('Content Text') }}" value="{{ @$contactPage->text }}">
                        </div>
                        <div class="form-group">
                            <label for="office_address">{{ __('Office Address') }}</label>
                            <input type="text" class="form-control" name="office_address" id="office_address"
                                placeholder="{{ __('Office Address') }}" value="{{ @$contactPage->office_address }}">
                        </div>
                        <div class="form-group">
                            <label for="contact_number">{{ __('Contact Number') }}</label>
                            <input type="text" class="form-control" name="contact_number" id="contact_number"
                                placeholder="{{ __('Contact Number') }}" value="{{ @$contactPage->contact_number }}">
                        </div>
                        <div class="form-group">
                            <label for="email_address">{{ __('Email Address') }}</label>
                            <input type="text" class="form-control" name="email_address" id="email_address"
                                placeholder="{{ __('Email Address') }}" value="{{ @$contactPage->email_address }}">
                        </div>

                        <div class="form-group">
                            <label for="career_info">{{ __('Career Info') }}</label>
                            <textarea id="area1" class="form-control summernote" name="career_info" placeholder="{{ __('Career Info') }}"
                            >{{ @$contactPage->career_info }}</textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
