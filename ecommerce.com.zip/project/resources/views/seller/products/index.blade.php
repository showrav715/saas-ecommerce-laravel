@extends('layouts.seller')

@section('title')
   @lang('Products')
@endsection

@section('breadcrumb')
 <section class="section">
    <div class="section-header">
        <h1>@lang('Products')</h1>
    </div>
</section>
@endsection

@section('content')

<div class="row">
   <div class="col-lg-12">
      <div class="card mb-4">
         <div class="card-header d-flex justify-content-end">
            <a href="{{route('seller.product.create')}}" class="btn btn-primary">
               <i class="fas fa-plus"></i> @lang('Add New')
            </a>
         </div>
         <div class="table-responsive p-3">
            <table class="table" id="table">
              <thead>
               <tr>
                  <th>@lang('Image')</th>
                  <th>@lang('Brand')</th>
                  <th>@lang('Category')</th>
                  <th>@lang('Name')</th>
                  <th>@lang('Price')</th>
                  <th>@lang('Status')</th>
                  <th class="text-right">@lang('Action')</th>
              </tr>
              </thead>
               <tbody>
                  @foreach($products as $item)
                   <tr>
                        <td data-label="@lang('Image')">
                          <img width="120" src="{{getPhoto($item->photo,auth()->id())}}" alt="">
                        </td>
                        <td data-label="@lang('Brand')">
                           {{$item->brand->name}}
                        </td>
                        <td data-label="@lang('Category')">
                           {{$item->category->name}}
                        </td>
                        <td data-label="@lang('Name')">
                           {{$item->name}}
                        </td>
                        <td data-label="@lang('Price')">
                           {{sellerShowAmount($item->current_price)}}
                        </td>
                        <td data-label="@lang('Status')">
                           @if ($item->status == 1)
                           <span class="badge badge-success"> @lang('Active') </span>
                           @else
                           <span class="badge badge-warning"> @lang('Inactive') </span>
                           @endif
                        </td>
                        <td data-label="@lang('Action')" class="text-right">
                           <button class="btn btn-primary mb-1 btn-sm highlight" data-id="{{$item->id}}" data-toggle="modal"  data-target="#highlight">@lang('Highlight')</button>
                           <a href="{{route('seller.product.edit',$item->id)}}"  class="btn btn-primary approve btn-sm edit mb-1" title="@lang('Edit')"><i class="fas fa-edit"></i></a>
                           <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1" data-id="{{$item->id}}"  data-toggle="tooltip" title="@lang('Remove')"><i class="fas fa-trash"></i></a>
                        </td>
                   </tr>
               @endforeach
               </tbody>
           </table>
         </div>
      </div>
   </div>
</div>



<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
   <div class="modal-dialog" role="document">
      <form action="{{route('seller.product.destroy')}}" method="POST">
         @method('DELETE')
         @csrf
         <input type="hidden" name="id">
         <div class="modal-content">
            <div class="modal-body">
               <h5>@lang('Are you sure to remove?')</h5>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
               <button type="submit" class="btn btn-danger">@lang('Confirm')</button>
            </div>
         </div>
      </form>
   </div>
</div>


<div class="modal fade" tabindex="-1" role="dialog" id="highlight">
   <div class="modal-dialog" role="document">
     <div class="modal-content">
      <form action="{{route('seller.product.highlight.submit')}}" method="POST">
         @csrf
       <div class="modal-header">
         <h5 class="modal-title">@lang('Highlight Products')</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
           <span aria-hidden="true">&times;</span>
         </button>
       </div>
      
       <div class="modal-body">
       </div>

       <div class="modal-footer bg-whitesmoke br">
         <button type="button" class="btn btn-secondary" data-dismiss="modal">@lang('Close')</button>
         <button type="submit" class="btn btn-primary">@lang('Save changes')</button>
       </div>
      </form>
     </div>
   </div>
 </div>
</div>

<div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
   <div class="modal-dialog" role="document">
      <form action="{{route('seller.product.destroy')}}" method="POST">
         @method('DELETE')
         @csrf
         <input type="hidden" name="id">
         <div class="modal-content">
            <div class="modal-body">
               <h5>@lang('Are you sure to remove?')</h5>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
               <button type="submit" class="btn btn-danger">@lang('Confirm')</button>
            </div>
         </div>
      </form>
   </div>
</div>

@endsection


@push('script')
    <script>
      'use strict',
      $(document).on('click','.highlight',function(){
         let product_id = $(this).attr('data-id');
         $.get("{{route('seller.product.highlight')}}",{product_id:product_id},function(data){
            $('#highlight .modal-body').html(data);
         });
      })

      $('.remove').on('click',function () { 
         $('#removeMod').find('input[name=id]').val($(this).data('id'))
         $('#removeMod').modal('show')
       })
    </script>
@endpush