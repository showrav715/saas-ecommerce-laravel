@extends('layouts.seller')

@section('title')
    @lang('Colors')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header">
            <h1>@lang('Colors')</h1>
        </div>
    </section>
@endsection

@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-end">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add">
                        <i class="fas fa-plus"></i> @lang('Add New')
                    </button>

                </div>
                <div class="table-responsive p-3">
                    <table class="table table-striped" id="table">
                        <thead>
                            <tr>
                                <th>@lang('Color Name')</th>
                                <th>@lang('Color Code')</th>
                                <th class="text-right">@lang('Action')</th>
                            </tr>
                        </thead>
                       <tbody>
                        @foreach ($colors as $item)
                        <tr>

                            <td data-label="@lang('Name')">
                                {{ $item->color_name }}
                            </td>

                            <td data-label="@lang('Code')">
                                {{ $item->color_code }}
                            </td>
                            <td data-label="@lang('Action')" class="text-right">
                                <a href="javascript:void()" class="btn btn-primary approve btn-sm edit mb-1"
                                    data-route="{{ route('seller.color.update', $item->id) }}"
                                    data-item="{{ $item }}" data-path="{{ sellerpath() }}"
                                    data-toggle="tooltip" title="@lang('Edit')"><i class="fas fa-edit"></i></a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-sm remove mb-1"
                                    data-id="{{ $item->id }}" data-toggle="tooltip" title="@lang('Remove')"><i
                                        class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                  
                    @endforeach
                       </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="add" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="{{ route('seller.color.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">@lang('Add new color')</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>@lang('Color Name')</label>
                            <input class="form-control" type="text" name="color_name">
                        </div>
                        <div class="form-group cp">
                            <label>@lang('Color Code')</label>
                            <div class="input-group">
                                <input type="text" class="form-control colorpicker-element" value="#000000"
                                    name="color_code">
                                <span class="input-group-append">
                                    <span class="input-group-text colorpicker-input-addon"><i></i></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                        <button type="submit" class="btn btn-primary">@lang('Submit')</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">@lang('Edit color')</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>@lang('Color Name')</label>
                            <input class="form-control" type="text" name="color_name">
                        </div>
                        <div class="form-group cpa">
                            <label>@lang('Color Code')</label>
                            <div class="input-group">
                                <input type="text" class="form-control colorpicker-element" value=""
                                    name="color_code">
                                <span class="input-group-append">
                                    <span class="input-group-text colorpicker-input-addon"><i></i></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                        <button type="submit" class="btn btn-primary">@lang('Submit')</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="{{ route('seller.color.destroy') }}" method="POST">
                @method('DELETE')
                @csrf
                <input type="hidden" name="id">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5>@lang('Are you sure to remove?')</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal">@lang('Close')</button>
                        <button type="submit" class="btn btn-danger">@lang('Confirm')</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('assets/admin/js/colorpicker.js') }}"></script>
    <script>
        'use strict';
        $(".cp").colorpicker({
            format: "auto",
        });

        $('.edit').on('click', function() {
            var data = $(this).data('item')
            $('#edit').find('input[name=color_name]').val(data.color_name)
            $('#edit').find('input[name=color_code]').val(data.color_code)
            $('#edit').find('form').attr('action', $(this).data('route'))
            $('#edit').modal('show')
            $(".cpa").colorpicker({
                color: data.color_code,
            });
        })

        $('.remove').on('click', function() {
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
    </script>
@endpush
