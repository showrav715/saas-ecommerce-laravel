
        <input type="hidden" name="product_id" value="{{$product->id}}">
        <div class="card">
            <div class="card-body">
                <label class="cswitch mb-0 d-flex justify-content-between align-items-center">
                    <input class="cswitch--input permission" name="new" {{@$product->new == 1 ? 'checked' : '' }} type="checkbox"/>
                    <span class="cswitch--trigger wrapper"></span>
                    <span class="cswitch--label font-weight-bold ">@lang('New')</span>
                </label>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <label class="cswitch mb-0 d-flex justify-content-between align-items-center">
                    <input class="cswitch--input permission" name="trending" {{@$product->trending == 1 ? 'checked' : '' }} type="checkbox"/>
                    <span class="cswitch--trigger wrapper"></span>
                    <span class="cswitch--label font-weight-bold ">@lang('Trending')</span>
                </label>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <label class="cswitch mb-0 d-flex justify-content-between align-items-center">
                    <input class="cswitch--input permission" name="best" {{@$product->best == 1 ? 'checked' : '' }} type="checkbox"/>
                    <span class="cswitch--trigger wrapper"></span>
                    <span class="cswitch--label font-weight-bold ">@lang('Best Selling')</span>
                </label>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <label class="cswitch mb-0 d-flex justify-content-between align-items-center">
                    <input class="cswitch--input permission" name="featured" {{@$product->featured == 1 ? 'checked' : '' }} type="checkbox"/>
                    <span class="cswitch--trigger wrapper"></span>
                    <span class="cswitch--label font-weight-bold ">@lang('Featured')</span>
                </label>
            </div>
        </div>
