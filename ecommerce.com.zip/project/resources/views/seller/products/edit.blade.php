@extends('layouts.seller')
@section('title')
    @lang('Edit Product')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1>@lang('Edit Product')</h1>
            <a href="{{ route('seller.product.index') }}" class="btn btn-primary"><i class="fas fa-backward"></i>
                @lang('Back') </a>
        </div>
    </section>
@endsection
@section('content')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <form method="post" action="{{ route('seller.product.update', $product->id) }}"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="col-sm-8 border py-2">
                                <div class="form-group">
                                    <label>@lang('Product Name') *</label>
                                    <input type="text" name="name" class="form-control slug-title"
                                        value="{{ $product->name }}">
                                </div>
                                <div class="form-group">
                                    <label>@lang('Product Slug') *</label>
                                    <input type="text" class="form-control slug" name="slug"
                                        value="{{ $product->slug }}">
                                </div>
                                <div class="form-group">
                                    <label>@lang('Product Sku') *</label>
                                    <input type="text" class="form-control" name="sku" value="{{ $product->sku }}">
                                </div>
                                <div class="form-group">
                                    <label>@lang('Product Current Price') ({{ sellerCurrencyCode() }}) *</label>
                                    <input type="number" step="any" name="current_price" class="form-control"
                                        value="{{ sellerConvertAmount($product->current_price) }}">
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Previous Price') ({{ sellerCurrencyCode() }}) *</label>
                                    <input type="number" step="any" name="previous_price" class="form-control"
                                        value="{{ sellerConvertAmount($product->previous_price) }}">
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Stock') *</label>
                                    <input type="number" name="stock" class="form-control" value="{{ $product->stock }}">
                                </div>

                                <div class="card">
                                    <div class="card-header">
                                        <h4>@lang('Product Variation')</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" readonly disabled
                                                    placeholder="Colors">
                                            </div>
                                            <div class="col-sm-8">
                                                @php
                                                    $colors = [];
                                                    $attributes = [];
                                                    if (@$product->product_attrs->colors) {
                                                        $colors = explode(',', $product->product_attrs->colors);
                                                    }
                                                    if (@$product->product_attrs->attribute_id) {
                                                        $attributes = explode(',', $product->product_attrs->attribute_id);
                                                    }
                                                @endphp
                                                <select name="colors[]" class="form-control select2" multiple
                                                    id="">
                                                    @foreach (DB::table('colors')->whereUserId(auth()->id())->get() as $color)
                                                        <option value="{{ $color->id }}"
                                                            {{ in_array($color->id, $colors) ? 'selected' : '' }}>
                                                            {{ $color->color_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" readonly disabled
                                                    placeholder="Attributes">
                                            </div>
                                            <div class="col-sm-8">
                                                <select name="attributes[]" class="form-control select2" multiple
                                                    id="attribute">
                                                    @foreach (App\Models\Attribute::whereUserId(auth()->id())->get() as $attribute)
                                                        <option value="{{ $attribute->id }}"
                                                            {{ in_array($attribute->id, $attributes) ? 'selected' : '' }}>
                                                            {{ $attribute->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div id="attribute__options">
                                            @if ($attributes)
                                                <p>Choose the attributes of this product and then input values of each
                                                    attribute</p>
                                                @php
                                                    $variations = json_decode($product->product_attrs->variation_id);
                                                    if ($variations) {
                                                        $variations = $variations;
                                                    } else {
                                                        $variations = [];
                                                    }
                                                @endphp
                                                @foreach ($variations as $key => $variation)
                                                    @php
                                                        $attribute = App\Models\Attribute::find($key);
                                                        $variations = App\Models\Variation::where('attribute_id', $attribute->id)->get();
                                                    @endphp
                                                    <div class="form-group row">
                                                        <div class="col-sm-4">
                                                            <input type="text" class="form-control" readonly disabled
                                                                placeholder="{{ $attribute->name }}">
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <select name="variations[{{ $attribute->id }}][]"
                                                                class="form-control select2" multiple id="">
                                                                @foreach ($variations as $variationSingle)
                                                                    <option value="{{ $variationSingle->id }}"
                                                                        {{ in_array($variationSingle->id, $variation) ? 'selected' : '' }}>
                                                                        {{ $variationSingle->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @endif
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label>@lang('Product Descriiption') *</label>
                                    <textarea name="details" class="form-control summernote h-125">{{ $product->details }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Tags')</label>
                                    <input type="text" name="tags" class="form-control tagify"
                                        value="{{ $product->tags }}">
                                </div>

                                <div class="form-group">
                                    <label for="meta_tag">@lang('Meta Tags')</label>
                                    <input type="text" name="meta_tag" value="{{ $product->meta_tag }}" id="meta_tag">
                                </div>
                                <div class="form-group">
                                    <label for="meta_content">@lang('Meta Content')</label>
                                    <textarea name="meta_content" id="meta_content" class="form-control h-125">{{ $product->meta_content }}</textarea>
                                </div>

                                <div class="form-group">
                                    <button class="btn btn-primary basicbtn" type="submit">@lang('Update')</button>
                                </div>
                            </div>
                            <div class="col-sm-4 border border-left-0 py-2">
                                <div class="form-group d-flex justify-content-center">
                                    <div id="image-preview" class="image-preview image-preview_alt"
                                        style="background-image:url({{ getPhoto($product->photo, auth()->id()) }});">
                                        <label for="image-upload" id="image-label">@lang('Choose File')</label>
                                        <input type="file" name="photo" id="image-upload" />
                                    </div>
                                </div>

                                <hr>
                                <div class="form-group">
                                    <label for="meta_content">@lang('Gallery')</label>
                                    <input type="file" class="form-control" name="gallery[]" id="gallery"
                                        multiple />
                                    <div class="gallery text-center my-3">
                                        @forelse ($product->galleries as $gallery)
                                        <div class="gallery-item border p-2 mb-4 mx-2">
                                            <a href="javascript:;" class="btn btn-danger btn-sm" data-href="{{route('seller.gallery.delete',$gallery->id)}}" title="Remove"><i class="fas fa-trash"></i></a>
                                            <img src="{{getPhoto($gallery->photo,sellerId())}}" width="60" alt="">
                                        </div>
                                        @empty
                                        <p>@lang('Image Not Found')</p>
                                        @endforelse
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label>@lang('Product Brand')</label>
                                    <select class="form-control" name="brand_id" id="brand_id">
                                        <option value="">@lang('-Select Brand-')</option>
                                        @foreach ($brands as $brand)
                                            <option value="{{ $brand->id }}" {{$product->brand_id == $brand->id ? 'selected' : ''}} >{{ $brand->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Category') *</label>
                                    <select class="form-control" name="category_id" id="category_id">
                                        <option value="">@lang('-Select Category-')</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}"
                                                {{ $product->category_id == $category->id ? 'selected' : '' }}>
                                                {{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>@lang('Subcategory')</label>
                                    <select class="form-control" {{ $product->subcategory_id ? '' : 'disabled' }}
                                        name="subcategory_id" id="sub">
                                        <option value="">@lang('-Select One-')</option>
                                        @foreach ($subcategories as $subcategory)
                                            <option value="{{ $subcategory->id }}"
                                                {{ $product->subcategory_id == $subcategory->id ? 'selected' : '' }}>
                                                {{ $subcategory->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="cswitch mb-0 d-flex justify-content-between align-items-center">
                                        <input class="cswitch--input is_digital"
                                            {{ $product->type == 1 ? 'checked' : '' }} name="digital" type="checkbox" />
                                        <span class="cswitch--trigger wrapper"></span>
                                        <span class="cswitch--label font-weight-bold ">@lang('Digital Product')</span>
                                    </label>
                                </div>

                                <div class="show_digital {{ $product->type == 1 ? '' : 'd-none' }} ">
                                    <div class="form-group">
                                        <label>@lang('File Type')</label>
                                        <select class="form-control" name="file_type">
                                            <option value="1" {{ $product->file_type == 1 ? 'selected' : '' }}>@lang('File')
                                            </option>
                                            <option value="0" {{ $product->file_type == 0 ? 'selected' : '' }}>@lang('Link')
                                            </option>
                                        </select>
                                    </div>
                                    <div class="form-group digital_file {{ $product->file_type == 1 ? '' : 'd-none' }}">
                                        <label for="file">@lang('Product File')</label>
                                        <input type="file" class="form-control" name="file" id="file">
                                        <code>@lang('File') : <a href="{{ asset('/') }}" download="">@lang('Download')</a></code>
                                    </div>
                                    <div
                                        class="form-group digital_digital_link {{ $product->file_type == 0 ? '' : 'd-none' }}">
                                        <label for="link">@lang('Product link')</label>
                                        <input type="text" class="form-control" name="link"
                                            value="{{ $product->link }}" id="link">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="status">@lang('Product Status')</label>
                                    <select name="status" class="form-control">
                                        <option value="1" {{$product->status == 1 ? 'selected' : ''}}>@lang('Active')</option>
                                        <option value="0" {{$product->status == 0 ? 'selected' : ''}}>@lang('Inactive')</option>
                                     </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script>
        'use strict';
        $.uploadPreview({
            input_field: "#image-upload",
            preview_box: "#image-preview",
            label_field: "#image-label",
            label_default: "{{ __('Choose File') }}",
            label_selected: "{{ __('Update Image') }}",
            no_label: false,
            success_callback: null
        });
        $('input[name=tags]').tagify();
        $('input[name=meta_tag]').tagify();

        $(document).on('change', '.is_digital', function() {
            if ($(this).is(':checked')) {
                $('.show_digital').removeClass('d-none');
            } else {
                $('.show_digital').addClass('d-none');
            }
        });

        $(document).on('change', 'select[name=file_type]', function() {
            if ($(this).val() == 1) {
                $('.digital_file').removeClass('d-none');
                $('.digital_digital_link').addClass('d-none');
            } else {
                $('.digital_file').addClass('d-none');
                $('.digital_digital_link').removeClass('d-none');
            }
        });

        // attribute get 
        $(document).on('change', '#attribute', function() {
            let attribute_ids = $(this).val();
            // array not empty 
            if (attribute_ids.length > 0) {
                $.ajax({
                    url: "{{ route('seller.product.variation.get') }}",
                    type: "GET",
                    data: {
                        attribute_ids: attribute_ids
                    },
                    success: function(data) {
                        $('#attribute__options').html(data);
                    }
                });
            } else {
                $('#attribute__options').html('');
            }
        })

        // category get
        $(document).on('change', '#category_id', function() {
            let category_id = $(this).val();
            // array not empty 
            if (category_id) {
                $.ajax({
                    url: "{{ route('seller.product.subcategory.get') }}",
                    type: "GET",
                    data: {
                        category_id: category_id
                    },
                    success: function(data) {
                        $('#sub').attr('disabled', false);
                        $('#sub').html(data);
                    }
                });
            } else {
                $('#sub').html('');
            }
        })


        $(document).on('change', '#gallery', function(event) {
            let html = '';
            for (let i = 0; i < event.target.files.length; i++) {
                html += `<div class="gallery-item border p-2 mb-4 mx-2">
                            <a href="javascript:;" class="btn btn-danger btn-sm" title="Remove"><i class="fas fa-trash"></i></a>
                            <img src="${URL.createObjectURL(event.target.files[i])}" width="60" alt="">
                        </div>`;
            }
            $('.gallery').append(html);
        })

        $(document).on('click', '.gallery-item a', function() {
            let data_href = $(this).attr('data-href');
            let status = confirm('Are you sure to delete this image?');
            if (!status) {
                return;
            }
           let  $this = $(this);
            if (data_href) {
                $.ajax({
                    url: data_href,
                    type: "GET",
                    success: function(data) {
                        $this.parent().remove();
                    }
                });
            }else{
                $(this).parent().remove();
            }
           
        })


    </script>
@endpush
