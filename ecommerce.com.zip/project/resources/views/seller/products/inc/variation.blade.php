
<p>Choose the attributes of this product and then input values of each attribute
</p>
@foreach ($datas as $key=>$data)

<div class="form-group row">
    <div class="col-sm-4">
       <input type="text" class="form-control" readonly disabled placeholder="{{$attributes[$key]->name}}">
    </div>
    <div class="col-sm-8">
       <select name="variations[{{$attributes[$key]->id}}][]" class="form-control select2" multiple id="">
         @foreach ($data as $item)
             <option value="{{$item->id}}">{{$item->name}}</option>
         @endforeach
       </select>
    </div>
 </div>
@endforeach

<script>
   'use strict';
    if(jQuery().select2) {
    $(".select2").select2();
  }
</script>

