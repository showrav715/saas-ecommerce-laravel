@extends('layouts.seller')
@section('title')
    @lang('Create Product')
@endsection

@section('breadcrumb')
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1>@lang('Create Product')</h1>
            <a href="{{ route('seller.product.index') }}" class="btn btn-primary"><i class="fas fa-backward"></i>
                @lang('Back') </a>
        </div>
    </section>
@endsection
@section('content')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <form method="post" action="{{ route('seller.product.store') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-sm-8 border py-2">
                                <div class="form-group">
                                    <label>@lang('Product Name') *</label>
                                    <input type="text" name="name" class="form-control slug-title"
                                        value="{{ old('name') }}">
                                </div>
                                <div class="form-group">
                                    <label>@lang('Product Slug') *</label>
                                    <input type="text" class="form-control slug" name="slug"
                                        value="{{ old('slug') }}">
                                </div>
                                <div class="form-group">
                                    <label>@lang('Product Sku')</label>
                                    <input type="text" class="form-control" name="sku"
                                        value="{{ old('sku', Str::random(8)) }}">
                                </div>
                                <div class="form-group">
                                    <label>@lang('Product Current Price') ({{ sellerCurrencyCode() }}) *</label>
                                    <input type="number" step="any" name="current_price" class="form-control"
                                        value="{{ old('current_price') }}">
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Previous Price') ({{ sellerCurrencyCode() }}) *</label>
                                    <input type="number" step="any" name="previous_price" class="form-control"
                                        value="{{ old('previous_price') }}">
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Stock') *</label>
                                    <input type="number" name="stock" class="form-control" value="{{ old('stock') }}">
                                </div>

                                <div class="card">
                                    <div class="card-header">
                                        <h4>@lang('Product Variation')</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" readonly disabled
                                                    placeholder="Colors">
                                            </div>
                                            <div class="col-sm-8">
                                                <select name="colors[]" class="form-control select2" multiple
                                                    id="">
                                                    @foreach (DB::table('colors')->whereUserId(auth()->id())->get() as $color)
                                                        <option value="{{ $color->id }}">{{ $color->color_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" readonly disabled
                                                    placeholder="Attributes">
                                            </div>
                                            <div class="col-sm-8">
                                                <select name="attributes[]" class="form-control select2" multiple
                                                    id="attribute">
                                                    @foreach (App\Models\Attribute::whereUserId(auth()->id())->get() as $attribute)
                                                        <option value="{{ $attribute->id }}">{{ $attribute->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div id="attribute__options">
                                            {{-- drtsgfsdfgsdfg --}}
                                        </div>
                                    </div>
                                </div>



                                <div class="form-group">
                                    <label>@lang('Product Descriiption') *</label>
                                    <textarea name="details" class="form-control summernote h-125"></textarea>
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Tags')</label>
                                    <input type="text" name="tags" class="form-control tagify"
                                        value="{{ old('tags') }}">
                                </div>

                                <div class="form-group">
                                    <label for="meta_tag">@lang('Meta Tags')</label>
                                    <input type="text" name="meta_tag" id="meta_tag">
                                </div>
                                <div class="form-group">
                                    <label for="meta_content">@lang('Meta Content')</label>
                                    <textarea name="meta_content" id="meta_content" class="form-control h-125"></textarea>
                                </div>

                                <div class="form-group">
                                    <button class="btn btn-primary basicbtn" type="submit">@lang('Update')</button>
                                </div>
                            </div>
                            <div class="col-sm-4 border border-left-0 py-2">
                                <label for="meta_content">@lang('Feature Image')</label>
                                <div class="form-group d-flex justify-content-center">
                                    <div id="image-preview" class="image-preview image-preview_alt"
                                        style="background-image:url({{ getPhoto('') }});">
                                        <label for="image-upload" id="image-label">@lang('Choose File')</label>
                                        <input type="file" name="photo" id="image-upload" />
                                    </div>
                                </div>

                                <hr>
                                <div class="form-group">
                                    <label for="meta_content">@lang('Gallery')</label>
                                    <input type="file" class="form-control" name="gallery[]" id="gallery"
                                        multiple />
                                    <div class="gallery">

                                    </div>
                                </div>


                                <div class="form-group">
                                    <label>@lang('Product Brand')</label>
                                    <select class="form-control" name="brand_id" id="brand_id">
                                        <option value="">@lang('-Select Brand-')</option>
                                        @foreach ($brands as $brand)
                                            <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>@lang('Product Category')</label>
                                    <select class="form-control" name="category_id" id="category_id">
                                        <option value="">@lang('-Select Category-')</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>@lang('Subcategory')</label>
                                    <select class="form-control" disabled name="subcategory_id" id="sub">
                                        <option value="">@lang('-Select One-')</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="cswitch mb-0 d-flex justify-content-between align-items-center">
                                        <input class="cswitch--input is_digital" name="digital" type="checkbox" />
                                        <span class="cswitch--trigger wrapper"></span>
                                        <span class="cswitch--label font-weight-bold ">@lang('Digital Product')</span>
                                    </label>
                                </div>

                                <div class="show_digital d-none">
                                    <div class="form-group">
                                        <label>@lang('File Type')</label>
                                        <select class="form-control" name="file_type">
                                            <option value="1">@lang('File')</option>
                                            <option value="0">@lang('Link')</option>
                                        </select>
                                    </div>
                                    <div class="form-group digital_file">
                                        <label for="file">@lang('Product File')</label>
                                        <input type="file" class="form-control" name="file" id="file">
                                    </div>
                                    <div class="form-group digital_digital_link d-none">
                                        <label for="link">@lang('Product link')</label>
                                        <input type="text" class="form-control" name="link" id="link">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="status">@lang('Product Status')</label>
                                    <select name="status" class="form-control">
                                        <option value="1">@lang('Active')</option>
                                        <option value="0">@lang('Inactive')</option>
                                    </select>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script>
        'use strict';
        $.uploadPreview({
            input_field: "#image-upload",
            preview_box: "#image-preview",
            label_field: "#image-label",
            label_default: "{{ __('Choose File') }}",
            label_selected: "{{ __('Update Image') }}",
            no_label: false,
            success_callback: null
        });
        $('input[name=tags]').tagify();
        $('input[name=meta_tag]').tagify();

        $(document).on('change', '.is_digital', function() {
            if ($(this).is(':checked')) {
                $('.show_digital').removeClass('d-none');
            } else {
                $('.show_digital').addClass('d-none');
            }
        });

        $(document).on('change', 'select[name=file_type]', function() {
            if ($(this).val() == 1) {
                $('.digital_file').removeClass('d-none');
                $('.digital_digital_link').addClass('d-none');
            } else {
                $('.digital_file').addClass('d-none');
                $('.digital_digital_link').removeClass('d-none');
            }
        });


        // attribute get 
        $(document).on('change', '#attribute', function() {
            let attribute_ids = $(this).val();
            // array not empty 
            if (attribute_ids.length > 0) {
                $.ajax({
                    url: "{{ route('seller.product.variation.get') }}",
                    type: "GET",
                    data: {
                        attribute_ids: attribute_ids
                    },
                    success: function(data) {
                        $('#attribute__options').html(data);
                    }
                });
            } else {
                $('#attribute__options').html('');
            }
        })

        $(document).on('change', '#category_id', function() {
            let category_id = $(this).val();
            if (category_id) {
                $.ajax({
                    url: "{{ route('seller.product.subcategory.get') }}",
                    type: "GET",
                    data: {
                        category_id: category_id
                    },
                    success: function(data) {
                        $('#sub').attr('disabled', false);
                        $('#sub').html(data);
                    }
                });
            } else {
                $('#sub').html('');
            }
        })


        $(document).on('change', '#gallery', function(event) {
            let html = '';
            for (let i = 0; i < event.target.files.length; i++) {
                html += `<div class="gallery-item border p-2 mb-4 mx-2">
                    <a href="javascript:;" class="btn btn-danger btn-sm" title="Remove"><i class="fas fa-trash"></i></a>
                    <img src="${URL.createObjectURL(event.target.files[i])}" width="60" alt="">
            </div>`;
            }
            $('.gallery').append(html);
        })

        $(document).on('click', '.gallery-item a', function() {
            $(this).parent().remove();
        })
    </script>
@endpush
