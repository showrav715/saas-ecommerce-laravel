  <!--==================== Best Selling Products Section Start ====================-->
  <div class="full-row px-sm-5">
    <div class="container-fluid">
        <div class="row justify-content-center wow fadeInUp animated" data-wow-delay="200ms" data-wow-duration="1000ms">
            <div class="col-xxl-4 col-xl-6 col-lg-7">
                <div class="text-center mb-5">
                    <span class="text-secondary pb-2 d-table tagline">@lang('Top Products')</span>
                    <h2 class="text-center font-500 mb-4">@lang('Best Selling Products')</h2>
                    <span class="sub-title">@lang('Cillum eu id enim aliquip aute ullamco anim. Culpa deserunt nostrud excepteur voluptate velit ipsum esse enim.')</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="products product-style-1 owl-mx-15">
                    <div class="five-carousel owl-carousel dot-disable nav-arrow-middle-show e-title-hover-primary e-image-bg-light e-hover-image-zoom e-info-center">
                    @foreach ($best_sellings as $best)
                    <div class="item">
                        <div class="product type-product">
                            <div class="product-wrapper">
                                <div class="product-image">
                                    <a href="{{route('seller.front.product.details',$best->slug)}}" class="woocommerce-LoopProduct-link"><img src="{{getPhoto($best->photo,getUser('user_id'))}}" alt="Product Image"></a>
                                  
                                    @if ($best->previous_price)
                                    <div class="on-sale">{{discountPrice($best)}}</div>
                                    @endif
                                    <div class="hover-area">
                                        <div class="cart-button">
                                            <a href="javascript:;" class="button add_to_cart_button add__to__cart" data-href="{{route('seller.front.cart.store')}}" data-bs-toggle="tooltip" itemid="{{$best->id}}"
                                                data-bs-placement="right" title="" data-bs-original-title="Add to Cart"
                                                aria-label="Add to Cart">@lang('Add to Cart')</a>
                                        </div>
                                        <div class="wishlist-button">
                                            @if (Auth::check())
                                            <a class="add_to_wishlist add__wishlist" href="javascript:;" data-href="{{ route('seller.user.wishlist.add',$best->id) }}" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                            @else
                                            <a class="add_to_wishlist" href="{{route('seller.user.login')}}"  data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                            @endif
                                        </div>
                                        <div class="compare-button">
                                            <a class="compare button" href="javascript:;" data-href="{{ route('seller.front.compare.add',$best->id) }}" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Compare" aria-label="Compare">@lang('Compare')</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-info">
                                    <h3 class="product-title"><a href="{{route('seller.front.product.details',$best->slug)}}">{{$best->name}}</a></h3>
                                    <div class="product-price">
                                        <div class="price">
                                            <ins>{{sellerShowAmount($best->base_price)}}</ins>
                                            @if ($best->previous_price)
                                            <del>{{sellerShowAmount($best->previous_price)}}</del>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="shipping-feed-back">
                                        <div class="star-rating">
                                            <div class="rating-wrap">
                                                <a href="{{route('seller.front.product.details',$best->slug)}}">
                                                    <i class="fas fa-star"></i><span> {{$best->rating()}} ({{$best->reviews_count}})</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    
                
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==================== Best Selling Products Section End ====================-->