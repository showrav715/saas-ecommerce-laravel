<div class="full-row bg-light">
    <div class="container">
        <div class="row row-cols-xl-4 row-cols-sm-2 row-cols-1 gy-4 gy-xl-0">
            @foreach ($services as $service)
            <div class="col">
                <div class="simple-service px-3 md-my-10 d-flex align-items-center">
                    <div class="box-80px rounded-pill position-relative bg-white"><i class="{{$service->icon}} fa-2x text-secondary xy-center position-absolute"></i></div>
                    <div class="ms-3">
                        <h5 class="mb-1 font-500"><a href="javascript:;" class="text-dark hover-text-primary transation-this">{{$service->title}}</a></h5>
                        <div class="font-small text-secondary">
                            <span>{{$service->text}}</span>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>