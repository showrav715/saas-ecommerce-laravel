<div class="container-fluid px-sm-5">
    <div class="position-relative">
        <span class="nextBtn"></span>
        <span class="prevBtn"></span>
        <section class="home-slider owl-theme owl-carousel">
            @foreach ($sliders as $data)
                <div class="banner-slide-item"
                    style="background: url('{{ getPhoto($data->photo, getUser('user_id')) }}') no-repeat center center / cover ;">
                    <div class="container">
                        <div class="banner-wrapper-item text-{{ $data->type }}">
                            <div class="banner-content text-dark">
                                <h2 class="title text-dark slide-h5">{{ $data->title }}</h2>
                                <p class="slide-h5">{{ $data->text }}</p>

                                <a href="{{ $data->url }}" class="cmn--btn ">{{ $data->btn_text }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </section>
    </div>
</div>
