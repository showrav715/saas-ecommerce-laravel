<div class="full-row px-sm-5">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="text-center font-500 mb-40">@lang('Posts')</h2>
            </div>
        </div>
        <div class="row row-cols-xl-3 row-cols-md-2 row-cols-1 g-4 gy-xl-0">
            @foreach ($blogs as $blog)
            <div class="col">
                <div class="thumb-blog-simple transation hover-img-zoom">
                    <div class="post-image overflow-hidden">
                        <img src="{{getPhoto($blog->photo,getUser('user_id'))}}" alt="Image not found!">
                    </div>
                    <div class="post-content">
                        <div class="post-meta font-small text-uppercase list-color-primary">
                            <a href="blog-grid.html"><span>{{$blog->category->name}}</span></a>
                        </div>
                        <h5>
                            <a href="{{route('seller.front.blog.show',$blog->slug)}}" class="transation text-dark hover-text-primary d-table my-10 font-500">
                                {{$blog->title}}
                            </a>
                        </h5>
                        <p>
                            {{Str::limit(strip_tags($blog->description), 100)}}
                        </p>
                        <a href="{{route('seller.front.blog.show',$blog->slug)}}" class="btn-link-down-line d-table">@lang('Read More')</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>