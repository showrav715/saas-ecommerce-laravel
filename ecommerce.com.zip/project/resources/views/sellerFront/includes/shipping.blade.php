<p class="form-row form-row-wide address-field">
<label for="shipping_fee" class="">@lang('Shipping')&nbsp;<abbr
        class="required" title="required">*</abbr></label>
<span class="woocommerce-input-wrapper">
    <select name="shipping_fee" id="shipping_fee">
        <option value="" selected disabled>@lang('Select Shipping')</option>
        @foreach ($shippings as $shipping)
            <option value="{{ $shipping->id }}" data-price="{{$shipping->price}}" data-convert-price="{{sellerConvertAmount($shipping->price)}}">
                {{ $shipping->shipping }}
            </option>
        @endforeach
    </select>
</span>
</p>