@extends('layouts.sellerFront')

@section('content')
    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Contact')</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Contact')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="full-row">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <h3 class="down-line mb-5">@lang('Send Message')</h3>
                    <div class="form-simple mb-5">
                        <form id="contact-form" action="{{ route('seller.front.contact.submit') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label>@lang('Full Name:')</label>
                                        <input type="text" class="form-control bg-gray" name="name">
                                        @error('name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label>@lang('Your Email:')</label>
                                        <input type="email" class="form-control bg-gray" name="email">
                                        @error('email')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label>@lang('Subject:')</label>
                                        <input type="text" class="form-control bg-gray" name="subject">
                                        @error('subject')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label>@lang('Message:')</label>
                                        <textarea class="form-control bg-gray" name="message" rows="8"></textarea>
                                        @error('message')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn btn-primary" type="submit">@lang('Send Message')</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5 col-md-5">
                    <h3 class="down-line mb-5">{{ $contactPage->title }}</h3>
                    <p>{{ $contactPage->text }}</p>
                    <div class="d-flex mb-3">
                        <ul>
                            <li class="mb-3">
                                <strong>@lang('Office Address :')</strong><br> {{ $contactPage->office_address }}
                            </li>
                            <li class="mb-3">
                                <strong>@lang('Contact Number :')</strong><br> {{ $contactPage->contact_number }}
                            </li>
                            <li class="mb-3">
                                <strong>@lang('Email Address :')</strong><br> {{ $contactPage->email_address }}
                            </li>
                        </ul>
                    </div>
                    <h4 class="mb-2">@lang('Career Info')</h4>
                    <p>{{ strip_tags($contactPage->career_info) }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
