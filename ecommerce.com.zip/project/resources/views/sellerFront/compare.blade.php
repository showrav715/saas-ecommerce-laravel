@extends('layouts.sellerFront')

@section('content')


    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Compare')</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Compare')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <!-- breadcrumb -->
    <!-- Compare Area Start -->
    <section class="compare-page pb-5">
        <div class="container">
            @if (Session::has('compare' . sellerId()))
                <div class="row">
                    <div class="col-lg-12">
                        <div class="content">
                            <div class="com-heading">
                                <h2 class="title py-4">
                                    {{ __('Product Compare') }}
                                </h2>
                            </div>
                            <div class="compare-page-content-wrap">
                                <div class="compare-table table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <tbody>
                                            @if (count($products) > 0)
                                            <tr>
                                                <td class="first-column top">{{ __('Product Name') }}</td>
                                                @foreach ($products as $product)
                                                    <td class="product-image-title c{{ $product['item']['id'] }}">
                                                        <div class="position-relative">
                                                        <img class="img-fluid"
                                                            src="{{ getPhoto($product['item']['photo'], sellerId()) }}"
                                                            alt="Compare product['item']">
                                                            
                                                        <div class="pro-remove __pro-remove c{{ $product['item']['id'] }}">
                                                            <a href="{{ route('seller.front.compare.remove', $product['item']['id']) }}"><i class="far fa-trash-alt compare-remove"></i></a>
                                                        </div>
                                                        </div>
                                                        <a class="d-block mt-3"
                                                            href="{{ route('seller.front.product.details', $product['item']['slug']) }}">
                                                            <h4 class="title1">
                                                                {{ $product['item']['name'] }}
                                                            </h4>
                                                        </a>
                                                    </td>
                                                @endforeach
                                            </tr>
                                            <tr>
                                                <td class="first-column">{{ __('Price') }}</td>
                                                @foreach ($products as $product)
                                                    <td class="pro-price c{{ $product['item']['id'] }}">
                                                        {{ productBasePrice($product['item']) }}
                                                    </td>
                                                @endforeach
                                            </tr>
                                            <tr>
                                                <td class="first-column">{{ __('Rating') }}</td>
                                                @foreach ($products as $product)
                                                    <td class="pro-ratting c{{ $product['item']['id'] }}">
                                                        <div class="ratings">
                                                            <div class="empty-stars"></div>
                                                            <div class="full-stars" style="width:50%"></div>
                                                        </div>
                                                    </td>
                                                @endforeach
                                            </tr>
                                            <tr>
                                                <td class="first-column">{{ __('Description') }}</td>
                                                @foreach ($products as $product)
                                                    <td class="pro-desc c{{ $product['item']['id'] }}">
                                                        <p>{{ strip_tags($product['item']['details']) }}</p>
                                                    </td>
                                                @endforeach
                                            </tr>
                                            <tr>
                                                <td class="first-column">{{ __('') }}</td>
                                                @foreach ($products as $product)
                                                    <td>
                                                        <div class="p-2">
                                                        <a href="javascript:;"
                                                            data-href="{{ route('seller.front.cart.store') }}"
                                                            class="cmn-btn add__to__cart"
                                                            itemid="{{ $product['item']['id'] }}" class="add-cart"
                                                            data-href="">{{ __('Add to Cart') }}</a></div>
                                                    </td>
                                                @endforeach
                                            </tr>
                                            @else
                                                <tr>
                                                    <td class="first-column p-5 text-center">{{ __('No Product To Compare.') }}</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <div class="row mb-2">
                    <div class="col-lg-12">
                        <div class="content">
                            <div class="com-heading ">
                                <h2 class="title p-5 text-center text-center">
                                    {{ __('No Product To Compare.') }}
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </section>
@endsection
