@extends('layouts.sellerFront')

@section('content')
    <!--==================== Header Section End ====================-->

        <!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 class="mb-2 text-secondary">{{ucwords($page->title)}}</h3>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="{{route('seller.front.index')}}"><i class="fas fa-home me-1"></i>@lang('Home')</a></li>
                                <li class="breadcrumb-item"><a href="javascript:;">@lang('Pages')</a></li>
                                <li class="breadcrumb-item active" aria-current="page">{{$page->title}}</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== About Owner Section Start ====================-->
        <div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <h3 class="text-dark down-line-primary mb-4">{{$page->title}}</h3>
                        <p class="text-secondary">{{strip_tags($page->details)}}</p>
                    </div>
                </div>
            </div>
        </div>

@endsection

