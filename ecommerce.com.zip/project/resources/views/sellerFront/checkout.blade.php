@extends('layouts.sellerFront')

@section('content')
<!-- breadcrumb -->
<div class="full-row bg-light py-5">
    <div class="container">
        <div class="row text-secondary">
            <div class="col-sm-6">
                <h3 class="mb-2 text-secondary">@lang('Checkout')</h3>
            </div>
            <div class="col-sm-6">
                <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                    <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                        <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                    class="fas fa-home me-1"></i>@lang('Home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">@lang('Checkout')</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb -->
<!--==================== Checkout Section Start ====================-->
<div id="main-content" class="full-row site-content">
    <div class="container">
        <div class="row ">
            <div id="primary" class="content-area col-md-12">
                <article id="post-19" class="post-19 page type-page status-publish hentry">
                    <div class="entry-content">
                        <div class="woocommerce">
                            <div class="woocommerce-form-coupon-toggle">
                                <div class="woocommerce-info">
                                    @lang('Have a coupon?') <a href="{{ route('seller.front.cart.index') }}"
                                        class="showcoupon">@lang('Click here to enter your code')</a>
                                </div>
                            </div>
                            <form method="post" class="checkout__form" action="" id="">
                                @csrf
                                <div class="row">
                                    <div class="col-lg-7">
                                        <div class="card border-0 bg-section">
                                            <div class="card-body">
                                                <div class="col2-set" id="customer_details">
                                                    <div class="woocommerce-billing-fields">
                                                        <h3>@lang('Billing details')</h3>
                                                        <div class="woocommerce-billing-fields__field-wrapper">
                                                            <p class="form-row" id="name">
                                                                <label for="billing_first_name">@lang('Name')&nbsp;<abbr
                                                                        class="required" title="required">*</abbr></label>

                                                                <input type="text" class="input-text " name="name"
                                                                    id="billing_first_name"
                                                                    value="{{ old('name', $user->name) }}">
                                                                @error('name')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </p>
                                                            <p class="form-row" id="" data-priority="20">
                                                                <label for="email">@lang('Email')
                                                                    &nbsp;<abbr class="required"
                                                                        title="required">*</abbr></label>
                                                                <input type="text" class="input-text " name="email"
                                                                    id="email" value="{{ old('email', $user->email) }}">
                                                                @error('email')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </p>
                                                            <input type="hidden" name="sub" id="sub" value="0">
                                                            <input type="hidden" name="ref_id" id="ref_id" value="">
                                                            <p class="form-row" id="" data-priority="20">
                                                                <label for="phone">@lang('Phone')
                                                                    &nbsp;<abbr class="required"
                                                                        title="required">*</abbr></label>
                                                                <input type="text" class="input-text " name="phone"
                                                                    id="phone" value="{{ old('phone', $user->phone) }}"
                                                                    autocomplete="family-name">
                                                                @error('phone')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </p>

                                                            <p class="form-row form-row-wide address-field">
                                                                <label for="checkout__location">@lang('Location')&nbsp;</label>
                                                                <select name="location" id="checkout__location"
                                                                    class="country_to_state country_select" required>
                                                                    <option value="" selected disabled>
                                                                        @lang('Select Location')</option>
                                                                    @foreach ($locations as $location)
                                                                        <option
                                                                            value="{{ route('seller.front.get.shipping', $location->id) }}">
                                                                            {{ $location->location }}</option>
                                                                    @endforeach
                                                                </select>
                                                                @error('location')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </p>

                                                            <div id="shipping_address" class="woocommerce-checkout-payment">
                                                                {{-- here add shipping --}}
                                                            </div>

                                                            <p class="form-row address-field ">
                                                                <label for="delivery_address">@lang('Delivery Address')&nbsp;<abbr
                                                                        class="required" title="required">*</abbr></label>
                                                                <input type="text" class="input-text "
                                                                    name="delivery_address" id="delivery_address"
                                                                    placeholder="Apartment, suite, unit, etc"
                                                                    value="{{ old('delivery_address', $user->address) }}">
                                                                @error('delivery_address')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </p>

                                                            <p class="form-row">
                                                                <label for="zip">@lang('ZIP')&nbsp;<abbr
                                                                        class="required" title="required">*</abbr></label>
                                                                <input type="text" class="input-text " name="zip"
                                                                    id="zip" value="{{ old('zip', $user->zip) }}">
                                                                @error('zip')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </p>
                                                        </div>
                                                    </div>

                                                    
                                                    <div class="woocommerce-additional-fields">
                                                        <div class="woocommerce-additional-fields__field-wrapper">
                                                            <p class="form-row notes" id="order_comments_field"
                                                                data-priority=""><label
                                                                    for="order_comments">@lang('Order notes')&nbsp;<span
                                                                        class="optional">@lang('(optional)')</span></label><span
                                                                    class="woocommerce-input-wrapper">
                                                                    <textarea name="order_comments" class="input-text " id="order_comments"
                                                                        placeholder="" rows="2" cols="5"></textarea>
                                                                </span></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-5">
                                        <div class="order-review-inner">
                                            <div id="order_review" class="woocommerce-checkout-review-order py-4">
                                                <h3 id="order_review_heading">@lang('Your order')</h3>
                                                <table class="shop_table woocommerce-checkout-review-order-table">
                                                    <thead>
                                                        <tr>
                                                            <th class="product-name">@lang('Product')</th>
                                                            <th class="product-total">@lang('Subtotal')</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @php
                                                            $cart = Session::get('cart' . sellerId());
                                                            $total = 0;
                                                        @endphp
                                                        @foreach ($cart as $item)
                                                            @php
                                                                $total += $item['cart_item_price'];
                                                            @endphp
                                                            <tr class="cart_item">
                                                                <td class="product-name">
                                                                    {{ $item['name'] }}
                                                                    <strong
                                                                        class="product-quantity">×&nbsp;{{ $item['quantity'] }}</strong>
                                                                </td>
                                                                <td class="product-total">
                                                                    <bdi>{{ sellerShowAmount($item['cart_item_price']) }}</bdi>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                    <tfoot>
                                                        <tr class="cart-subtotal">
                                                            <th>@lang('Subtotal')</th>
                                                            <td><span class="woocommerce-Price-amount amount"><bdi><span
                                                                            class="woocommerce-Price-currencySymbol">{{ sellerShowAmount($total) }}</span></bdi>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr class="order-total">
                                                            <th>@lang('Discount')</th>
                                                            <td><strong><span
                                                                        class="woocommerce-Price-amount amount"><bdi>{{ sellerShowAmount(@$discount['discount']) }}</bdi></span></strong>
                                                                @if (isset($discount['coupon']))
                                                                    <small>
                                                                        ({{ $discount['coupon']['percentage'] }})%</small>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                        <tr class="order-total">
                                                            <th>@lang('Shipping Fee')</th>
                                                            <td><strong><span
                                                                        class="woocommerce-Price-amount shipping_fee"><bdi
                                                                            class="shpping_fee_show">{{ sellerShowAmount(0) }}</bdi></span></strong>
                                                            </td>
                                                        </tr>
                                                        @php
                                                            $total = $total - @$discount['discount'];
                                                        @endphp
                                                        <tr class="order-total">
                                                            <th>@lang('Total')</th>
                                                            <td><strong><span class="woocommerce-Price-amount amount">
                                                                        <span
                                                                            class="woocommerce-Price-currencySymbol"></span>
                                                                        <bdi id="grand__total"
                                                                            data-grand-price="{{ sellerConvertAmount($total) }}"
                                                                            data-convert-price="{{ sellerConvertAmount($total) }}">{{ sellerShowAmount($total) }}</bdi></span></strong>
                                                            </td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                            <div id="payment" class="woocommerce-checkout-payment">
                                                <div class="wc_payment_methods payment_methods methods">
                                                    @foreach ($payment_gatewayes as $gateway)
                                                        <label class="wc_payment_method form-check ps-4 {{ $gateway->keyword }}">
                                                            <input required id="i{{ $gateway->keyword }}"
                                                                data-keyword="{{ $gateway->keyword }}"
                                                                data-form="{{ $gateway->showForm() }}"
                                                                data-href="{{ $gateway->showCheckoutLink() }}"
                                                                form-get="{{ $gateway->formUrl() }}" type="radio"
                                                                class="form-check-input payment_gateway_option"
                                                                name="payment_method"
                                                                value="{{ $gateway->keyword }}">
                                                            <span for="i{{ $gateway->keyword }}" class="form-check-label">
                                                                {{ $gateway->name }} </span>
                                                            @if ($gateway->type != 'manual')
                                                                <div class="payment_box"
                                                                    id="show{{ $gateway->keyword }}">
                                                                    <P>{{ $gateway->getAutoDataText() }}</P>
                                                                </div>
                                                            @else
                                                                <div class="payment_box"
                                                                    id="show{{ $gateway->keyword }}">
                                                                </div>
                                                            @endif
                                                        </label>
                                                    @endforeach
                                                </div>
                                                <div class="form-row place-order">
                                                    <button type="submit"
                                                        id="place_order">@lang('Place order')</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>
@endsection


@section('scripts')
<script src="https://js.paystack.co/v1/inline.js"></script>
<script>
    $(document).on('change', '#checkout__location', function() {
        var route = $(this).val();
        $.ajax({
            url: route,
            type: 'GET',
            success: function(data) {
                console.log(data);
                $('#shipping_address').html(data);
            }
        });
    })


        function showAmountt(amount){
    let direction = '{{sellerCurrencyDirection()}}';
    if(direction == 'left'){
        return '{{sellerCurrency()}}'+ parseFloat(amount).toFixed(2);
    }else{
        return parseFloat(amount).toFixed(2)+'{{sellerCurrency()}}';
    } 
}

    $(document).on('click', '.payment_gateway_option', function() {

        var form = $(this).attr('data-form');
        var href = $(this).attr('data-href');
        var formType = $(this).attr('data-form');
        $('.checkout__form').attr('action', href);
        var keyword = $(this).attr('data-keyword');
        $('form').attr('id', keyword)
        if (formType == 'yes') {
            var formUrl = $(this).attr('form-get');
            $('#show' + keyword).load(formUrl);
        }
    })

    $(document).on('change', '#shipping_fee', function() {
        var shipping_fee_price = $(this).find(':selected').attr('data-convert-price');
        shipping_fee_price = parseFloat(shipping_fee_price).toFixed(2);
        var grand_total = $('#grand__total').attr('data-convert-price');
        grand_total = parseFloat(grand_total).toFixed(2);
        $('.shipping_fee .shpping_fee_show').html(showAmountt(shipping_fee_price));
        $('#grand__total').html(showAmountt(parseFloat(shipping_fee_price) + parseFloat(grand_total)));
        $('#grand__total').attr('data-grand-price', parseFloat(shipping_fee_price) + parseFloat(grand_total));
    })

    $(document).on('submit', '#paystack', function() {
        var val = $('#sub').val();
        var total = $('#grand__total').attr('data-grand-price');
        total = Math.round(total);
        if (val == 0) {
            var handler = PaystackPop.setup({
                key: '{{ $paystackData['key'] }}',
                email: '{{ Auth::user()->email }}',
                amount: total * 100,
                currency: '{{ sellerCurrencyCode() }}',
                ref: '' + Math.floor((Math.random() * 1000000000) + 1),
                callback: function(response) {
                    $('#ref_id').val(response.reference);
                    $('#sub').val('1');
                    $('#form').attr('id', '');
                    $('#place_order').click();
                },
                onClose: function() {
                    window.location.reload();
                }
            });
            handler.openIframe();
            return false;
        } else {

            return true;
        }
        return false
    });
</script>
@endsection
