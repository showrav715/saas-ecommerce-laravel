@extends('layouts.sellerFront')

@section('content')

@include('sellerFront.includes.slider')
@include('sellerFront.includes.category')
@include('sellerFront.includes.best_offer')
@include('sellerFront.includes.highlight')
@include('sellerFront.includes.services')
@include('sellerFront.includes.best_selling')
@include('sellerFront.includes.bottom_banner')
@include('sellerFront.includes.blogs')
@endsection