@extends('layouts.sellerFront')
@section('content')
    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">{{$blog->title}}</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item" aria-current="page"><a href="{{route('seller.front.blog')}}">@lang('Blog')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Blogs Details')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

<div class="full-row">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 md-mb-50 order-lg-2">
                <div id="sidebar" class="sidebar-blog bg-light p-30">
                    <div class="widget border-0 py-0 search-widget">
                        <form action="{{route('seller.front.blog')}}" method="get">
                            <input type="text" class="form-control bg-light" name="search" placeholder="{{__('Search')}}">
                            <button type="submit" name="submit" class="bg-light"><i class="flaticon-search flat-mini text-secondary"></i></button>
                        </form>
                    </div>
                    <div class="widget border-0 py-0 widget_categories">
                        <h4 class="widget-title down-line">@lang('Categories')</h4>
                        <ul>
                            <li><a href="{{route('seller.front.blog')}}">@lang('All')</a></li>
                            @foreach ($blog_categories as $category)
                            <li class="{{$category->slug == request()->category ? 'active' : ''}}"><a href="{{route('seller.front.blog').'?category='.$category->slug}}">{{$category->name}}</a> ({{$category->blogs_count}})</li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="widget border-0 py-0 widget_recent_entries">
                        <h4 class="widget-title down-line">@lang('Recent Post')</h4>
                        <ul>
                            @foreach ($recent_blogs as $recent)
                            <li class="border py-2 px-3">
                                <a href="{{route('seller.front.blog.show',$recent->slug)}}" class="__recent-posts">
                                    <img src="{{asset('/assets/images/10291072731674966449.png')}}" alt="">
                                    <div class="__inf">
                                        <div class="tt">{{$recent->title}}</div>
                                        <span class="post-date">{{$recent->created_at->format('d/M/Y')}}</span>
                                    </div>
                                </a>
                            </li> 
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 order-lg-1">
                <div class="single-post">
                    <div class="single-post-title">
                        <h3 class="mb-2 text-secondary">{{$blog->title}}</h3>
                        <div class="post-meta mb-4">
                            <a href="javascript:;"><i class="flaticon-user-silhouette flat-mini"></i> <span>@lang('By Admin')</span></a>
                            <a href="javascript:;"><i class="flaticon-calendar flat-mini"></i> <span>{{$blog->created_at->format('d/M/Y')}}</span></a>
                            <span><i class="flaticon-document flat-mini text-primary"></i> <a href="{{route('seller.front.blog').'?category'.$blog->category->slug}}"><span>{{$blog->category->name}}</span></a></span>
                        </div>
                    </div>
                    <div class="post-image">
                        <img src="{{getPhoto($blog->photo,getUser('user_id'))}}" class="w-100" alt="Image not found!">
                    </div>
                    <div class="post-content pt-4 mb-5">
                       {{ strip_tags($blog->description) }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection