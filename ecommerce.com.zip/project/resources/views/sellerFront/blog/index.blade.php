@extends('layouts.sellerFront')

@section('content')
    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary">@lang('Blog Posts')</h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}"><i
                                        class="fas fa-home me-1"></i>@lang('Home')</a></li>
                            <li class="breadcrumb-item active" aria-current="page">@lang('Blogs')</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

<div class="full-row">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 md-mb-50">
                <div id="sidebar" class="sidebar-blog bg-light p-30">
                    <div class="widget border-0 py-0 search-widget">
                        <form action="{{route('seller.front.blog')}}" method="get">
                            <input type="text" class="form-control bg-light" name="search" placeholder="Search">
                            <button type="submit" name="submit" class="bg-light"><i class="flaticon-search flat-mini text-secondary"></i></button>
                        </form>
                    </div>
                    <div class="widget border-0 py-0 widget_categories">
                        <h4 class="widget-title down-line">@lang('Categories')</h4>
                        <ul>
                            <li><a href="{{route('seller.front.blog')}}">@lang('All')</a></li>
                            @foreach ($blog_categories as $category)
                            <li class="{{$category->slug == request()->category ? 'active' : ''}}"><a href="{{route('seller.front.blog').'?category='.$category->slug}}">{{$category->name}}</a> ({{$category->blogs_count}})</li>
                            @endforeach
                            
                        </ul>
                    </div>
                    <div class="widget border-0 py-0 widget_recent_entries">
                        <h4 class="widget-title down-line">@lang('Recent Post')</h4>
                        <ul>
                            @foreach ($recent_blogs as $recent)
                            <li class="border py-2 px-3">
                                <a href="{{route('seller.front.blog.show',$recent->slug)}}">{{$recent->title}}</a>
                                <span class="post-date">{{$recent->created_at->format('d/M/Y')}}</span>
                            </li> 
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="row">
                    @forelse ($blogs as $blog)
                    <div class="col-md-12">
                        <div class="thumb-blog-horizontal clearfix hover-img-zoom transation mb-30">
                            <div class="post-image overflow-hidden">
                                <img src="{{getPhoto($blog->photo,getUser('user_id'))}}" alt="Image not found!">
                            </div>
                            <div class="post-content ps-3">
                                <div class="post-meta font-mini text-uppercase list-color-light">
                                    <a href="{{route('seller.front.blog.show',$blog->slug)}}"><span>{{$blog->category->name}}</span></a>
                                </div>
                                <h4 class="mb-2"><a href="{{route('seller.front.blog.show',$blog->slug)}}" class="transation text-dark hover-text-primary d-block">{{$blog->title}}</a></h4>
                                <p>{{Str::limit(strip_tags($blog->description), 250)}}</p>
                                <div class="date text-primary font-small text-uppercase"><span>{{$blog->created_at->format('d/M/Y')}}</span></div>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="col-md-12 text-center" >
                        <div class="border p-5">
                            <h4>@lang('Blog not found!')</h4>
                        </div>
                    </div>
                    @endforelse
                   
                   
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
