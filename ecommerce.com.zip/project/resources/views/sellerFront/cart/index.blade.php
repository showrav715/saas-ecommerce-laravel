@extends('layouts.sellerFront')

@section('content')
<div class="full-row bg-light py-5">
    <div class="container">
        <div class="row text-secondary">
            <div class="col-sm-6">
                <h3 class="mb-2 text-secondary">@lang('Cart Page')</h3>
            </div>
            <div class="col-sm-6">
                <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                    <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                        <li class="breadcrumb-item"><a href="{{route('seller.front.index')}}"><i class="fas fa-home me-1"></i>@lang('Home')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">@lang('Cart Page')</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>



<div class="full-row">
    <div class="container">
        <div class="row" id="show__cart" data-href="{{route('seller.front.cart.refresh')}}">
           @include('sellerFront.inc.cart')
        </div>
    </div>
</div>
@endsection


@section('scripts')
<script>
    'use strict';
    $(document).on('click','.quantity-cart',function(){
        let itemId = $(this).attr('data-item');
        let quantity = $('#'+itemId).val();
        let type = 'quantity_update';
        $.ajax({
            url: "{{route('seller.front.cart.store')}}",
            type: "POST",
            data: {
                // csrf token
                _token: "{{ csrf_token() }}",
                itemId: itemId,
                quantity: quantity,
                type: type,
            },
            success: function (data) {
                $("#show__cart").html(data);
            },
    })
    });
 
 

    $(document).on('submit','#couponForm', function(e) {

        e.preventDefault();
        var form = $(this);
        var url = form.attr('action');
        var method = form.attr('method');
        var data = form.serialize();
        $.ajax({
            url: url,
            method: method,
            data: data,
            success: function(response) {
                if(response.success){
                    Toast.fire({
                    icon: 'success',
                    title: response.success
                    })
                    $("#show__cart").load($('#show__cart').attr('data-href'));
                }
                if(response.error){
                    Toast.fire({
                    icon: 'error',
                    title: response.error
                    })
                }
            }
        });
    });

</script>

    
@endsection