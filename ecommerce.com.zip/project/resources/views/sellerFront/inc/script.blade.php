<script src="{{ asset('assets/front') }}/js/jquery.min.js"></script>
<script src="{{ asset('assets/front') }}/js/greensock.js"></script>
<script src="{{ asset('assets/front') }}/js/layerslider.transitions.js"></script>
<script src="{{ asset('assets/front') }}/js/layerslider.kreaturamedia.jquery.js"></script>
<script src="{{ asset('assets/front') }}/js/popper.min.js"></script>
<script src="{{ asset('assets/front') }}/js/bootstrap.min.js"></script>
<script src="{{ asset('assets/front') }}/js/owl.carousel.min.js"></script>
<script src="{{ asset('assets/front') }}/js/wow.js"></script>
<script src="{{ asset('assets/front') }}/js/jquery.countdown.js"></script>
<script src="{{ asset('assets/front') }}/js/sweetalert.js"></script>
<script src="{{ asset('assets/front') }}/js/jquery.elevatezoom.js"></script>
<script src="{{ asset('assets/front') }}/js/custom.js"></script>
<script src="{{ asset('assets/front') }}/js/myscript.js"></script>
<script src="{{ asset('assets/front') }}/js/user.js"></script>

@yield('scripts')
<script>
    'use strict';
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })

    function showAmount(amount){
        let direction = '{{sellerCurrencyDirection()}}';
        if(direction == 'left'){
            return '{{sellerCurrency()}}'+ parseFloat(amount).toFixed(2);
        }else{
            return parseFloat(amount).toFixed(2)+'{{sellerCurrency()}}';
        } 
    }

    $("#single-image-zoom").elevateZoom({
            gallery: 'gallery_09',
            zoomType: "inner",
            cursor: "crosshair",
            galleryActiveClass: 'active',
            imageCrossfade: true,
            loadingIcon: 'http://www.elevateweb.co.uk/spinner.gif'
        });
        //pass the images to Fancybox
        $("#single-image-zoom").bind("click", function(e) {
            var ez = $('#single-image-zoom').data('elevateZoom');
            $.fancybox(ez.getGalleryList());
            return false;
        });
</script>

@if (Session::has('success'))
    <script>
        'use strict';
        Toast.fire({
        icon: 'success',
        title: '{{Session::get('success')}}'
        })
    </script>
@endif


@if (Session::has('error'))
    <script>
        'use strict';
        Toast.fire({
        icon: 'error',
        title: '{{Session::get('error')}}'
    })
    </script>
@endif