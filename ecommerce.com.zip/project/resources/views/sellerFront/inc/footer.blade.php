        <!--==================== Footer Section Start ====================-->
        <footer class="full-row bg-white border-footer p-0">
            <div class="container">
                <div class="row ">
                    <div class="col-sm">
                        <div class="footer-widget my-5">
                            <div class="footer-logo mb-4">
                                <a href="{{route('seller.front.index')}}"><img src="{{getPhoto($gs->footer_logo,getUser('user_id'))}}" alt="Image not found!" /></a>
                            </div>
                
                            <div class="widget-ecommerce-contact">
                                <div class="text-general mt-20">
                                    {!! wordwrap($gs->footer_text, 35, "<br>", true) !!}
                                </div>
                            </div>
                          
                        </div>
                      
                        <div class="footer-widget media-widget">
                            @if (@$socialLink->icon && $socialLink->url)
                            <a href="{{$socialLink->url}}"><i class="{{$socialLink->icon}}"></i></a>
                            @endif
                            @if(@$socialLink->icon1 && $socialLink->url1)
                            <a href="{{$socialLink->url1}}"><i class="{{$socialLink->icon1}}"></i></a>
                            @endif
                            @if(@$socialLink->icon2 && $socialLink->url2)
                            <a href="{{$socialLink->url2}}"><i class="{{$socialLink->icon2}}"></i></a>
                            @endif
                            @if(@$socialLink->icon3 && $socialLink->url3)
                            <a href="{{$socialLink->url3}}"><i class="{{$socialLink->icon3}}"></i></a>
                            @endif
                            @if(@$socialLink->icon4 && $socialLink->url4)
                            <a href="{{$socialLink->url4}}"><i class="{{$socialLink->icon4}}"></i></a>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm col-6">
                        <div class="footer-widget category-widget my-5">
                            <h6 class="widget-title mb-sm-4">@lang('Important Link')</h6>
                            <ul>
                                <li><a href="{{route('seller.front.index')}}">@lang('Home')</a></li>
                                <li><a href="{{route('seller.front.contact')}}">@lang('Contact')</a></li>
                                <li><a href="{{route('seller.front.blog')}}">@lang('Blog')</a></li>
                                @php
                                    $pages = DB::table('user_pages')->whereUserId(getUser('user_id'))->get();
                                @endphp
                                @foreach ($pages as $page)
                                <li><a href="{{ route('seller.front.page', $page->slug) }}">{{ $page->title }}</a></li>
                                @endforeach
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm col-6">
                        <div class="footer-widget category-widget my-5">
                            <h6 class="widget-title mb-sm-4">@lang('Latest Blog')</h6>
                            <ul>
                                @foreach (DB::table('user_blogs')->whereUserId(sellerId())->orderby('id','desc')->take(5)->get() as $blog)

                                <li>
                                    <a href="{{route('seller.front.blog.show',$blog->slug)}}" class="__recent-posts">
                                        <img src="{{getPhoto($blog->photo,sellerId())}}" style="width:50px" alt="">
                                        <div class="__inf">
                                            <div class="tt">{{$blog->title}}</div>
                                        </div>
                                    </a>
                                </li> 
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--==================== Footer Section End ====================-->

        <!--==================== Copyright Section Start ====================-->
        <div class="full-row copyright bg-white py-3">
            <div class="container">
                <div class="row">
                    
                    @if ($gs->copyright_show == 1)
                    <div class="col-md-6">
                        <span class="sm-mb-10 d-block">{{$gs->copyright_text}}</span>
                    </div>
                    @endif
                </div>
            </div>
        </div>
        <!--==================== Copyright Section End ====================-->
        <!-- Scroll to top -->
        <a href="#" class="bg-primary text-white" id="scroll"><i class="fa fa-angle-up"></i></a>
        <!-- End Scroll To top -->
		