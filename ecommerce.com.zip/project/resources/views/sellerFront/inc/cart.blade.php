@php
    if (Session::has('cart' . getUser('user_id'))) {
        $cart = Session::get('cart' . getUser('user_id'));
    } else {
        $cart = [];
    }
@endphp

@if ($cart)
    <div class="col-xl-8 col-lg-12 col-md-12 col-12">
            <table class="shop_table cart">
                <tr>
                    <th class="product-thumbnail">&nbsp;</th>
                    <th class="product-name">@lang('Product')</th>
                    <th class="product-price">@lang('Price')</th>
                    <th class="product-quantity">@lang('Quantity')</th>
                    <th class="product-subtotal">@lang('Subtotal')</th>
                    <th class="product-remove">&nbsp;</th>
                </tr>
                @php
                    $total = 0;
                    $totalQty = 0;
                @endphp
                @foreach ($cart as $cartKey => $item)
                    @php
                        $total += $item['cart_item_price'];
                        $totalQty += $item['quantity'];
                    @endphp
                    <tr class="woocommerce-cart-form__cart-item cart_item">
                        <td class="product-thumbnail">
                            <a href="{{ route('seller.front.product.details', $item['slug']) }}"><img
                                    src="{{ $item['photo'] }}" alt="Product image"></a>
                        </td>
                        <td class="product-name">
                            <a href="{{ route('seller.front.product.details', $item['slug']) }}">{{ $item['name'] }}</a>
                            @if (isset($item['color']))
                                <div class="variation">
                                    <span>Color:</span>
                                    <span>{{ $item['color']['color_name'] }}</span>
                                </div>
                            @endif
                            @if ($item['attributes'])
                                @foreach ($item['attributes'] as $key => $attr)
                                    <div class="variation">
                                        <span>{{ $key }}:</span>
                                        <span>{{ $attr['name'] }} + {{ sellerShowAmount($attr['price']) }}</span>
                                    </div>
                                @endforeach
                            @endif
                        </td>

                        <td class="product-price">
                            <span><bdi>{{ sellerShowAmount($item['cart_single_price']) }}</bdi></span>
                        </td>

                        <td class="product-quantity">
                            @if ($item['type'] == 0)
                            <div class="quantity">
                                <input type="number" name="quantity" min="1" max="{{ $item['item_stock'] }}"
                                    step="1" value="{{ $item['quantity'] }}" id="{{ $cartKey }}">
                                <div class="quantity-nav">
                                    <div class="quantity-button quantity-cart quantity-down"
                                        data-item="{{ $cartKey }}">-</div>
                                    <div class="quantity-button quantity-cart quantity-up"
                                        data-item="{{ $cartKey }}">+</div>
                                </div>
                            </div> 
                            @else
                            --
                            @endif
                        </td>

                        <td class="product-subtotal">
                            <span><bdi>{{ sellerShowAmount($item['cart_item_price']) }}</bdi>
                            </span>
                        </td>
                        <td class="product-remove">
                            <a href="javascript:;" class="cart__item__remove remove"
                                data-href="{{ route('seller.front.cart.remove', $cartKey) }}">×</a>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <td colspan="6" class="actions">
                        <form action="{{ route('seller.front.cart.coupon') }}" id="couponForm" method="POST">
                            @csrf
                            <div class="coupon">
                                <label for="coupon_code">@lang('Coupon:')</label>
                                <input type="text" name="coupon_code" class="input-text" id="coupon_code"
                                    value="" placeholder="Coupon code">
                                <button type="submit" class="button">@lang('Apply coupon')</button>
                            </div>
                        </form>
                    </td>
                </tr>
            </table>
    </div>
    <div class="col-xl-4 col-lg-12 col-md-12 col-12">
        <div class="cart-collaterals">
            <div class="cart_totals ">
                <h2>@lang('Cart totals')</h2>
                <table>
                    <tr>
                        <th>@lang('Total Items')</th>
                        <td>
                            <span><bdi><span>{{ $totalQty }}</bdi>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th>@lang('Subtotal')</th>
                        <td>
                            <span><bdi><span>{{ sellerShowAmount($total) }}</bdi>
                            </span>
                        </td>
                    </tr>
                  
                    <tr class="order-total">
                        <th>@lang('Discount')</th>
                        <td><strong><span class="woocommerce-Price-amount amount"><bdi>{{ sellerShowAmount(@$discount['discount']) }}</bdi></span></strong>
                        </td>
                    </tr>
                    <tr class="order-total">
                        <th>@lang('Total')</th>
                        <td><strong>
                           <bdi>{{ sellerShowAmount($total- @$discount['discount']) }}</bdi></strong>
                        </td>
                    </tr>
                </table>
                <div class="wc-proceed-to-checkout">
                    <a href="{{ route('seller.front.checkout.index') }}" class="checkout-button">@lang('Proceed to checkout')</a>
                </div>
            </div>
        </div>
    </div>
@else
    <div class="col-12">
        <div class="alert alert-warning" role="alert">
            <h4 class="alert-heading">@lang('Your cart is empty!')</h4>
            <p>@lang('It seems that your cart is currently empty. Would you like to go back to the shop?')</p>
            <hr>
            <p class="mb-0"><a href="{{route('seller.front.product.catalog')}}" class="btn btn-primary">@lang('Go to shop')</a></p>
        </div>
    </div>
@endif





<script>
    'use strict';
    // Quantity number changing script
    $(document).ready(function(){
        $('<div class="quantity-nav"><div class="quantity-button quantity-down">-</div><div class="quantity-button quantity-up">+</div></div>').insertAfter('.quantity input');

    $('.quantity').each(function() {
        var spinner = $(this),
            input = spinner.find('input[type="number"]'),
            btnUp = spinner.find('.quantity-up'),
            btnDown = spinner.find('.quantity-down'),
            min = input.attr('min'),
            max = input.attr('max');

        btnUp.on('click', function() {
            var oldValue = parseFloat(input.val());
            if (oldValue >= max) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue + 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });

        btnDown.on('click', function() {
            var oldValue = parseFloat(input.val());
            if (oldValue <= min) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue - 1;
            }
            spinner.find("input").val(newVal);
            spinner.find("input").trigger("change");
        });

    });
    })

</script>
