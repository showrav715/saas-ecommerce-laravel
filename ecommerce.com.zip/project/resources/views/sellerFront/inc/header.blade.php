    <!--==================== Header Section Start ====================-->
    <header class="ecommerce-header px-sm-5">
        <div class="top-header d-none d-lg-block py-2 border-0 font-400">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-4 sm-mx-none">
                        <a href="help-center.html" class="text-general"><span>@lang('Help & Support') :
                                {{ $gs->support_number }}</span></a>
                    </div>
                    <div class="col-lg-8 d-flex">
                        <ul class="top-links d-flex ms-auto align-items-center">
                            @if ($gs->currency_show == 1)
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle text-general" data-bs-toggle="dropdown"
                                        role="button" aria-haspopup="true"
                                        aria-expanded="false"><span>{{ sellerCurrencyCode() }}</span></a>
                                    <ul class="dropdown-menu">
                                        @foreach ($globalcurrency as $gcurrency)
                                            <li class=""><a
                                                    href="{{ route('seller.front.currency.set', $gcurrency->id) }}"
                                                    class="dropdown-item">{{ $gcurrency->code }}</a></li>
                                        @endforeach
                                    </ul>
                                </li>
                            @endif
                            @if ($gs->language_show == 1)
                                @php
                                    $language = \DB::table('languages')
                                        ->where('code', Session::get('lang'))
                                        ->first();
                                @endphp
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle text-general" data-bs-toggle="dropdown"
                                        role="button" aria-haspopup="true"
                                        aria-expanded="false"><span>{{ $language->language }}</span></a>
                                    <ul class="dropdown-menu">
                                        @foreach (App\Models\Language::get() as $language)
                                            <li><a href="{{ route('seller.front.language.set', $language->code) }}"
                                                    class="dropdown-item">{{ $language->language }}</a></li>
                                        @endforeach
                                    </ul>
                                </li>
                            @endif
                            <li class="my-account-dropdown">
                                <a href="my-account.html" class="has-dropdown"><i
                                        class="flaticon-user-3 flat-mini me-1"></i>@lang('My Account')</a>
                                <ul class="my-account-popup">
                                    @if (Auth::check())
                                        <li><a href="{{ route('seller.user.dashboard') }}"><span
                                                    class="menu-item-text">@lang('Dashboard')</span></a></li>
                                        <li><a href="{{ route('seller.user.profile') }}"><span
                                                    class="menu-item-text">@lang('Profile')</span></a></li>
                                        <li><a href="{{ route('seller.user.logout') }}"><span
                                                    class="menu-item-text">@lang('Logout')</span></a></li>
                                    @else
                                        <li><a href="{{ route('seller.user.login') }}"><span
                                                    class="menu-item-text">@lang('Login')</span></a></li>
                                        <li><a href="{{ route('seller.user.register') }}"><span
                                                    class="menu-item-text">@lang('Create Account')</span></a></li>
                                    @endif
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-nav py-4 d-none d-lg-block">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <nav class="navbar navbar-expand-lg nav-dark nav-primary-hover">
                            <a class="navbar-brand" href="{{ route('seller.front.index') }}"><img class="nav-logo"
                                    src="{{ getPhoto($gs->header_logo, getUser('user_id')) }}"
                                    alt="Image not found !"></a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <i class="navbar-toggler-icon flaticon-menu-2 flat-small text-primary"></i>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav ms-xxl-5">
                                    <li class="nav-item"><a class="nav-link"
                                            href="{{ route('seller.front.index') }}">@lang('Home')</a></li>
                                    <li class="nav-item dropdown mega-dropdown">
                                        <a class="nav-link dropdown-toggle"
                                            href="{{ route('seller.front.product.catalog') }}">{{ __('Product') }}</a>
                                        <ul class="dropdown-menu mega-dropdown-menu">
                                            <li class="mega-container">
                                                <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                                                    @foreach ($globalcategory as $category)
                                                        <div class="col">
                                                            <a
                                                                href="{{ route('seller.front.product.catalog') . '?category=' . $category->slug }}"><span
                                                                    class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">{{ $category->name }}</span></a>
                                                            <ul>
                                                                @if ($category->subcategories_count != 0)
                                                                    @foreach ($category->subcategories as $subcategory)
                                                                        <li><a class="dropdown-item"
                                                                                href="{{ route('seller.front.product.catalog') . '?subcategory=' . $subcategory->slug }}">{{ $subcategory->name }}</a>
                                                                        </li>
                                                                    @endforeach
                                                                @endif
                                                            </ul>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#">@lang('Pages')</a>
                                        <ul class="dropdown-menu">
                                            @php
                                                $pages = DB::table('user_pages')
                                                    ->whereUserId(getUser('user_id'))
                                                    ->get();
                                            @endphp
                                            @foreach ($pages as $page)
                                                <li><a class="dropdown-item"
                                                        href="{{ route('seller.front.page', $page->slug) }}">{{ $page->title }}</a>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </li>

                                    <li class="nav-item"><a class="nav-link"
                                            href="{{ route('seller.front.blog') }}">@lang('Blog')</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="{{ route('seller.front.contact') }}">@lang('Contact')</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="col-xl-5 col-lg-3">
                        <div class="margin-right-1 d-flex align-items-center justify-content-end h-100">
                            <div class="product-search-one flex-grow-1 mr-20 global-search touch-screen-view">
                                <form class="form-inline search-pill-shape"
                                    action="{{ route('seller.front.product.catalog') }}" method="get">
                                    <input type="text" class="form-control search-field" name="search"
                                        value="" placeholder="@lang('Search Products')">
                                    <div class="select-appearance-none">
                                        <select class="form-control" name="category">
                                            <option value="">@lang('All Categories')</option>
                                            @foreach ($globalcategory as $gcateogry)
                                                <option value="{{ $gcateogry->slug }}">{{ $gcateogry->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <button type="submit" class="search-submit"><i
                                            class="flaticon-search flat-mini text-white"></i></button>
                                </form>
                            </div>
                            <div class="search-view d-xxl-none">
                                <a href="#"
                                    class="search-pop top-quantity d-flex align-items-center text-decoration-none">
                                    <i class="flaticon-search flat-mini text-dark mx-auto"></i>
                                </a>
                            </div>
                            <div class="wishlist-view">
                                <a href="{{ route('seller.user.wishlist.index') }}"
                                    class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                    <i class="flaticon-like flat-mini text-dark mx-auto"></i>
                                    @php
                                        if (Auth::check()) {
                                            $wishlistCount = count(Auth::user()->wishlists);
                                        } else {
                                            $wishlistCount = 0;
                                        }
                                        if (Session::has('compare' . sellerId())) {
                                            $oldCompare = Session::get('compare' . sellerId());
                                            $compare = new App\Models\Compare($oldCompare);
                                            $products = $compare->items;
                                            $compareCount = count($products);
                                        } else {
                                            $compareCount = 0;
                                        }
                                    @endphp
                                    <span
                                        class="header-cart-count wishlist_count1 wishlist_count">{{ $wishlistCount }}</span>
                                </a>
                            </div>
                            <div class="refresh-view">
                                <a href="{{ route('seller.front.compare.index') }}"
                                    class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                    <i class="flaticon-shuffle flat-mini text-dark mx-auto"></i>
                                    <span
                                        class="header-cart-count compare_count1 compare_count">{{ $compareCount }}</span>
                                </a>
                            </div>
                            <div class="header-cart-1">
                                <a href="cart.html" class="cart has-cart-data">
                                    @php
                                        if (Session::has('cart' . getUser('user_id'))) {
                                            $cartCount = count(Session::get('cart' . getUser('user_id')));
                                        } else {
                                            $cartCount = 0;
                                        }
                                    @endphp

                                    <div class="cart-icon"><i class="flaticon-shopping-cart flat-mini"></i> <span
                                            class="header-cart-count" id="cart_count1">{{ $cartCount }}</span>
                                    </div>
                                    <div class="cart-wrap">
                                        <div class="cart-text">Cart</div>
                                        <span class="header-cart-count">({{ $cartCount }})
                                            {{ $cartCount > 1 ? __('Items') : __('Item') }} </span>

                                    </div>
                                </a>
                                <div class="cart-popup" data-href="{{ route('seller.front.header.cart.load') }}">
                                    @include('sellerFront.inc.header_cart')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-sticky bg-white py-10">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xxl-2 col-xl-2 col-lg-3 col-6 order-lg-1">
                        <div class="d-flex align-items-center h-100 md-py-10">
                            <div class="nav-leftpush-overlay">
                                <nav class="navbar navbar-expand-lg nav-general nav-primary-hover">
                                    <button type="button" class="push-nav-toggle d-lg-none border-0">
                                        <i class="flaticon-menu-2 flat-small text-primary"></i>
                                    </button>
                                    <div class="navbar-slide-push transation-this">
                                        <div
                                            class="login-signup bg-secondary d-flex justify-content-between py-10 px-20 align-items-center mb-3">
                                            <a href="{{ route('seller.user.login') }}"
                                                class="d-flex align-items-center text-white">
                                                <i class="flaticon-user flat-small me-1"></i>
                                                <span>@lang('Login')</span>
                                            </a>
                                            /
                                            <a href="{{ route('seller.user.register') }}"
                                                class="d-flex align-items-center text-white">
                                                <i class="flaticon-user flat-small me-1"></i>
                                                <span>@lang('Signup')</span>
                                            </a>
                                            <span class="slide-nav-close"><i
                                                    class="flaticon-cancel flat-mini text-white"></i></span>
                                        </div>
                                        <div class="menu-and-category">
                                            <div class="push-navbar">
                                                <ul class="navbar-nav">
                                                    <li class="nav-item"><a class="nav-link"
                                                            href="{{ route('seller.front.index') }}">@lang('Home')</a>
                                                    </li>
                                                    <li class="nav-item dropdown mega-dropdown">
                                                        <a class="nav-link dropdown-toggle"
                                                            href="#">@lang('Product')</a>
                                                        <ul class="dropdown-menu mega-dropdown-menu">
                                                            <li class="mega-container">
                                                                <div
                                                                    class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                                                                    @foreach ($globalcategory as $category)
                                                                        <div class="col">
                                                                            <a
                                                                                href="{{ route('seller.front.product.catalog') . '?category=' . $category->slug }}"><span
                                                                                    class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">{{ $category->name }}</span></a>
                                                                            <ul>
                                                                                @if ($category->subcategories_count != 0)
                                                                                    @foreach ($category->subcategories as $subcategory)
                                                                                        <li><a class="dropdown-item"
                                                                                                href="{{ route('seller.front.product.catalog') . '?subcategory=' . $subcategory->slug }}">{{ $subcategory->name }}</a>
                                                                                        </li>
                                                                                    @endforeach
                                                                                @endif
                                                                            </ul>
                                                                        </div>
                                                                    @endforeach
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="nav-item dropdown">
                                                        <a class="nav-link dropdown-toggle"
                                                            href="#">@lang('Pages')</a>
                                                        <ul class="dropdown-menu">
                                                            @php
                                                                $pages = DB::table('user_pages')
                                                                    ->whereUserId(getUser('user_id'))
                                                                    ->get();
                                                            @endphp
                                                            @foreach ($pages as $page)
                                                                <li><a class="dropdown-item"
                                                                        href="{{ route('seller.front.page', $page->slug) }}">{{ $page->title }}</a>
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </li>

                                                    <li class="nav-item"><a class="nav-link"
                                                            href="{{ route('seller.front.blog') }}">@lang('Blog')</a>
                                                    </li>
                                                    <li class="nav-item"><a class="nav-link"
                                                            href="{{ route('seller.front.contact') }}">@lang('Contact')</a>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                            <a class="navbar-brand" href="{{ route('seller.front.index') }}"><img class="nav-logo"
                                    src="{{ getPhoto($gs->header_logo, getUser('user_id')) }}"
                                    alt="Image not found !"></a>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-4 col-lg-3 col-6 order-lg-3">
                        <div class="margin-right-1 d-flex align-items-center justify-content-end h-100 md-py-10">
                            @if ($gs->currency_show == 1)
                                <div class="dropdown">
                                    <a href="#" class="dropdown-toggle __drp-icon text-general"
                                        data-bs-toggle="dropdown" role="button" aria-haspopup="true"
                                        aria-expanded="false"><span>{{ sellerCurrencyCode() }}</span></a>
                                    <ul class="dropdown-menu bg-white">
                                        @foreach ($globalcurrency as $gcurrency)
                                            <li class=""><a
                                                    href="{{ route('seller.front.currency.set', $gcurrency->id) }}"
                                                    class="dropdown-item">{{ $gcurrency->code }}</a></li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <div class="sign-in position-relative font-general my-account-dropdown">
                                <a href="#0"
                                    class="has-dropdown d-flex align-items-center text-dark text-decoration-none"
                                    title="My Account">
                                    <i class="flaticon-user-3 flat-mini me-1 mx-auto"></i>
                                </a>
                                <ul class="my-account-popup">
                                    @if (Auth::check())
                                        <li><a href="{{ route('seller.user.dashboard') }}"><span
                                                    class="menu-item-text">@lang('Dashboard')</span></a></li>
                                        <li><a href="{{ route('seller.user.profile') }}"><span
                                                    class="menu-item-text">@lang('Profile')</span></a></li>
                                        <li><a href="{{ route('seller.user.logout') }}"><span
                                                    class="menu-item-text">@lang('Logout')</span></a></li>
                                    @else
                                        <li><a href="{{ route('seller.user.login') }}"><span
                                                    class="menu-item-text">@lang('Login')</span></a></li>
                                        <li><a href="{{ route('seller.user.register') }}"><span
                                                    class="menu-item-text">@lang('Create Account')</span></a></li>
                                    @endif

                                </ul>
                            </div>
                            <div class="wishlist-view">
                                <a href="{{ route('seller.user.wishlist.index') }}"
                                    class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                    <i class="flaticon-like flat-mini text-dark mx-auto"></i>
                                    <span class="header-cart-count wishlist_count">{{ $wishlistCount }}</span>
                                </a>
                            </div>
                            <div class="refresh-view">
                                <a href="{{ route('seller.front.compare.index') }}"
                                    class="position-relative top-quantity d-flex align-items-center text-dark text-decoration-none">
                                    <i class="flaticon-shuffle flat-mini text-dark mx-auto"></i>
                                    <span class="header-cart-count compare_count">{{ $compareCount }}</span>
                                </a>
                            </div>



                            <div class="header-cart-1">
                                <a href="cart.html" class="cart has-cart-data">
                                    @php
                                        if (Session::has('cart' . getUser('user_id'))) {
                                            $cartCount = count(Session::get('cart' . getUser('user_id')));
                                        } else {
                                            $cartCount = 0;
                                        }
                                    @endphp
                                    <div class="cart-icon"><i class="flaticon-shopping-cart flat-mini"></i> <span
                                            class="header-cart-count" id="cart_count">{{ $cartCount }}</span>
                                    </div>
                                    <div class="cart-wrap">
                                        <div class="cart-text">Cart</div>

                                        <span class="header-cart-count">({{ $cartCount }})
                                            {{ $cartCount > 1 ? __('Items') : __('Item') }} </span>

                                    </div>
                                </a>
                                <div class="cart-popup" data-href="{{ route('seller.front.header.cart.load') }}">
                                    @include('sellerFront.inc.header_cart')
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="col-xxl-7 col-xl-6 col-lg-6 col-12 order-lg-2">
                        <div class="product-search-one">
                            <form class="form-inline search-pill-shape"
                                action="{{ route('seller.front.product.catalog') }}" method="get">
                                <input type="text" class="form-control search-field" name="search"
                                    value="" placeholder="@lang('Search Products')">
                                <div class="select-appearance-none">
                                    <select class="form-control" name="category">
                                        <option value="">@lang('All Categories')</option>
                                        @foreach ($globalcategory as $gcateogry)
                                            <option value="{{ $gcateogry->slug }}">{{ $gcateogry->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <button type="submit" class="search-submit"><i
                                        class="flaticon-search flat-mini text-white"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--==================== Header Section End ====================-->
