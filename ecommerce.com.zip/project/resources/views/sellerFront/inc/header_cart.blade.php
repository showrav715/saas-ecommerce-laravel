@php
    if (Session::has('cart' . getUser('user_id'))) {
        $cartCount = count(Session::get('cart' . getUser('user_id')));
    } else {
        $cartCount = 0;
    }
@endphp

@if ($cartCount != 0)
    <ul class="cart_list product_list_widget ">
        @php
            $cartTotal = 0;
        @endphp
        @if (Session::has('cart' . getUser('user_id')))
            @foreach (Session::get('cart' . getUser('user_id')) as $cartKey => $item)
                @php
                    $cartTotal += $item['cart_item_price'];
                @endphp
                <li class="mini-cart-item">
                    <a href="javascript:;" class="remove cart__item__remove"
                        data-href="{{ route('seller.front.cart.remove', $cartKey) }}" referrerpolicy="1"
                        title="Remove this item"><i class="fas fa-times"></i></a>
                    <a href="#" class="product-image bg-light"><img src="{{ $item['photo'] }}"
                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="Cart product"></a>
                    <a href="#" class="product-name">{{ $item['name'] }}</a>

                    @if (isset($item['color']))
                        <div class="variation">
                            <span>Color:</span>
                            <span>{{ $item['color']['color_name'] }}</span>
                        </div>
                    @endif
                    @if ($item['attributes'])
                        @foreach ($item['attributes'] as $key => $attr)
                            <div class="variation">
                                <span>{{ $key }}:</span>
                                <span>{{ $attr['name'] }} + {{ sellerShowAmount($attr['price']) }}</span>
                            </div>
                        @endforeach
                    @endif
                    <div class="cart-item-quantity">{{ $item['quantity'] }} ×
                        <span
                            class="woocommerce-Price-amount amount"><bdi>{{ sellerShowAmount($item['cart_single_price']) }}</bdi>
                        </span>
                    </div>
                </li>
            @endforeach
        @endif
    </ul>

    <div class="total-cart">
        <div class="title">@lang('Total'): </div>
        <div class="price"><span class="woocommerce-Price-amount amount"><span
                    class="woocommerce-Price-currencySymbol"> {{ sellerShowAmount($cartTotal) }}</span>
        </div>
    </div>
    <div class="buttons">
        <a href="{{ route('seller.front.cart.index') }}"
            class="btn btn-primary rounded-0 view-cart">@lang('View cart')</a>
        <a href="{{ route('seller.front.checkout.index') }}"
            class="btn btn-secondary rounded-0 checkout">@lang('Check out')</a>
    </div>
@else
    <p>@lang('Cart is empty')</p>
@endif
