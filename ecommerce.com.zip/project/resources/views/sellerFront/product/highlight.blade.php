@foreach ($products as $product)
    <div class="col">
        <div class="product type-product">
            <div class="product-wrapper">
                <div class="product-image">
                    <a href="{{route('seller.front.product.details',$product->slug)}}" class="woocommerce-LoopProduct-link"><img
                            src="{{ getPhoto($product->photo, getUser('user_id')) }}" alt="Product Image"></a>
                    @if ($product->previous_price)
                        <div class="on-sale">{{ discountPrice($product) }}</div>
                    @endif
                    <div class="hover-area">
                        <div class="cart-button">
                            <a href="javascript:;" class="button add_to_cart_button add__to__cart" data-href="{{route('seller.front.cart.store')}}" data-bs-toggle="tooltip" itemid="{{$product->id}}"
                                data-bs-placement="right" title="" data-bs-original-title="Add to Cart"
                                aria-label="Add to Cart">@lang('Add to Cart')</a>
                        </div>
                        <div class="wishlist-button">
                            @if (Auth::check())
                            <a class="add_to_wishlist add__wishlist" href="javascript:;" data-href="{{ route('seller.user.wishlist.add',$product->id) }}" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist">@lang('Wishlist')</a>
                            @else
                            <a class="add_to_wishlist" href="{{route('seller.user.login')}}"  data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist">@lang('Wishlist')</a>
                            @endif
                        </div>
                        <div class="compare-button">
                            <a class="compare button" href="javascript:;" data-href="{{ route('seller.front.compare.add',$product->id) }}" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Compare" aria-label="Compare">@lang('Compare')</a>
                        </div>
                    </div>
                </div>
                <div class="product-info">
                    <h3 class="product-title"><a href="{{route('seller.front.product.details',$product->slug)}}">{{ $product->name }}</a></h3>
                    <div class="product-price">
                        <div class="price">
                            <ins>{{ sellerShowAmount($product->current_price) }}</ins>
                            @if ($product->previous_price)
                                <del>{{ sellerShowAmount($product->previous_price) }}</del>
                            @endif

                        </div>
                    </div>
                    <div class="shipping-feed-back">
                        <div class="star-rating">
                            <div class="rating-wrap">
                                <a href="{{route('seller.front.product.details',$product->slug)}}">
                                    <i class="fas fa-star"></i><span> {{$product->rating()}} ({{$product->reviews_count}})</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endforeach
