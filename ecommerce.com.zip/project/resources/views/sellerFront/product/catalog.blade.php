@extends('layouts.sellerFront')

@section('content')
    <div class="full-row py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-2">@lang('Products')</h3>
                </div>
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="{{ route('seller.front.index') }}">@lang('Home')</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">@lang('Products')</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="full-row pt-0">
        <div class="container">
            <div class="row">
                <div class="col-xl-3">
                    <div id="sidebar" class="widget-title-bordered-full">
                        <div class="filter-btn d-xl-none ms-auto">
                            <i class="fas fa-times"></i>
                        </div>
                        <div id="woocommerce_product_categories-4"
                            class="widget woocommerce widget_product_categories widget-toggle">
                            <h2 class="widget-title">@lang('Product categories')</h2>
                            <ul class="product-categories">
                                @foreach ($globalcategory as $category)
                                    <li class="cat-item cat-parent">
                                        <a href="{{route('seller.front.product.catalog').'?category='.$category->slug}}">{{ $category->name }} <span
                                                class="count">({{ $category->products_count }})</span></a>
                                        @if ($category->subcategories_count != 0)
                                            <span class="has-child"></span>
                                            <ul class="children">
                                                @foreach ($category->subcategories as $subcategory)
                                                    <li class="cat-item"><a href="{{route('seller.front.product.catalog').'?subcategory='.$subcategory->slug}}">{{ $subcategory->name }}</a></li>
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        </div>

                        <div id="bigbazar-price-filter-list-1"
                            class="widget bigbazar_widget_price_filter_list widget_layered_nav widget-toggle">
                            <h2 class="widget-title">@lang('Brands')</h2>
                            <ul class="price-filter-list">
                                <li class="wc-layered-nav-term {{ !request()->input('brand') ? 'chosen' : '' }}">
                                    <span class="woocommerce-Price-amount product__brand" data="">
                                        <span class="woocommerce-Price-currencySymbol">@lang('All Brands')</span>
                                    </span>
                                </li>
                                @foreach ($product_brands as $brand)
                                    <li
                                        class="wc-layered-nav-term  {{ request()->input('brand') == $brand->id ? 'chosen' : '' }}">
                                        <span class="woocommerce-Price-amount product__brand" data="{{ $brand->id }}">
                                            <span class="woocommerce-Price-currencySymbol">{{ $brand->name }}</span>
                                        </span>
                                    </li>
                                @endforeach
                            </ul>
                        </div>


                        <div id="bigbazar-price-filter-list-1"
                            class="widget bigbazar_widget_price_filter_list widget_layered_nav widget-toggle">
                            <h2 class="widget-title">Colors</h2>
                            <ul class="price-filter-list">
                                <li class="wc-layered-nav-term {{ !request()->input('color') ? 'chosen' : '' }}">
                                    <span class="woocommerce-Price-amount product__color" data="">
                                        <span class="woocommerce-Price-currencySymbol">@lang('All Colors')</span>
                                    </span>
                                </li>
                                @foreach ($product_colors as $color)
                                    <li
                                        class="wc-layered-nav-term {{ request()->input('color') == $color->id ? 'chosen' : '' }}">
                                        <span class="woocommerce-Price-amount product__color" data="{{ $color->id }}">
                                            <span class="woocommerce-Price-currencySymbol">{{ $color->color_name }}</span>
                                        </span>
                                    </li>
                                @endforeach
                            </ul>
                        </div>


                        @foreach ($product_attrbutes as $attribute)
                            @if ($attribute->variations_count != 0)
                                <div id="bigbazar-price-filter-list-1"
                                    class="widget bigbazar_widget_price_filter_list widget_layered_nav widget-toggle">
                                    <h2 class="widget-title">{{ $attribute->name }}</h2>
                                    <ul class="price-filter-list">
                                        @foreach ($attribute->variations as $variation)
                                            <li class="wc-layered-nav-term product_attribute {{ request()->input('attribute') && in_array($attribute->id . '_' . $variation->id, explode(',', request()->input('attribute'))) ? 'chosen' : '' }}"
                                                data-attribute="{{ $attribute->id }}"
                                                data-variation="{{ $variation->id }}">
                                                <span class="woocommerce-Price-amount amount">
                                                    <span
                                                        class="woocommerce-Price-currencySymbol">{{ $variation->name }}</span>
                                                </span>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                        @endforeach
                        <button id="clear__attributes" class="btn btn-danger btn-small">@lang('Clear Attribute')</button>
                    </div>
                </div>
                <div class="col-xl-9">
                    <div
                        class="products-header d-flex flex-wrap justify-content-between align-items-center py-10 px-20 bg-light md-mt-30 gap-10px">
                        <div class="products-header-left d-flex align-items-center me-auto">
                            <h6 class="woocommerce-products-header__title page-title d-block">@lang('Products')</h6>
                        </div>
                        <div class="filter-btn d-xl-none ms-auto">
                            <i class="fas fa-filter"></i>
                        </div>
                        <div class="gap-10px d-flex flex-wrap">
                            <div class="products-header-right">
                                <select name="pagination" class="orderby" id="pagination__product" aria-label="Shop order">
                                    <option value="9" {{ request()->input('pagination') == '9' ? 'selected' : '' }}> @lang('Show:9')
                                    </option>
                                    <option value="12" {{ request()->input('pagination') == '12' ? 'selected' : '' }}>
                                        @lang('Show:12') </option>
                                    <option value="16" {{ request()->input('pagination') ==
                                    '16' ? 'selected' : '' }}>
                                        @lang('Show:16')</option>
                                    <option value="20" {{ request()->input('pagination') == '20' ? 'selected' : '' }}>
                                        @lang('Show:20')</option>
                                </select>
                            </div>
                            <div class="products-header-right">
                                <select name="orderby" class="orderby" id="orderby" aria-label="Shop order">
                                    <option value="latest" {{ request()->input('sort') == 'latest' ? 'selected' : '' }}>
                                        @lang('Sort by latest')</option>
                                    <option value="oldest" {{ request()->input('sort') == 'oldest' ? 'selected' : '' }}>
                                        @lang('Sort by Oldest')</option>
                                    <option value="name_a_z" {{ request()->input('sort') == 'name_a_z' ? 'selected' : '' }}>
                                        @lang('Sort by A TO Z')</option>
                                    <option value="name_z_a" {{ request()->input('sort') == 'name_z_a' ? 'selected' : '' }}>
                                        @lang('Sort by Z TO A')</option>
                                    <option value="low_to_high"
                                        {{ request()->input('sort') == 'low_to_high' ? 'selected' : '' }}>@lang('Sort by price: low to high')
                                    </option>
                                    <option value="high_to_low"
                                        {{ request()->input('sort') == 'high_to_low' ? 'selected' : '' }}>@lang('Sort by price: high to low')
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="showing-products pt-30 pb-50 border-2 border-bottom border-light">
                        <div
                            class="row row-cols-xl-4 row-cols-md-3 row-cols-sm-2 row-cols-1 product-style-3 e-hover-image-zoom after-border-two gy-3 gx-0">
                            @forelse ($products as $product)
                                <div class="col">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="{{ route('seller.front.product.details', $product->slug) }}"
                                                    class="woocommerce-LoopProduct-link"><img
                                                        src="{{ getPhoto($product->photo, getUser('user_id')) }}"
                                                        alt="Product Image"></a>
                                            </div>
                                            <div class="product-info">
                                                <div class="product-cats"><a
                                                        href="#">{{ $product->category->name }}</a></div>
                                                <h3 class="product-title"><a
                                                        href="{{ route('seller.front.product.details', $product->slug) }}">{{ $product->name }}</a>
                                                </h3>
                                                <div class="product-price">
                                                    <div class="price">
                                                        <ins>{{ productBasePrice($product) }}</ins>
                                                        @if ($product->previous_price)
                                                            <del>{{ sellerShowAmount($product->previous_price) }}</del>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="shipping-feed-back">
                                                    <div class="star-rating">
                                                        <div class="rating-wrap">
                                                            <a href="{{route('seller.front.product.details',$product->slug)}}">
                                                                <i class="fas fa-star"></i><span> {{$product->rating()}} ({{$product->reviews_count}})</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="hover-area">
                                                    <div class="cart-button">
                                                        <a href="javascript:;"
                                                            data-href="{{ route('seller.front.cart.store') }}"
                                                            class="button  add__to__cart" itemid="{{ $product->id }}"
                                                            data-bs-toggle="tooltip" data-bs-placement="right"
                                                            title="add" data-bs-original-title="Add to Cart"
                                                            aria-label="Add to Cart">@lang('Add to Cart')</a>
                                                    </div>
                                                    <div class="wishlist-button">
                                                        @if (Auth::check())
                                                            <a class="add_to_wishlist add__wishlist" href="javascript:;"
                                                                data-href="{{ route('seller.user.wishlist.add', $product->id) }}"
                                                                data-bs-toggle="tooltip" data-bs-placement="right"
                                                                title="" data-bs-original-title="Add to Wishlist"
                                                                aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                                        @else
                                                            <a class="add_to_wishlist"
                                                                href="{{ route('seller.user.login') }}"
                                                                data-bs-toggle="tooltip" data-bs-placement="right"
                                                                title="" data-bs-original-title="Add to Wishlist"
                                                                aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                                        @endif
                                                    </div>
                                                    <div class="compare-button">
                                                        <a class="compare button" href="javascript:;"
                                                            data-href="{{ route('seller.front.compare.add', $product->id) }}"
                                                            data-bs-toggle="tooltip" data-bs-placement="right"
                                                            title="" data-bs-original-title="Compare"
                                                            aria-label="Compare">@lang('Compare')</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="col">
                                    <div class="product-info">
                                        <h3 class="product-title">@lang('No Product Found')</h3>
                                    </div>
                                </div>
                            @endforelse
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-3">
                        <div class="pagination-style-one">
                            <nav aria-label="Page navigation example">
                                @if ($products->lastPage() > 1)
                                    <ul class="pagination">
                                        <li class="page-item {{ $products->currentPage() == 1 ? 'disabled' : '' }}">
                                            <a class="page-link" href="{{ $products->url(1) }}" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                        @for ($i = 1; $i <= $products->lastPage(); $i++)
                                            <li class="page-item {{ $products->currentPage() == $i ? 'active' : '' }}">
                                                <a class="page-link"
                                                    href="{{ $products->url($i) }}">{{ $i }}</a>
                                            </li>
                                        @endfor
                                        <li
                                            class="page-item {{ $products->currentPage() == $products->lastPage() ? 'disabled' : '' }}">
                                            <a class="page-link"
                                                href="{{ $products->url($products->currentPage() + 1) }}"
                                                aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                    </ul>
                                @endif
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Area End Here -->

    <form hidden action="{{ route('seller.front.product.catalog') }}" id="search__products" method="GET">
        <input type="text" name="sort" id="sort"
            value="{{ request()->input('sort') ? request()->input('sort') : '' }}">
        <input type="text" name="pagination" id="pagination"
            value="{{ request()->input('pagination') ? request()->input('pagination') : '' }}">
        <input type="text" name="color" id="color"
            value="{{ request()->input('color') ? request()->input('color') : '' }}">
        <input type="text" name="brand" id="brand"
            value="{{ request()->input('brand') ? request()->input('brand') : '' }}">
        <input type="text" name="attribute" id="attribute"
            value="{{ request()->input('attribute') ? request()->input('attribute') : '' }}">
    </form>
@endsection



@section('scripts')
    <script>
        // php array abc to js array

        $(document).on('change', '#orderby', function() {
            $('#sort').val($(this).val());
            $('#search__products').submit();
        })
        $(document).on('change', '#pagination__product', function() {
            $('#pagination').val($(this).val());
            $('#search__products').submit();
        })
        $(document).on('click', '.product__brand', function() {
            let brand = $(this).attr('data');
            $('#brand').val(brand);
            $('#search__products').submit();
        })
        $(document).on('click', '.product__color', function() {
            let color = $(this).attr('data');
            $('#color').val(color);
            $('#search__products').submit();
        })

        let array = [];

        $(document).on('click', '.product_attribute', function() {

            let xarray = $('#attribute').val();
            if (xarray != '') {
                array = xarray.split(',');
            }
            console.log(array);
            // return true;
            // loop through array
            let attribute = $(this).attr('data-attribute');
            let variation = $(this).attr('data-variation');
            let value = attribute + '_' + variation;
            array.push(value);

            array = array.filter(function(item, pos) {
                return array.indexOf(item) == pos;
            })

            $('#attribute').val(array);
            $('#search__products').submit();
        })

        $(document).on('click', '#clear__attributes', function() {
            $('#attribute').remove();
            $('#search__products').submit();
        })
    </script>
@endsection
