@extends('layouts.sellerFront')


@section('content')
<div class="full-row bg-light py-5">
    <div class="container">
        <div class="row text-secondary">
            <div class="col-sm-6">
                <h3 class="mb-2 text-secondary">{{ucwords($product->name)}}</h3>
            </div>
            <div class="col-sm-6">
                <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                    <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                        <li class="breadcrumb-item"><a href="{{route('seller.front.index')}}"><i class="fas fa-home me-1"></i>@lang('Home')</a></li>
                        <li class="breadcrumb-item"><a href="javascript:;">@lang('Product')</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{$product->name}}</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
    <div class="full-row">
        <div class="container">
            <div class="row single-product-wrapper">
                <div class="col-12 col-md-6 col-lg-5">
                    <div class="product-images">
                        <div class="images-inner">
                            <div class="woocommerce-product-gallery ">
                                <figure class="woocommerce-product-gallery__wrapper">
                                    <img id="single-image-zoom" src="{{ getPhoto($product->photo, getUser('user_id')) }}"
                                        alt="Thumb Image"
                                        data-zoom-image="{{ getPhoto($product->photo, getUser('user_id')) }}" />

                                    <div id="gallery_09" class="product-slide-thumb">
                                        <div class="owl-carousel four-carousel dot-disable nav-arrow-middle owl-mx-5">
                                            <div class="item">
                                                <a class="active" href="#"
                                                    data-image="{{ getPhoto($product->photo, getUser('user_id')) }}"
                                                    data-zoom-image="{{ getPhoto($product->photo, getUser('user_id')) }}">
                                                    <img src="{{ getPhoto($product->photo, getUser('user_id')) }}"
                                                        alt="Thumb Image" />
                                                </a>
                                            </div>
                                            @foreach ($product->galleries as $gallery)
                                                <div class="item">
                                                    <a class="" href="#"
                                                        data-image="{{ getPhoto($gallery->photo, getUser('user_id')) }}"
                                                        data-zoom-image="{{ getPhoto($gallery->photo, getUser('user_id')) }}">
                                                        <img src="{{ getPhoto($gallery->photo, getUser('user_id')) }}"
                                                            alt="Thumb Image" />
                                                    </a>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-7">
                    <div class="summary entry-summary">
                        <div class="summary-inner">
                            <div class="entry-breadcrumbs">
                                <nav class="breadcrumb-divider-slash" aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a
                                                href="{{ route('seller.front.product.catalog') }}">@lang('Shop')</a>
                                        </li>
                                        <li class="breadcrumb-item"><a
                                                href="{{ route('seller.front.product.catalog') }}">{{ $product->category->name }}</a>
                                        </li>
                                        @if ($product->subcategory_id)
                                            <li class="breadcrumb-item"><a
                                                    href="{{ route('seller.front.product.catalog') }}">{{ $product->subcategory->name }}</a>
                                            </li>
                                        @endif
                                        <li class="breadcrumb-item active" aria-current="page">{{ $product->name }}</li>
                                    </ol>
                                </nav>
                            </div>
                            <h1 class="product_title entry-title">{{ $product->name }}</h1>
                            <div class="woocommerce-product-rating">
                                <div class="fancy-star-rating">
                                    <div class="rating-wrap"> <span class="fancy-rating good">{{ $product->rating() }}
                                            ★</span>
                                    </div>
                                    <div class="rating-counts-wrap">
                                        <a href="#reviews" class="bigbazar-rating-review-link" rel="nofollow"> <span
                                                class="rating-counts"> ({{ $product->reviews_count }}) </span> </a>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="base__amount" value="{{ $product->current_price }}">
                            <p class="price">
                                <span class="woocommerce-Price-amount amount">
                                    <bdi><span id="main__price">{{ productBasePrice($product) }}</span></bdi>
                                </span>
                                <span class="woocommerce-Price-amount amount mx-2">
                                    <del><small><span
                                                class="woocommerce-Price-currencySymbol"></span>{{ sellerShowAmount($product->previous_price) }}</small></del>
                                </span>
                            </p>
                            @if ($product->previous_price)
                                <div class="product-price-discount"><span
                                        class="on-sale"><span>{{ discountPrice($product) }}</span>
                                </div>
                            @endif
                            <div class="stock-availability in-stock">@lang('In Stock')</div>

                            <form class="variations_form cart kapee-swatches-wrap"
                                action="{{ route('seller.front.cart.store') }}" method="post"
                                enctype="multipart/form-data">
                                @csrf
                                <table class="variations">
                                    <tbody>
                                        @php
                                            $attributes_data = json_decode($product->product_attrs, true);
                                            $attributes = json_decode($attributes_data['variation_id'], true);
                                            $colors = explode(',', $attributes_data['colors']);
                                        @endphp
                                        @if ($attributes_data['colors'] != null)
                                            <tr>
                                                <td class="label"><label>@lang('Color')</label></td>
                                                <td class="value with-swatches">
                                                    <div class="bigbazar-swatches">
                                                        @foreach ($colors as $color_id)
                                                            @php
                                                                $color = \App\Models\Color::find($color_id);
                                                            @endphp
                                                            @if ($color)
                                                                <span
                                                                    class="product__color__attr swatch swatch-color swatch-circle {{ $loop->first ? 'swatch-selected' : '' }}"
                                                                    data-bs-toggle="tooltip" data-id="{{ $color->id }}"
                                                                    data-bs-placement="top" data-bs-original-title="Blue">
                                                                    <span class="bigbazar-tooltip"
                                                                        style="background-color:{{ $color->color_code }}"
                                                                        title="">{{ $color->color_name }}
                                                                    </span>
                                                                </span>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                </td>
                                            </tr>
                                        @endif
                                        @if ($attributes)
                                            @foreach ($attributes as $attribute_id => $option_ids)
                                                @php
                                                    $attribute = \App\Models\Attribute::findOrFail($attribute_id);
                                                @endphp
                                                @if ($attribute)
                                                    <tr>
                                                        <td class="label"><label>{{ $attribute->name }}</label></td>
                                                        <td class="value with-swatches">
                                                            <div class="bigbazar-swatches">
                                                                @foreach ($option_ids as $option_id)
                                                                    @php
                                                                        $option = \App\Models\Variation::findOrFail($option_id);
                                                                    @endphp
                                                                    @if ($option)
                                                                        <span
                                                                            class="attribute{{ $attribute->id }} swatch product__another__attr swatch-label  swatch-circle {{ $loop->first ? 'swatch-selected' : '' }}"
                                                                            attribute="{{ $attribute->id }}"
                                                                            data-id="{{ $option->id }}"
                                                                            data-price="{{ $option->price }}"
                                                                            title="{{ $option->name }}">
                                                                            <span>{{ $option->name }}</span>
                                                                        </span>
                                                                    @endif
                                                                @endforeach
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endif
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                <div class="single_variation_wrap">

                                    @if ($product->type == 0)
                                        <div class="quantity">
                                            <input type="number" name="quantity" id="main__qty" min="1"
                                                max="{{ $product->stock }}" step="1" value="1">
                                            <div class="quantity-nav">
                                                <div class="quantity-button quantity-down">-</div>
                                                <div class="quantity-button quantity-up">+</div>
                                            </div>
                                        </div>
                                    @endif

                                    <div
                                        class="woocommerce-variation-add-to-cart variations_button woocommerce-variation-add-to-cart-enabled">
                                        <button type="submit"
                                            class="single_add_to_cart_button button alt single_add_to_cart_ajax_button"
                                            type="button">@lang('Add to cart')</button>
                                        <div class="bigbazar-quick-buy">
                                            <button type="submit" name="buy_now" value="1"
                                                class="bigbazar_quick_buy_button bigbazar_quick_buy_variable bigbazar_quick_buy_58"value="Buy Now">@lang('Buy Now')</button>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" value="{{ $product->id }}" name="product_id">
                                <input type="hidden" id="store__color" value="" name="color">
                                <input type="hidden" id="store__size" value="" name="variation">
                            </form>

                            <div class="yith-wcwl-add-to-wishlist wishlist-fragment">
                                <div class="wishlist-button">
                                    @if (Auth::check())
                                        <a class="add_to_wishlist add__wishlist" href="javascript:;"
                                            data-href="{{ route('seller.user.wishlist.add', $product->id) }}"
                                            data-bs-toggle="tooltip" data-bs-placement="right" title=""
                                            data-bs-original-title="Add to Wishlist"
                                            aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                    @else
                                        <a class="add_to_wishlist" href="{{ route('seller.user.login') }}"
                                            data-bs-toggle="tooltip" data-bs-placement="right" title=""
                                            data-bs-original-title="Add to Wishlist"
                                            aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                    @endif
                                </div>
                                <div class="compare-button">
                                    <a class="compare button" href="javascript:;"
                                        data-href="{{ route('seller.front.compare.add', $product->id) }}"
                                        data-bs-toggle="tooltip" data-bs-placement="right" title=""
                                        data-bs-original-title="Compare" aria-label="Compare">@lang('Compare')</a>
                                </div>
                            </div>

                            <div class="product_meta"> <span class="sku_wrapper">@lang('SKU:') <span
                                        class="sku">{{ $product->sku ?? 'N/A' }}</span></span>
                                <span class="posted_in">@lang('Category:') <a
                                        href="{{ route('seller.front.product.catalog') . '?category=' . $product->category->slug }}">{{ $product->category->name }}</a></span>
                                <span class="tagged_as">@lang('Tags:')
                                    @foreach (explode(',', $product->tags) as $tag)
                                        @if ($loop->last)
                                            <a href="{{ route('seller.front.product.catalog') . '?tag=' . $tag }}"
                                                rel="tag">{{ $tag }}</a>
                                        @else
                                            <a
                                                href="{{ route('seller.front.product.catalog') . '?tag=' . $tag }}"rel="tag">{{ $tag }}</a>,
                                        @endif
                                    @endforeach
                                </span>
                            </div>

                            <div class="bigbazar-wc-message"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="full-row pt-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="border-bottom border-top border-gray border-2">
                        <div class="woocommerce-tabs wc-tabs-wrapper ps-0 py-30 mt-0">
                            <ul class="nav nav-pills wc-tabs justify-content-center" id="pills-tab-one" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="pills-description-one-tab" data-bs-toggle="pill"
                                        href="#pills-description-one" role="tab"
                                        aria-controls="pills-description-one" aria-selected="true">@lang('Description')</a>
                                </li>

                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="pills-reviews-one-tab" data-bs-toggle="pill"
                                        href="#pills-reviews-one" role="tab" aria-controls="pills-reviews-one"
                                        aria-selected="true">@lang('Reviews') ({{ count($reviews) }})</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="woocommerce-tabs wc-tabs-wrapper ps-0 mt-0">
                        <div class="tab-content" id="pills-tabContent-one">
                            <div class="tab-pane fade show active woocommerce-Tabs-panel woocommerce-Tabs-panel--description"
                                id="pills-description-one" role="tabpanel" aria-labelledby="pills-description-one-tab">
                                <div class="pt-30">
                                    <div class="row pb-40">
                                        {{ strip_tags($product->details) }}
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="pills-reviews-one"
                                role="tabpanel"aria-labelledby="pills-reviews-one-tab">
                                <div id="reviews" class="woocommerce-Reviews">
                                    <div id="comments">
                                        <h2 class="woocommerce-Reviews-title my-3">({{ count($reviews) }})
                                            {{ __('Customer Review') }}</h2>
                                        <ol class="commentlist">
                                            @foreach ($reviews as $review)
                                                <li>
                                                    <div class="comment_container">
                                                        <img src="{{ getPhoto($review->user->photo, sellerId()) }}"
                                                            class="avatar" alt="Image not found!">
                                                        <div class="comment-text">
                                                            <div class="star-rating">
                                                                @php
                                                                    $rating = $review->rating;
                                                                    for ($i = 1; $i <= $rating; $i++) {
                                                                        echo '<i class="fas fa-star"></i>';
                                                                    }
                                                                @endphp
                                                            </div>
                                                            <p class="meta">
                                                                <strong
                                                                    class="woocommerce-review__author">{{ $review->user->name }}
                                                                </strong>
                                                                <span class="woocommerce-review__dash">–</span>
                                                                <span
                                                                    class="woocommerce-review__published-date">{{ dateFormat($review->created_at) }}</span>
                                                            </p>
                                                            <div class="description">
                                                                <p>
                                                                    {{ $review->review }}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            @endforeach
                                        </ol>
                                    </div>
                                    <div id="review_form_wrapper">
                                        @if (Auth::check())
                                            <div id="review_form">
                                                <div id="respond" class="comment-respond">
                                                    <form action="{{ route('seller.front.product.review') }}"
                                                        method="post" id="commentform" class="comment-form">
                                                        @csrf
                                                        <label class="mb-1">@lang('Your rating')</label>
                                                        <div class="comment-form-rating mb-3">
                                                            <ul class="stars">
                                                                <li class="star" data-rating="1">
                                                                    <i class="fas fa-star"></i>
                                                                </li>
                                                                <li class="star" data-rating="2">
                                                                    <i class="fas fa-star"></i>
                                                                </li>
                                                                <li class="star" data-rating="3">
                                                                    <i class="fas fa-star"></i>
                                                                </li>
                                                                <li class="star" data-rating="4">
                                                                    <i class="fas fa-star"></i>
                                                                </li>
                                                                <li class="star" data-rating="5">
                                                                    <i class="fas fa-star"></i>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <input type="hidden" name="product_id"
                                                            value="{{ $product->id }}">
                                                        <input type="hidden" name="rating" id="rating"
                                                            value="">
                                                        <p class="comment-form-comment">
                                                            <textarea id="comment" name="review" class="form-control" placeholder="Your review *" cols="45"
                                                                rows="7" aria-required="true"></textarea>
                                                        </p>
                                                        <p class="form-submit">
                                                            <button
                                                                class="submit btn btn-primary">@lang('Submit')</button>
                                                        </p>
                                                    </form>
                                                </div>
                                            </div>
                                        @else
                                            <div class="alert alert-warning">
                                                <p class="mb-0">@lang('Please') <a
                                                        href="{{ route('seller.user.login') }}">@lang('login')</a>
                                                    @lang('to review this
                                                                                                                                                                product.')</p>
                                            </div>
                                        @endif

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="full-row pt-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-head border-bottom d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex section-head-side-title">
                            <h4 class="text-dark mb-0">@lang('Related Products')</h4>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="products product-style-1 owl-mx-15">
                                <div
                                    class="five-carousel owl-carousel dot-disable nav-arrow-middle-show e-title-hover-primary e-image-bg-light e-hover-image-zoom e-info-center">
                                    @foreach ($related_products as $rproduct)
                                        <div class="item">
                                            <div class="product type-product">
                                                <div class="product-wrapper">
                                                    <div class="product-image">
                                                        <a href="{{ route('seller.front.product.details', $rproduct->slug) }}"
                                                            class="woocommerce-LoopProduct-link"><img
                                                                src="{{ getPhoto($rproduct->photo, getUser('user_id')) }}"
                                                                alt="Product Image"></a>

                                                        @if ($rproduct->previous_price)
                                                            <div class="on-sale">{{ discountPrice($rproduct) }}</div>
                                                        @endif
                                                        <div class="hover-area">
                                                            <div class="cart-button">
                                                                <a href="javascript:;"
                                                                    class="button add_to_cart_button add__to__cart"
                                                                    data-href="{{ route('seller.front.cart.store') }}"
                                                                    data-bs-toggle="tooltip" itemid="{{ $rproduct->id }}"
                                                                    data-bs-placement="right" title=""
                                                                    data-bs-original-title="Add to Cart"
                                                                    aria-label="Add to Cart">@lang('Add to Cart')</a>
                                                            </div>
                                                            <div class="wishlist-button">
                                                                @if (Auth::check())
                                                                    <a class="add_to_wishlist add__wishlist"
                                                                        href="javascript:;"
                                                                        data-href="{{ route('seller.user.wishlist.add', $rproduct->id) }}"
                                                                        data-bs-toggle="tooltip" data-bs-placement="right"
                                                                        title=""
                                                                        data-bs-original-title="Add to Wishlist"
                                                                        aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                                                @else
                                                                    <a class="add_to_wishlist"
                                                                        href="{{ route('seller.user.login') }}"
                                                                        data-bs-toggle="tooltip" data-bs-placement="right"
                                                                        title=""
                                                                        data-bs-original-title="Add to Wishlist"
                                                                        aria-label="Add to Wishlist">@lang('Wishlist')</a>
                                                                @endif
                                                            </div>
                                                            <div class="compare-button">
                                                                <a class="compare button" href="javascript:;"
                                                                    data-href="{{ route('seller.front.compare.add', $rproduct->id) }}"
                                                                    data-bs-toggle="tooltip" data-bs-placement="right"
                                                                    title="" data-bs-original-title="Compare"
                                                                    aria-label="Compare">@lang('Compare')</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="product-info">
                                                        <h3 class="product-title"><a
                                                                href="{{ route('seller.front.product.details', $rproduct->slug) }}">{{ $rproduct->name }}</a>
                                                        </h3>
                                                        <div class="product-price">
                                                            <div class="price">
                                                                <ins>{{ sellerShowAmount($rproduct->base_price) }}</ins>
                                                                @if ($rproduct->previous_price)
                                                                    <del>{{ sellerShowAmount($rproduct->previous_price) }}</del>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="shipping-feed-back">
                                                            <div class="star-rating">
                                                                <div class="rating-wrap">
                                                                    <a
                                                                        href="{{ route('seller.front.product.details', $rproduct->slug) }}">
                                                                        <i class="fas fa-star"></i><span>
                                                                            {{ $rproduct->rating() }}
                                                                            ({{ $rproduct->reviews_count }})
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--==================== Related Products Section End ====================-->
@endsection
