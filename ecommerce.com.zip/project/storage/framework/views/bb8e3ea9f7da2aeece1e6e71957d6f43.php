

<h1>NOT FOUND</h1><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/errors/404.blade.php ENDPATH**/ ?>