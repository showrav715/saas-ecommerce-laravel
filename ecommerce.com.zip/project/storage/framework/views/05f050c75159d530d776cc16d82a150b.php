<div class="full-row px-sm-5">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h2 class="text-center font-500 mb-40"><?php echo app('translator')->get('Posts'); ?></h2>
            </div>
        </div>
        <div class="row row-cols-xl-3 row-cols-md-2 row-cols-1 g-4 gy-xl-0">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="thumb-blog-simple transation hover-img-zoom">
                    <div class="post-image overflow-hidden">
                        <img src="<?php echo e(getPhoto($blog->photo,getUser('user_id'))); ?>" alt="Image not found!">
                    </div>
                    <div class="post-content">
                        <div class="post-meta font-small text-uppercase list-color-primary">
                            <a href="blog-grid.html"><span><?php echo e($blog->category->name); ?></span></a>
                        </div>
                        <h5>
                            <a href="<?php echo e(route('seller.front.blog.show',$blog->slug)); ?>" class="transation text-dark hover-text-primary d-table my-10 font-500">
                                <?php echo e($blog->title); ?>

                            </a>
                        </h5>
                        <p>
                            <?php echo e(Str::limit(strip_tags($blog->description), 100)); ?>

                        </p>
                        <a href="<?php echo e(route('seller.front.blog.show',$blog->slug)); ?>" class="btn-link-down-line d-table"><?php echo app('translator')->get('Read More'); ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/blogs.blade.php ENDPATH**/ ?>