        <!--==================== Footer Section Start ====================-->
        <footer class="full-row bg-white border-footer p-0">
            <div class="container">
                <div class="row ">
                    <div class="col-sm">
                        <div class="footer-widget my-5">
                            <div class="footer-logo mb-4">
                                <a href="<?php echo e(route('seller.front.index')); ?>"><img src="<?php echo e(getPhoto($gs->footer_logo,getUser('user_id'))); ?>" alt="Image not found!" /></a>
                            </div>
                
                            <div class="widget-ecommerce-contact">
                                <div class="text-general mt-20">
                                    <?php echo wordwrap($gs->footer_text, 35, "<br>", true); ?>

                                </div>
                            </div>
                          
                        </div>
                      
                        <div class="footer-widget media-widget">
                            <?php if(@$socialLink->icon && $socialLink->url): ?>
                            <a href="<?php echo e($socialLink->url); ?>"><i class="<?php echo e($socialLink->icon); ?>"></i></a>
                            <?php endif; ?>
                            <?php if(@$socialLink->icon1 && $socialLink->url1): ?>
                            <a href="<?php echo e($socialLink->url1); ?>"><i class="<?php echo e($socialLink->icon1); ?>"></i></a>
                            <?php endif; ?>
                            <?php if(@$socialLink->icon2 && $socialLink->url2): ?>
                            <a href="<?php echo e($socialLink->url2); ?>"><i class="<?php echo e($socialLink->icon2); ?>"></i></a>
                            <?php endif; ?>
                            <?php if(@$socialLink->icon3 && $socialLink->url3): ?>
                            <a href="<?php echo e($socialLink->url3); ?>"><i class="<?php echo e($socialLink->icon3); ?>"></i></a>
                            <?php endif; ?>
                            <?php if(@$socialLink->icon4 && $socialLink->url4): ?>
                            <a href="<?php echo e($socialLink->url4); ?>"><i class="<?php echo e($socialLink->icon4); ?>"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm col-6">
                        <div class="footer-widget category-widget my-5">
                            <h6 class="widget-title mb-sm-4"><?php echo app('translator')->get('Important Link'); ?></h6>
                            <ul>
                                <li><a href="<?php echo e(route('seller.front.index')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                                <li><a href="<?php echo e(route('seller.front.contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                                <li><a href="<?php echo e(route('seller.front.blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li>
                                <?php
                                    $pages = DB::table('user_pages')->whereUserId(getUser('user_id'))->get();
                                ?>
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('seller.front.page', $page->slug)); ?>"><?php echo e($page->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm col-6">
                        <div class="footer-widget category-widget my-5">
                            <h6 class="widget-title mb-sm-4"><?php echo app('translator')->get('Latest Blog'); ?></h6>
                            <ul>
                                <?php $__currentLoopData = DB::table('user_blogs')->whereUserId(sellerId())->orderby('id','desc')->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li>
                                    <a href="<?php echo e(route('seller.front.blog.show',$blog->slug)); ?>" class="__recent-posts">
                                        <img src="<?php echo e(getPhoto($blog->photo,sellerId())); ?>" style="width:50px" alt="">
                                        <div class="__inf">
                                            <div class="tt"><?php echo e($blog->title); ?></div>
                                        </div>
                                    </a>
                                </li> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--==================== Footer Section End ====================-->

        <!--==================== Copyright Section Start ====================-->
        <div class="full-row copyright bg-white py-3">
            <div class="container">
                <div class="row">
                    
                    <?php if($gs->copyright_show == 1): ?>
                    <div class="col-md-6">
                        <span class="sm-mb-10 d-block"><?php echo e($gs->copyright_text); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!--==================== Copyright Section End ====================-->
        <!-- Scroll to top -->
        <a href="#" class="bg-primary text-white" id="scroll"><i class="fa fa-angle-up"></i></a>
        <!-- End Scroll To top -->
		<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/inc/footer.blade.php ENDPATH**/ ?>