
<?php if(count($banners)>0): ?>
<div class="full-row px-sm-5">
    <div class="container-fluid">
        <div class="row justify-content-center wow fadeInUp animated animated" data-wow-delay="200ms" data-wow-duration="1000ms" style="visibility: visible; animation-duration: 1000ms; animation-delay: 200ms;">
            <div class="col-xxl-5 col-xl-7 col-lg-9">
                <div class="text-center mb-40">
                    <h2 class="text-center font-500 mb-4"><?php echo app('translator')->get('Best Month Offer'); ?></h2>
                    <span class="sub-title"><?php echo app('translator')->get('Erat pellentesque curabitur euismod dui etiam pellentesque rhoncus fermentum tristique lobortis lectus magnis. Consequat porta turpis maecenas'); ?></span>
                </div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-xxl-6 col-md-12">
                <div class="banner-wrapper hover-img-zoom banner-one custom-class-122 bg-light">
                    <div class="banner-image overflow-hidden transation"><img src="<?php echo e(getPhoto($banners[0]->photo,getUser('user_id'))); ?>" alt="Banner Image"></div>
                    <div class="banner-content y-center position-absolute">
                        <div class="middle-content">
                            <span class="up-to-sale"><?php echo e($banners[0]->header); ?></span>
                            <h3><a href="<?php echo e($banners[0]->link); ?>" class="text-dark text-decoration-none"><?php echo e($banners[0]->title); ?></a></h3>
                            <a href="<?php echo e($banners[0]->link); ?>" class="category"><?php echo e($banners[0]->subtitle); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div class="banner-wrapper hover-img-zoom banner-one custom-class-123">
                    <div class="banner-image overflow-hidden transation"><img src="<?php echo e(getPhoto($banners[1]->photo,getUser('user_id'))); ?>" alt="Banner Image"></div>
                    <div class="banner-content position-absolute">
                        <div class="middle-content">
                            <a href="<?php echo e($banners[1]->link); ?>" class="category"><?php echo e($banners[1]->header); ?></a>
                            <span class="sale"><?php echo e($banners[1]->title); ?></span>
                            <span class="sale"><?php echo e($banners[1]->text); ?></span>
                            <a href="<?php echo e($banners[1]->link); ?>" class="btn btn-secondary"><?php echo app('translator')->get('Shop Now'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-3 col-md-6">
                <div class="banner-wrapper hover-img-zoom banner-one custom-class-124 bg-light">
                    <div class="banner-image overflow-hidden transation"><img src="<?php echo e(getPhoto($banners[2]->photo,getUser('user_id'))); ?>" alt="Banner Image"></div>
                    <div class="banner-content position-absolute">
                        <a href="<?php echo e($banners[2]->link); ?>" class="category"><?php echo e($banners[2]->header); ?></a>
                        <h3><a href="<?php echo e($banners[2]->link); ?>"><?php echo e($banners[2]->title); ?></a></h3>
                        <span class="up-to-sale"><?php echo e($banners[2]->text); ?></span>
                        <a href="<?php echo e($banners[2]->link); ?>" class="btn btn-secondary"><?php echo app('translator')->get('Shop Now'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/best_offer.blade.php ENDPATH**/ ?>