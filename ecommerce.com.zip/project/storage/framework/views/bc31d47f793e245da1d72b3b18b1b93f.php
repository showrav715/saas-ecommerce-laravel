<aside id="sidebar-wrapper">
    <ul class="sidebar-menu mb-5">
        <li class="menu-header"><?php echo app('translator')->get('Dashboard'); ?></li>
        <li class="nav-item <?php echo e(menu('admin.dashboard')); ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link"><i
                    class="fas fa-fire"></i><span><?php echo app('translator')->get('Dashboard'); ?></span></a>
        </li>

        <li class="menu-header"><?php echo app('translator')->get('Package Management'); ?></li>

        <li class="nav-item dropdown <?php echo e(menu(['admin.package.*'])); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fab fa-product-hunt"></i><span><?php echo app('translator')->get('Package Management'); ?></span></a>
            <ul class="dropdown-menu">
                <li class="<?php echo e(menu('admin.package.create')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.package.create')); ?>"><?php echo app('translator')->get('Create New'); ?></a></li>
                <li class="<?php echo e(menu('admin.package.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.package.index')); ?>"><?php echo app('translator')->get('Packages'); ?></a></li>
            </ul>
        </li>

        <li class="nav-item <?php echo e(menu('admin.order.index')); ?>">
            <a href="<?php echo e(route('admin.order.index')); ?>" class="nav-link"><i
                    class="fas fa-coins"></i><span><?php echo app('translator')->get('Manage Orders'); ?></span></a>
        </li>

        <li class="menu-header"><?php echo app('translator')->get('Customers'); ?></li>
        <li class="nav-item dropdown <?php echo e(menu(['admin.customer.*'])); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fab fa-product-hunt"></i><span><?php echo app('translator')->get('Customers'); ?></span></a>
            <ul class="dropdown-menu">
                <li class="<?php echo e(menu('admin.customer.create')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.customer.create')); ?>"><?php echo app('translator')->get('Create Customer'); ?></a></li>
                <li class="<?php echo e(menu('admin.customer.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.customer.index')); ?>"><?php echo app('translator')->get('All Customers'); ?></a></li>
            </ul>
        </li>


        <li class="nav-item dropdown <?php echo e(menu('admin.ticket.manage')); ?>">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-ticket-alt"></i> <span><?php echo app('translator')->get('Support Tickets'); ?>
                    <?php if($pending_seller_ticket > 0): ?>
                        <small class="badge badge-primary mr-4">!</small>
                    <?php endif; ?>
                </span></a>
            <ul class="dropdown-menu">
                <li class="<?php echo e(url()->current() == url('admin/manage/tickets/user') ? 'active' : ''); ?>"><a
                        class="nav-link <?php echo e($pending_seller_ticket > 0 ? 'beep beep-sidebar' : ''); ?>"
                        href="<?php echo e(route('admin.ticket.manage', 'user')); ?>"><?php echo app('translator')->get('User Tickets'); ?></a></li>
            </ul>
        </li>



        <li class="menu-header"><?php echo app('translator')->get('Staff and Role'); ?></li>
        <li class="nav-item <?php echo e(menu('admin.role*')); ?>">
            <a href="<?php echo e(route('admin.role.index')); ?>" class="nav-link"><i
                    class="fas fa-user-tag"></i><span><?php echo app('translator')->get('Manage Role'); ?></span></a>
        </li>


        <li class="nav-item <?php echo e(menu('admin.staff*')); ?>">
            <a href="<?php echo e(route('admin.staff.manage')); ?>" class="nav-link"><i
                    class="fas fa-user-shield"></i><span><?php echo app('translator')->get('Manage Staff'); ?></span></a>
        </li>

        <li class="nav-item dropdown <?php echo e(menu(['admin.domain*', 'admin.domain*'])); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fas fa-money-check-alt"></i> <span><?php echo app('translator')->get('Manage Domain'); ?></span></a>
            <ul class="dropdown-menu">
                <li class="<?php echo e(menu('admin.domain.setting')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.domain.setting')); ?>"><?php echo app('translator')->get('Domain Setting'); ?></a></li>
            </ul>
        </li>


        <li class="nav-item dropdown <?php echo e(menu(['admin.gateway*'])); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fas fa-money-check-alt"></i> <span><?php echo app('translator')->get('Payment Gateway'); ?></span></a>
            <ul class="dropdown-menu">
                <li class="<?php echo e(menu('admin.currency.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.currency.index')); ?>"><?php echo app('translator')->get('Currency'); ?></a></li>
                <li class="<?php echo e(menu('admin.gateway')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.gateway')); ?>"><?php echo app('translator')->get('Gateways'); ?></a>
                </li>
            </ul>
        </li>

        <li class="menu-header"><?php echo app('translator')->get('General'); ?></li>

        <li class="nav-item dropdown <?php echo e(menu(['admin.gs*', 'admin.cookie'])); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                    class="fas fa-cog"></i><span><?php echo app('translator')->get('General Settings'); ?></span></a>
            <ul class="dropdown-menu">

                <li class="<?php echo e(menu('admin.gs.site.settings')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.gs.site.settings')); ?>"><?php echo app('translator')->get('Site Settings'); ?></a></li>
                <li class="<?php echo e(menu('admin.gs.logo')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.gs.logo')); ?>"><?php echo app('translator')->get('Logo & Favicon'); ?></a></li>
                <li class="<?php echo e(menu('admin.mail.config')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.mail.config')); ?>"><?php echo app('translator')->get('Email Config'); ?></a></li>

                <li class="<?php echo e(menu('admin.cookie')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.cookie')); ?>"><?php echo app('translator')->get('Cookie Concent'); ?></a></li>
            </ul>
        </li>


        <li
            class="nav-item dropdown <?php echo e(menu(['admin.front*', 'admin.page*', 'admin.frontend*', 'admin.bcategory*', 'admin.blog*', 'admin.seo-setting*'])); ?>">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-th"></i>
                <span><?php echo app('translator')->get('Frontend Setting'); ?></span></a>
            <ul class="dropdown-menu">
                <li class="<?php echo e(menu('admin.gs.banner')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.gs.banner')); ?>"><?php echo app('translator')->get('Hero Section'); ?></a></li>
                <li class="<?php echo e(menu('admin.page.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.page.index')); ?>"><?php echo app('translator')->get('Pages Settings'); ?></a></li>
                <li class="<?php echo e(menu('admin.service.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.service.index')); ?>"><?php echo app('translator')->get('Services'); ?></a></li>
                <li class="<?php echo e(menu('admin.testimonial.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.testimonial.index')); ?>"><?php echo app('translator')->get('Testimonials'); ?></a></li>
                <li class="<?php echo e(menu('admin.bcategory.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.bcategory.index')); ?>"><?php echo app('translator')->get('Blog Category'); ?></a></li>
                <li class="<?php echo e(menu(['admin.blog.index', 'admin.blog.create', 'admin.blog.edit'])); ?>"><a
                        class="nav-link" href="<?php echo e(route('admin.blog.index')); ?>"><?php echo app('translator')->get('Manage Blog'); ?></a></li>
                <li class="<?php echo e(menu('admin.seo-setting.index')); ?>"><a class="nav-link"
                        href="<?php echo e(route('admin.seo-setting.index')); ?>"><?php echo app('translator')->get('Seo Settings'); ?></a></li>

            </ul>
        </li>


        <li class="nav-item <?php echo e(menu('admin.clear.cache')); ?>">
            <a href="<?php echo e(route('admin.clear.cache')); ?>" class="nav-link"><i class="fas fa-broom"></i>
                <span><?php echo app('translator')->get('Clear Cache'); ?></span></a>
        </li>


    </ul>
</aside>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>