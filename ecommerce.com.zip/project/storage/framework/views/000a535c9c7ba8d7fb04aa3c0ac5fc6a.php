
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('View Customer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header  d-flex justify-content-between">
            <h1><?php echo app('translator')->get('View Customer'); ?></h1>
            <a href="<?php echo e(route('admin.customer.index')); ?>" class="btn btn-primary"><i class="fas fa-backward"></i>
                <?php echo app('translator')->get('Back'); ?></a>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">

        <div class="col-12 col-md-12 col-lg-12">
            <div class="card profile-widget">
                <div class="profile-widget-header">
                    <img alt="image" src="<?php echo e(getPhoto($user->photo)); ?>" class="profile-widget-picture">
                    <div class="profile-widget-items">
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label">Package / Plan</div>
                            <?php
                                $package = $user->user_package;
                            ?>
                            <div class="profile-widget-item-value"><?php echo e($user->user_package->package_info->name); ?></div>
                        </div>
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label">Will Expired</div>
                            <div class="profile-widget-item-value"><?php echo e($user->domain->will_expire); ?></div>
                        </div>
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label">Status</div>
                            <div class="profile-widget-item-value">
                                <?php if($user->status == 1): ?>
                                    <span class="badge badge-success"><?php echo e(__('Active')); ?></span>
                                <?php elseif($user->status == 0): ?>
                                    <span class="badge badge-danger"><?php echo e(__('Pending')); ?></span>
                                <?php elseif($user->status == 2): ?>
                                    <span class="badge badge-warning"><?php echo e(__('Ban')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    if (request()->secure()) {
                        $customer_domain = 'https://' . $user->domain->domain;
                    } else {
                        $customer_domain = 'http://' . $user->domain->domain;
                    }
                ?>
                <div class="profile-widget-description">
                    <div class="profile-widget-name"><?php echo e($user->name); ?> <div
                            class="text-muted d-inline font-weight-normal">
                            <div class="slash"></div> <a href="<?php echo e($customer_domain); ?>"
                                target="_blank"><?php echo e($user->domain->domain); ?></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4><?php echo app('translator')->get('Customer Information'); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-3 col-sm-12 mt-2">
                            <div class="list-group" id="list-tab" role="tablist">
                                <a class="list-group-item list-group-item-action active show" id="profile-list"
                                    data-toggle="list" href="#profile" role="tab"
                                    aria-selected="false"><b><?php echo app('translator')->get('Basic
                                                                            Information'); ?></b></a>
                                <a class="list-group-item list-group-item-action " id="customer-list" data-toggle="list"
                                    href="#customer" role="tab" aria-selected="true"><b><?php echo app('translator')->get('Customers'); ?></b></a>
                                <a class="list-group-item list-group-item-action" id="package-list" data-toggle="list"
                                    href="#package" role="tab" aria-selected="false"><b><?php echo app('translator')->get('Package History'); ?></b></a>
                            </div>
                        </div>
                        <div class="col-lg-9 col-sm-12">
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade active show" id="profile" role="tabpanel"
                                    aria-labelledby="profile-list">
                                    <ul class="list-group">
                                        <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-4">
                                                    <strong><?php echo app('translator')->get('Customer Name'); ?></strong>
                                                </div>
                                                <div class="col-8">
                                                    <?php echo e($user->name); ?>

                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-4">
                                                    <strong><?php echo app('translator')->get('Customer Email'); ?></strong>
                                                </div>
                                                <div class="col-8">
                                                    <?php echo e($user->email); ?>

                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-4">
                                                    <strong><?php echo app('translator')->get('Customer Phone'); ?></strong>
                                                </div>
                                                <div class="col-8">
                                                    <?php echo e($user->phone); ?>

                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-4">
                                                    <strong><?php echo app('translator')->get('Customer Address'); ?></strong>
                                                </div>
                                                <div class="col-8">
                                                    <?php echo e($user->address); ?>

                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-4">
                                                    <strong><?php echo app('translator')->get('Customer City'); ?></strong>
                                                </div>
                                                <div class="col-8">
                                                    <?php echo e($user->city); ?>

                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="tab-pane fade" id="customer" role="tabpanel" aria-labelledby="customer-list">
                                    <div class="table-responsive">
                                        <table class="table table-hover" id="table">
                                            <thead>
                                                <tr>
                                                    <th><?php echo app('translator')->get('Name'); ?></th>
                                                    <th><?php echo app('translator')->get('Email'); ?></th>
                                                    <th><?php echo app('translator')->get('Phone'); ?></th>
                                                    <th><?php echo app('translator')->get('Created At'); ?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th data-label="Name"><?php echo e($customer->name); ?></th>
                                                        <td data-label="Email"><?php echo e($customer->email); ?></td>
                                                        <td data-label="Phone"><?php echo e($customer->phone); ?></td>
                                                        <td data-label="Created at"><?php echo e(dateFormat($customer->created_at)); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="package" role="tabpanel" aria-labelledby="package-list">
                                    <div class="table-responsive">
                                        <table class="table table-hover" id="table1">
                                            <thead>
                                                <tr>
                                                    <th><?php echo app('translator')->get('Order No'); ?></th>
                                                    <th><?php echo app('translator')->get('Package Name'); ?></th>
                                                    <th><?php echo app('translator')->get('Price'); ?></th>
                                                    <th><?php echo app('translator')->get('Created At'); ?></th>
                                                    <th><?php echo app('translator')->get('View'); ?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $package_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th data-label="Order No"><?php echo e($item->order_no); ?></th>
                                                        <td data-label="Package Name"><?php echo e($item->package_info->name); ?></td>
                                                        <td data-label="Price"><?php echo e(adminShowAmount($item->amount)); ?></td>
                                                        <td data-label="Created at"><?php echo e(dateFormat($item->created_at)); ?>

                                                        </td>
                                                        <td data-label="view">
                                                            <a href="<?php echo e(route('admin.order.details', $item->id)); ?>"
                                                                class="btn btn-primary btn-sm mb-1"
                                                                title="<?php echo app('translator')->get('Edit'); ?>"><i class="fas fa-eye"></i></a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/admin/customer/view.blade.php ENDPATH**/ ?>