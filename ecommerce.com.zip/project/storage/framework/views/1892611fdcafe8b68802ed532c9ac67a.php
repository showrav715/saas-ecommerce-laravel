
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Admin Dashboard'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo app('translator')->get('Dashboard'); ?></h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
       <div class="col-xl-4 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                   <i class="fas fa-users"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo app('translator')->get('Total User'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($total_customer); ?>

                   </div>
               </div>
           </div>
       </div>
       <div class="col-xl-4 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                   <i class="far fa-user"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo app('translator')->get('Total Staff'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($total_staff); ?>

                   </div>
               </div>
           </div>
       </div>
       <div class="col-xl-4 col-lg-4 col-sm-6 col-12">
           <div class="card card-statistic-1">
               <div class="card-icon bg-primary">
                <i class="fab fa-product-hunt"></i>
               </div>
               <div class="card-wrap">
                   <div class="card-header">
                       <h4><?php echo app('translator')->get('Total Package'); ?></h4>
                   </div>
                   <div class="card-body">
                      <?php echo e($total_package); ?>

                   </div>
               </div>
           </div>
       </div>
      
   </div>

    <div class="row">
        <div class="col-sm-6 col-12">
            <div class="card card-statistic-2">
                <div class="card-icon shadow-primary bg-success text-white">
                    <i class="fas fa-coins"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                       <h4><?php echo app('translator')->get('Total Orders'); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php echo e($total_order); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-12">
            <div class="card card-statistic-2">
            <div class="card-icon shadow-primary bg-primary text-white">
                <?php echo e(defaultCurr()->symbol); ?>

            </div>
            <div class="card-wrap">
                <div class="card-header">
                <h4><?php echo app('translator')->get('Total Earning'); ?></h4>
                </div>
                <div class="card-body">
                    <?php echo e(adminShowAmount($total_earning)); ?>

                </div>
            </div>
            </div>
        </div>
    </div>


   <div class="row">
       <div class="col-12 col-md-12 col-lg-12">
           <div class="card">
               <div class="card-header">
                   <h4><?php echo app('translator')->get('Recent Orders'); ?></h4>
               </div>
               <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Oder Id'); ?></th>
                                <th><?php echo app('translator')->get('Customer'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Purchase Date'); ?></th>
                                <th><?php echo app('translator')->get('Expiry Date'); ?></th>
                                <th><?php echo app('translator')->get('Price'); ?></th>
                                <th><?php echo app('translator')->get('Method'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Expiry'); ?></th>
                                <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Order Id'); ?>">
                                    <?php echo e($item->order_no); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Customer'); ?>">
                                    <?php echo e($item->user->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                    <?php echo e($item->package_info->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Purchase Date'); ?>">
                                    <?php echo e(dateFormat($item->created_at)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Expiry Date'); ?>">
                                    <?php echo e(dateFormat($item->will_expire)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Price'); ?>">
                                    <?php echo e(adminShowAmount($item->amount)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Method'); ?>">
                                    <?php echo e($item->method); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($item->status == 0): ?>
                                        <span class="badge badge-primary"> <?php echo app('translator')->get('Pending'); ?> </span>
                                    <?php elseif($item->status == 1): ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Approved'); ?> </span>
                                    <?php else: ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Expired'); ?> </span>
                                    <?php endif; ?>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Expiry'); ?>">
                                    <?php if(Carbon\Carbon::parse($item->will_expire)->isPast()): ?>
                                        <span class="badge badge-danger"> <?php echo app('translator')->get('Expired'); ?> </span>
                                    <?php else: ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Active'); ?> </span>
                                    <?php endif; ?>
                                </td>



                                <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                                    <div class="btn-group mb-2">
                                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php echo app('translator')->get('Action'); ?>
                                        </button>
                                        <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 29px, 0px); top: 0px; left: 0px; will-change: transform;">
                                           <a class="dropdown-item" href="<?php echo e(route('admin.order.edit',$item->id)); ?>"><?php echo app('translator')->get('Edit'); ?></a>
                                           <a class="dropdown-item" href="<?php echo e(route('admin.order.details',$item->id)); ?>"><?php echo app('translator')->get('View'); ?></a>
                                        </div>
                                     </div>
                                </td>
                            </tr>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
               </div>
           </div>
       </div>
       <div class="col-12 col-md-12 col-lg-12">
           <div class="card">
               <div class="card-header">
                   <h4><?php echo app('translator')->get('Recent Registered Users'); ?></h4>
               </div>
               <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Email'); ?></th>
                                <th><?php echo app('translator')->get('Domain'); ?></th>
                                <th><?php echo app('translator')->get('Package/Plan'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Title'); ?>">
                                    <?php echo e($seller->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('URL Slug'); ?>">
                                    <?php echo e($seller->email); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                    <a href="<?php echo e($seller->domain->domain ?? ''); ?>"
                                        target="_blank"><?php echo e($seller->domain->domain ?? ''); ?></a>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Package'); ?>">
                                    <?php echo e($seller->user_package->package_info->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php if($seller->status == 1): ?>
                                        <span class="badge badge-success"><?php echo e(__('Active')); ?></span>
                                    <?php elseif($seller->status == 0): ?>
                                        <span class="badge badge-danger"><?php echo e(__('Trash')); ?></span>
                                    <?php elseif($seller->status == 2): ?>
                                        <span class="badge badge-warning"><?php echo e(__('Suspended')); ?></span>
                                    <?php elseif($seller->status == 3): ?>
                                        <span class="badge badge-primary"><?php echo e(__('Pending')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Actions'); ?>">
                                    <div class="dropdown d-inline ">
                                        <button class="btn btn-primary btn-sm dropdown-toggle"
                                            type="button"id="dropdownMenuButton2" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            Actions
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item has-icon edit" href="javascript:;"
                                                data-route="<?php echo e(route('admin.customer.update', $seller->id)); ?>"
                                                data-item="<?php echo e($seller); ?>" data-toggle="tooltip"
                                                title="<?php echo app('translator')->get('Edit'); ?>"><i class="fas fa-user-edit"></i>
                                                <?php echo e(__('Edit')); ?></a>
                                            
                                            <a class="dropdown-item has-icon"
                                                href="<?php echo e(route('admin.customer.package.edit', $seller->id)); ?>"><i
                                                    class="far fa-edit"></i><?php echo e(__('Edit Package')); ?></a>
                                            <a class="dropdown-item has-icon"
                                                href="<?php echo e(route('admin.customer.view', $seller->id)); ?>"><i
                                                    class="far fa-eye"></i><?php echo e(__('View')); ?></a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
               </div>
           </div>
       </div>



   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>