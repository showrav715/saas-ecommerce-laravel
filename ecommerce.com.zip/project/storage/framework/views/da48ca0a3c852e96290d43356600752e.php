<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="BigBazar - Multipurpose Ecommerce HTML Template">
    <meta name="author" content="root">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($gs->title); ?></title>
    <link rel="shortcut icon" href="<?php echo e(getPhoto($gs->favicon, getUser('user_id'))); ?>">
    <?php echo $__env->make('sellerFront.inc.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(getPackage('google_analytics') == 1): ?>
        <?php if($gs->google_analytics): ?>
            <script>
                window.dataLayer = window.dataLayer || [];

                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());
                gtag('config', '<?php echo e($gs->google_analytics); ?>');
            </script>
        <?php endif; ?>
    <?php endif; ?>


    <?php if(getPackage('facebook_pixel') == 1): ?>
        <?php if($gs->facebook_pixel): ?>
            <script>
                ! function(f, b, e, v, n, t, s) {
                    if (f.fbq) return;
                    n = f.fbq = function() {
                        n.callMethod ?
                            n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                    };
                    if (!f._fbq) f._fbq = n;
                    n.push = n;
                    n.loaded = !0;
                    n.version = '2.0';
                    n.queue = [];
                    t = b.createElement(e);
                    t.async = !0;
                    t.src = v;
                    s = b.getElementsByTagName(e)[0];
                    s.parentNode.insertBefore(t, s)
                }(window, document, 'script',
                    'https://connect.facebook.net/en_US/fbevents.js');
                fbq('init', '<?php echo e($gs->facebook_pixel); ?>');
                fbq('track', 'PageView');
            </script>
            <noscript>
                <img height="1" width="1" style="display:none"
                    src="https://www.facebook.com/tr?id=<?php echo e($gs->facebook_pixel); ?>&ev=PageView&noscript=1" />
            </noscript>
        <?php endif; ?>
    <?php endif; ?>

</head>

<body>
    <div id="page_wrapper" class="bg-white">
        <div class="loader">
            <div class="spinner"></div>
        </div>
        <?php echo $__env->make('sellerFront.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('sellerFront.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('sellerFront.inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/layouts/sellerFront.blade.php ENDPATH**/ ?>