  <!--==================== Best Selling Products Section Start ====================-->
  <div class="full-row px-sm-5">
    <div class="container-fluid">
        <div class="row justify-content-center wow fadeInUp animated" data-wow-delay="200ms" data-wow-duration="1000ms">
            <div class="col-xxl-4 col-xl-6 col-lg-7">
                <div class="text-center mb-5">
                    <span class="text-secondary pb-2 d-table tagline"><?php echo app('translator')->get('Top Products'); ?></span>
                    <h2 class="text-center font-500 mb-4"><?php echo app('translator')->get('Best Selling Products'); ?></h2>
                    <span class="sub-title"><?php echo app('translator')->get('Cillum eu id enim aliquip aute ullamco anim. Culpa deserunt nostrud excepteur voluptate velit ipsum esse enim.'); ?></span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="products product-style-1 owl-mx-15">
                    <div class="five-carousel owl-carousel dot-disable nav-arrow-middle-show e-title-hover-primary e-image-bg-light e-hover-image-zoom e-info-center">
                    <?php $__currentLoopData = $best_sellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="product type-product">
                            <div class="product-wrapper">
                                <div class="product-image">
                                    <a href="<?php echo e(route('seller.front.product.details',$best->slug)); ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo e(getPhoto($best->photo,getUser('user_id'))); ?>" alt="Product Image"></a>
                                  
                                    <?php if($best->previous_price): ?>
                                    <div class="on-sale"><?php echo e(discountPrice($best)); ?></div>
                                    <?php endif; ?>
                                    <div class="hover-area">
                                        <div class="cart-button">
                                            <a href="javascript:;" class="button add_to_cart_button add__to__cart" data-href="<?php echo e(route('seller.front.cart.store')); ?>" data-bs-toggle="tooltip" itemid="<?php echo e($best->id); ?>"
                                                data-bs-placement="right" title="" data-bs-original-title="Add to Cart"
                                                aria-label="Add to Cart"><?php echo app('translator')->get('Add to Cart'); ?></a>
                                        </div>
                                        <div class="wishlist-button">
                                            <?php if(Auth::check()): ?>
                                            <a class="add_to_wishlist add__wishlist" href="javascript:;" data-href="<?php echo e(route('seller.user.wishlist.add',$best->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist"><?php echo app('translator')->get('Wishlist'); ?></a>
                                            <?php else: ?>
                                            <a class="add_to_wishlist" href="<?php echo e(route('seller.user.login')); ?>"  data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist"><?php echo app('translator')->get('Wishlist'); ?></a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="compare-button">
                                            <a class="compare button" href="javascript:;" data-href="<?php echo e(route('seller.front.compare.add',$best->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Compare" aria-label="Compare"><?php echo app('translator')->get('Compare'); ?></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-info">
                                    <h3 class="product-title"><a href="<?php echo e(route('seller.front.product.details',$best->slug)); ?>"><?php echo e($best->name); ?></a></h3>
                                    <div class="product-price">
                                        <div class="price">
                                            <ins><?php echo e(sellerShowAmount($best->base_price)); ?></ins>
                                            <?php if($best->previous_price): ?>
                                            <del><?php echo e(sellerShowAmount($best->previous_price)); ?></del>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="shipping-feed-back">
                                        <div class="star-rating">
                                            <div class="rating-wrap">
                                                <a href="<?php echo e(route('seller.front.product.details',$best->slug)); ?>">
                                                    <i class="fas fa-star"></i><span> <?php echo e($best->rating()); ?> (<?php echo e($best->reviews_count); ?>)</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==================== Best Selling Products Section End ====================--><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/best_selling.blade.php ENDPATH**/ ?>