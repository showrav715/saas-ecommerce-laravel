

<?php $__env->startSection('content'); ?>
     <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h2 class="hero-title"><?php echo e($page->title); ?></h2>
                <ul class="breadcrumb">
                    <li>
                        <a href="<?php echo e(route('landing.index')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                    </li>
                    <li>
                        <?php echo e($page->title); ?>

                    </li>
                </ul>
            </div>
        </div>
        <span class="banner-elem elem1">&nbsp;</span>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem7">&nbsp;</span>
    </section>
 
    <section class="about-section pt-5 ">
        <div class="container">
            <div class="row justify-content-start">
                <div class="col-lg-12">
                    <div class="about-text-item mb-5">
                        <h4 class="title">
                            <?php echo e($page->title); ?>

                        </h4>
                        <p>
                            <?php
                                echo $page->details;
                            ?>
                        </p>
                    </div>
                 
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/front/page.blade.php ENDPATH**/ ?>