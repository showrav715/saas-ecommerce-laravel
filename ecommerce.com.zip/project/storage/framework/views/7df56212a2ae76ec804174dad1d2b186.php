

<?php $__env->startSection('content'); ?>
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h2 class="hero-title">Package Order</h2>
                <ul class="breadcrumb">
                    <li>
                        <a href="<?php echo e(route('landing.index')); ?>">Home</a>
                    </li>
                    <li>
                        Package Order
                    </li>
                </ul>
            </div>
        </div>
        <span class="banner-elem elem1">&nbsp;</span>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem7">&nbsp;</span>
    </section>

    <section class="contact-section pt-5 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="pricing-items">
                        <div class="pricing-head">
                            <h4>
                                <?php echo e($package->name); ?>

                            </h4>
                            <?php if($package->days == 7): ?>
                                <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Week'); ?></strong></div>
                            <?php elseif($package->days == 30): ?>
                                <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Month'); ?></strong></div>
                            <?php elseif($package->days == 365): ?>
                                <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Year'); ?></strong></div>
                            <?php endif; ?>
                            <p class="p-2 m-2 mt-0"> <?php echo e($package->description); ?></p>
                        </div>
                        <div class="pricing-content">
                            <div class="content-body">

                                <ul class="pricing-list">
                                    <li>
                                        <span>Category Limit <?php echo e($package->category_limit); ?></span>
                                    </li>
                                    <li>
                                        <span>Product Limit <?php echo e($package->product_limit); ?></span>
                                    </li>
                                    <li>
                                        <span>Customer Limit <?php echo e($package->customer_limit); ?></span>
                                    </li>
                                    <li>
                                        <span>Brand Limit <?php echo e($package->brand_limit); ?></span>
                                    </li>

                                    <li>
                                        <span>Variant Limit <?php echo e($package->variant_limit); ?></span>
                                    </li>




                                    <?php if($package->custom_domain == 1): ?>
                                        <li>
                                            <span><i class="fas fa-check"></i></span>
                                            <span>Custom Domain</span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span><i class="fas fa-times red"></i></span>
                                            <span>Custom Domain</span>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($package->customer_panel_access == 1): ?>
                                        <li>
                                            <span><i class="fas fa-check"></i></span>
                                            <span>Customer Panel Access</span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span><i class="fas fa-times red"></i></span>
                                            <span>Customer Panel Access</span>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($package->support == 1): ?>
                                        <li>
                                            <span><i class="fas fa-check"></i></span>
                                            <span>Support Module</span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span><i class="fas fa-times red"></i></span>
                                            <span>Support Module</span>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($package->qr_code == 1): ?>
                                        <li>
                                            <span><i class="fas fa-check"></i></span>
                                            <span>QR Code</span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span><i class="fas fa-times red"></i></span>
                                            <span>QR Code</span>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($package->facebook_pixel == 1): ?>
                                        <li>
                                            <span><i class="fas fa-check"></i></span>
                                            <span>Facebook Pixel</span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span><i class="fas fa-times red"></i></span>
                                            <span>Facebook Pixel</span>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($package->google_analytics == 1): ?>
                                        <li>
                                            <span><i class="fas fa-check"></i></span>
                                            <span>Google Analytics</span>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                            <span><i class="fas fa-times red"></i></span>
                                            <span>Google Analytics</span>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                <h2>
                                    <?php echo e(landingShowAmount($package->price)); ?>

                                </h2>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-8 col-md-6 border p-5">
                    <form action="" id="payment-form" class="contact-form row g-4 landing_form" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="ref_id" id="ref_id">
                        <input type="hidden" name="package_id" value="<?php echo e($package->id); ?>">
                        <div class="col-sm-6 form-group">
                            <label class="form--label" for="name">Your Name</label>
                            <input type="text" class="form-control  bg--section" name="name"
                                value="<?php echo e(old('name')); ?>" id="name" placeholder="Your Name">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label class="form--label" for="email">Your Email Address</label>
                            <input type="text" class="form-control  bg--section" name="email"
                                value="<?php echo e(old('email')); ?>" id="email" placeholder="Your Email Address">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label class="form--label" for="password">Password</label>
                            <input type="password" class="form-control bg--section" name="password"
                                value="<?php echo e(old('password')); ?>" id="password" placeholder="Password">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label class="form--label" for="password_confirmation">Confirm Password</label>
                            <input type="password" name="password_confirmation" class="form-control bg--section"
                                value="<?php echo e(old('password_confirmation')); ?>" id="password_confirmation"
                                placeholder="Confirm Password">
                        </div>

                        <div class="input-group">
                            <input type="text" class="form-control text-right" name="domain"
                                value="<?php echo e(old('domain')); ?>" placeholder="shop name">
                            <div class="input-group-append">
                                <div class="input-group-text">.<?php echo e(env('MAIN_DOMAIN')); ?></div>
                            </div>
                        </div>
                        <code>Example: {shop_name}.<?php echo e(env('MAIN_DOMAIN')); ?> </code>

                        <?php if($package->price > 0): ?>
                            <div class="col-sm-6 form-group">
                                <label class="form--label" for="seller_payment_gateway_option">Payment Gateway</label>
                                <select name="method" required class="form-control bg--section"
                                    id="seller_payment_gateway_option">
                                    <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                    <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gateway->id); ?>" data-keyword="<?php echo e($gateway->keyword); ?>"
                                            data-form="<?php echo e($gateway->showForm()); ?>"
                                            data-href="<?php echo e($gateway->showLandingLink()); ?>"
                                            form-get="<?php echo e($gateway->landingformUrl()); ?>"><?php echo e($gateway->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div id="showPayment"></div>
                        <?php endif; ?>
                        <div class="col-xl-12 form-group">
                            <div class="form-check form--check">
                                <input class="form-check-input" type="checkbox" value="" id="invalidCheck"
                                    required="" checked="">
                                <label class="form-check-label" for="invalidCheck">
                                    I Accept the <a href="#0" class="text--base">Terms</a> before sending you
                                    message
                                </label>
                            </div>
                        </div>
                        <input type="hidden" name="sub" id="sub" value="0">

                        <div class="col-xl-12 form-group">
                            <button type="submit" id="submit_btn" class="cmn--btn">Submit</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://js.paystack.co/v1/inline.js"></script>
    <script>
        $(document).on('change', '#seller_payment_gateway_option', function() {
            var form = $('option:selected', this).attr('data-form');
            var href = $('option:selected', this).attr('data-href');

            var formType = $('option:selected', this).attr('data-form');
            var keyword = $('option:selected', this).attr('data-keyword');
            $('form').attr('id', keyword)
            $('.landing_form').attr('action', href);
            if (formType == 'yes') {
                var formUrl = $('option:selected', this).attr('form-get');
                $('#showPayment').load(formUrl);
            } else {
                $('#showPayment').html('');
            }
        })

        $(document).on('submit', '#paystack', function() {
            var val = $('#sub').val();
            var total = '<?php echo e(landingShowAmount($package->price, true)); ?>';
            total = Math.round(total);
            if (val == 0) {
                var handler = PaystackPop.setup({
                    key: '<?php echo e($paystackData['key']); ?>',
                    email: $('#email').val(),
                    amount: total * 100,
                    currency: '<?php echo e(landingCurrency()->code); ?>',
                    ref: '' + Math.floor((Math.random() * 1000000000) + 1),
                    callback: function(response) {
                        $('#ref_id').val(response.reference);
                        $('#sub').val('1');
                        $('#form').attr('id', '');
                        $('#submit_btn').click();
                    },
                    onClose: function() {
                        window.location.reload();
                    }
                });
                handler.openIframe();
                return false;
            } else {

                return true;
            }
            return false
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/front/pricing_order.blade.php ENDPATH**/ ?>