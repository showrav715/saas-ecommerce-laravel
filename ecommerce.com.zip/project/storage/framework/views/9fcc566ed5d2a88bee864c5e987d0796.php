

<?php $__env->startSection('content'); ?>
     <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h2 class="hero-title">Pricing Plan</h2>
                <ul class="breadcrumb">
                    <li>
                        <a href="<?php echo e(route('landing.index')); ?>">Home</a>
                    </li>
                    <li>
                        Pricing Plan
                    </li>
                </ul>
            </div>
        </div>
        <span class="banner-elem elem1">&nbsp;</span>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem7">&nbsp;</span>
    </section>
 
    <section class="pricing-plan pt-5 pb-100">
        <div class="container">
            <div class="row g-4 justify-content-center">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="pricing-items">
                        <div class="pricing-head">
                            <h4>
                                <?php echo e($package->name); ?>

                            </h4>
                            <?php if($package->days == 7): ?>
                                <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Week'); ?></strong></div>
                            <?php elseif($package->days == 30): ?>
                                <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Month'); ?></strong></div>
                            <?php elseif($package->days == 365): ?>
                                <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Year'); ?></strong></div>
                            <?php endif; ?>
                            <p class="px-2 m-2 mt-0"> <?php echo e($package->description); ?></p>
                        </div>
                       
                        <div class="pricing-content">
                           <div class="content-body">
                            
                                <ul class="pricing-list">
                                    <li>
                                        <span>Category Limit <?php echo e($package->category_limit); ?></span>
                                    </li>
                                    <li>
                                        <span>Product Limit <?php echo e($package->product_limit); ?></span>
                                    </li>
                                    <li>
                                        <span>Customer Limit <?php echo e($package->customer_limit); ?></span>
                                    </li>
                                    <li>
                                        <span>Brand Limit <?php echo e($package->brand_limit); ?></span>
                                    </li>
                                    
                                    <li>
                                        <span>Variant Limit <?php echo e($package->variant_limit); ?></span>
                                    </li>
                                   
                                    <?php if($package->custom_domain == 1): ?>
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Custom Domain</span>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Custom Domain</span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($package->customer_panel_access == 1): ?>
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Customer Panel Access</span>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Customer Panel Access</span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($package->support == 1): ?>
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Support Module</span>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Support Module</span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($package->qr_code == 1): ?>
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>QR Code</span>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>QR Code</span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($package->facebook_pixel == 1): ?>
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Facebook Pixel</span>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Facebook Pixel</span>
                                    </li>
                                    <?php endif; ?>

                                    <?php if($package->google_analytics == 1): ?>
                                    <li>
                                        <span><i class="fas fa-check"></i></span>
                                        <span>Google Analytics</span>
                                    </li>
                                    <?php else: ?>
                                    <li>
                                        <span><i class="fas fa-times red"></i></span>
                                        <span>Google Analytics</span>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                                <h2>
                                    <?php echo e(landingShowAmount($package->price)); ?>

                                </h2>
                                <div class="pricing-btn">
                                    <a href="<?php echo e(route('landing.package.order',$package->id)); ?>" class="cmn--btn">
                                        Purchase now
                                    </a>
                                </div>
                           </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/front/pricing.blade.php ENDPATH**/ ?>