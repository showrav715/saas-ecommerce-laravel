<div class="container-fluid px-sm-5">
    <div class="position-relative">
        <span class="nextBtn"></span>
        <span class="prevBtn"></span>
        <section class="home-slider owl-theme owl-carousel">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="banner-slide-item"
                    style="background: url('<?php echo e(getPhoto($data->photo, getUser('user_id'))); ?>') no-repeat center center / cover ;">
                    <div class="container">
                        <div class="banner-wrapper-item text-<?php echo e($data->type); ?>">
                            <div class="banner-content text-dark">
                                <h2 class="title text-dark slide-h5"><?php echo e($data->title); ?></h2>
                                <p class="slide-h5"><?php echo e($data->text); ?></p>

                                <a href="<?php echo e($data->url); ?>" class="cmn--btn "><?php echo e($data->btn_text); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/slider.blade.php ENDPATH**/ ?>