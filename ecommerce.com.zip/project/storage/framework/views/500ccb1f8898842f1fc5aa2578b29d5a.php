

<?php $__env->startSection('content'); ?>


    <div class="full-row bg-light py-5">
        <div class="container">
            <div class="row text-secondary">
                <div class="col-sm-6">
                    <h3 class="mb-2 text-secondary"><?php echo app('translator')->get('Compare'); ?></h3>
                </div>
                <div class="col-sm-6">
                    <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                        <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('seller.front.index')); ?>"><i
                                        class="fas fa-home me-1"></i><?php echo app('translator')->get('Home'); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo app('translator')->get('Compare'); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <!-- breadcrumb -->
    <!-- Compare Area Start -->
    <section class="compare-page pb-5">
        <div class="container">
            <?php if(Session::has('compare' . sellerId())): ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="content">
                            <div class="com-heading">
                                <h2 class="title py-4">
                                    <?php echo e(__('Product Compare')); ?>

                                </h2>
                            </div>
                            <div class="compare-page-content-wrap">
                                <div class="compare-table table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <tbody>
                                            <?php if(count($products) > 0): ?>
                                            <tr>
                                                <td class="first-column top"><?php echo e(__('Product Name')); ?></td>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="product-image-title c<?php echo e($product['item']['id']); ?>">
                                                        <div class="position-relative">
                                                        <img class="img-fluid"
                                                            src="<?php echo e(getPhoto($product['item']['photo'], sellerId())); ?>"
                                                            alt="Compare product['item']">
                                                            
                                                        <div class="pro-remove __pro-remove c<?php echo e($product['item']['id']); ?>">
                                                            <a href="<?php echo e(route('seller.front.compare.remove', $product['item']['id'])); ?>"><i class="far fa-trash-alt compare-remove"></i></a>
                                                        </div>
                                                        </div>
                                                        <a class="d-block mt-3"
                                                            href="<?php echo e(route('seller.front.product.details', $product['item']['slug'])); ?>">
                                                            <h4 class="title1">
                                                                <?php echo e($product['item']['name']); ?>

                                                            </h4>
                                                        </a>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column"><?php echo e(__('Price')); ?></td>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="pro-price c<?php echo e($product['item']['id']); ?>">
                                                        <?php echo e(productBasePrice($product['item'])); ?>

                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column"><?php echo e(__('Rating')); ?></td>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="pro-ratting c<?php echo e($product['item']['id']); ?>">
                                                        <div class="ratings">
                                                            <div class="empty-stars"></div>
                                                            <div class="full-stars" style="width:50%"></div>
                                                        </div>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column"><?php echo e(__('Description')); ?></td>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="pro-desc c<?php echo e($product['item']['id']); ?>">
                                                        <p><?php echo e(strip_tags($product['item']['details'])); ?></p>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column"><?php echo e(__('')); ?></td>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <div class="p-2">
                                                        <a href="javascript:;"
                                                            data-href="<?php echo e(route('seller.front.cart.store')); ?>"
                                                            class="cmn-btn add__to__cart"
                                                            itemid="<?php echo e($product['item']['id']); ?>" class="add-cart"
                                                            data-href=""><?php echo e(__('Add to Cart')); ?></a></div>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td class="first-column p-5 text-center"><?php echo e(__('No Product To Compare.')); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="row mb-2">
                    <div class="col-lg-12">
                        <div class="content">
                            <div class="com-heading ">
                                <h2 class="title p-5 text-center text-center">
                                    <?php echo e(__('No Product To Compare.')); ?>

                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sellerFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/compare.blade.php ENDPATH**/ ?>