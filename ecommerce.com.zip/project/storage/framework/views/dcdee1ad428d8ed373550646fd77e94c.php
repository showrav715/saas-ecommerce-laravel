<div class="full-row py-30 px-sm-5">
    <div class="container-fluid">
        <div class="row row-cols-xxl-6 row-cols-md-3 row-cols-sm-2 row-cols-2 g-3 coustom-categories-banner-1 e-wrapper-absolute e-hover-image-zoom">
            <?php $__currentLoopData = $feature_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="product type-product">
                    <div class="product-wrapper">
                        <div class="product-image">
                            <a href="<?php echo e(route('seller.front.product.catalog').'?category='.$category->slug); ?>"><img src="<?php echo e(getPhoto($category->photo,getUser('user_id'))); ?>" alt="Product image"></a>
                        </div>
                        <a href="<?php echo e(route('seller.front.product.catalog').'?category='.$category->slug); ?>" class="product-info">
                            <h6 class="product-title"><?php echo e($category->name); ?></h6>
                            <span class="strok text-primary">(<?php echo e($category->products_count); ?>)</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/category.blade.php ENDPATH**/ ?>