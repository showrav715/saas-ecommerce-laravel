<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title><?php echo e($gs->title); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/animate.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/all.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/lightbox.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/odometer.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/owl.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing')); ?>/css/main.css" />
    <link rel="shortcut icon" href="<?php echo e(getPhoto($gs->favicon)); ?>" type="image/x-icon" />
</head>

<body>
    <!-- Overlayer -->
    <div class="overlayer"></div>
    <div class="loader">
        <div class="loader-item">
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
            <span class="loader-block"></span>
        </div>
    </div>
    <!-- Overlayer -->

    <!-- Header -->
    <div class="navbar-bottom">
        <div class="container">
            <div class="navbar-wrapper">
                <div class="logo">
                    <a href="<?php echo e(route('landing.index')); ?>">
                        <img src="<?php echo e(getPhoto($gs->header_logo)); ?>" alt="logo" />
                    </a>
                </div>
                <div class="nav-toggle d-lg-none">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="nav-menu-area">
                    <div class="menu-close text--danger d-lg-none">
                        <i class="fas fa-times"></i>
                    </div>
                    <ul class="nav-menu">
                        <li>
                            <a href="<?php echo e(route('landing.index')); ?>">Home</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('landing.pricing')); ?>">Pricing</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('landing.blogs')); ?>">Blogs</a>
                        </li>
                        <li>
                            <a href="#0">Pages</a>
                            <ul class="sub-nav">
                                <?php $__currentLoopData = DB::table('pages')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('landing.page', $page->slug)); ?>"><?php echo e($page->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo e(route('landing.contact')); ?>">Contact</a>
                        </li>

                        <li>
                            <div class="btn__grp ms-lg-3">
                                <form id="currency_submit" action="<?php echo e(route('landing.currency.store')); ?>"
                                    method="GET">
                                    <select name="currency_id" class="form-control" id="currency_id">
                                        <?php
                                            if (Session::has('landing_currency')) {
                                                $currency_id = Session::get('landing_currency');
                                            } else {
                                                $currency_id = App\Models\Currency::where('default', 1)->first()->id;
                                            }
                                        ?>
                                        <?php $__currentLoopData = DB::table('currencies')->whereStatus(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($currency->id); ?>"
                                                <?php echo e($currency_id == $currency->id ? 'selected' : ''); ?>>
                                                <?php echo e($currency->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </form>
                            </div>
                        </li>
                        <li>
                            <div class="btn__grp  ms-lg-3">
                                <a href="<?php echo e(route('landing.login')); ?>" class="cmn--btn">Login Now</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Header -->

    <?php echo $__env->yieldContent('content'); ?>
    <!-- Footer -->
    <footer class="footer-section position-relative overflow-hidden">
        <div class="footer-top">
            <div class="container">
                <div class="footer-wrapper">
                    <div class="footer-widget">
                        <div class="f-logo">
                            <img src="<?php echo e(getPhoto($gs->header_logo)); ?>" alt="f-logo">
                        </div>
                        <p class="text-white"><?php echo e($gs->footer_text); ?></p>
                        <div class="footer-info">
                            <div class="info-items">
                                <span>
                                    <i class="fas fa-phone"></i>
                                </span>
                                <a href="#0">
                                    <?php echo e($gs->phone); ?>

                                </a>
                            </div>
                            <div class="info-items">
                                <span>
                                    <i class="fas fa-envelope"></i>
                                </span>
                                <a href="#0">
                                    <?php echo e($gs->email); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="footer-widget">
                        <h5 class="footer-title">Quick Links</h5>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('landing.index')); ?>">Home</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('landing.pricing')); ?>">Pricing</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('landing.blogs')); ?>">Blog</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('landing.contact')); ?>">Company</a>
                            </li>

                        </ul>
                    </div>

                    <div class="footer-widget">
                        <h5 class="footer-title">Recent Post</h5>
                        <div class="recent-post">
                            <?php $__currentLoopData = DB::table('blogs')->orderby('id', 'desc')->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('landing.blog.show', $blog->slug)); ?>" class="recent-items">
                                    <div class="thumb">
                                        <img src="<?php echo e(getPhoto($blog->photo)); ?>" width="100" height="80"
                                            alt="thumb-img">
                                    </div>
                                    <div class="content">
                                        <span class="title">
                                            <?php echo e(Str::limit($blog->title, 20)); ?>

                                        </span>
                                        <span><?php echo e(dateFormat($blog->created_at)); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
            $cookie = $gs->cookie;
        ?>
        <?php if(isset($visited)): ?>
            <?php if($cookie->status == 1): ?>
                <div class="cookie-bar-wrap show">
                    <div class="container d-flex justify-content-center">
                        <div class="col-xl-10 col-lg-12">
                            <div class="row justify-content-center">
                                <div class="cookie-bar">
                                    <div class="cookie-bar-text">
                                        <?php echo e($cookie->cookie_text); ?>

                                    </div>
                                    <div class="cookie-bar-action">
                                        <button class="btn btn-primary btn-accept">
                                            <?php echo e($cookie->button_text); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="footer-copyright">
            <p><?php echo e($gs->copyright_text); ?></p>
        </div>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem5">&nbsp;</span>
        <span class="banner-elem elem6">&nbsp;</span>
        <span class="banner-elem elem8">&nbsp;</span>
    </footer>
    <!-- Footer -->


    <script src="<?php echo e(asset('assets/landing')); ?>/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/viewport.jquery.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/odometer.min.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/lightbox.min.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/owl.min.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/tilt.js"></script>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/main.js"></script>
    <?php echo $__env->make('notify.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('script'); ?>
    <script>
        'use strict'
        $(document).ready(function() {
            $('#currency_id').on('change', function() {
                $('#currency_submit').submit();
            })
        })
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/layouts/front.blade.php ENDPATH**/ ?>