<?php if(in_array($gateway->keyword, ['stripe', 'authorize'])): ?>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label><?php echo app('translator')->get('Card Number'); ?></label>
                <input class="form-control" type="text" name="card" placeholder="Enter Card Number">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label><?php echo app('translator')->get('Month'); ?></label>
                <input class="form-control" type="text" name="month" placeholder="Month">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label><?php echo app('translator')->get('Year'); ?></label>
                <input class="form-control" type="text" name="year" placeholder="Year">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label><?php echo app('translator')->get('CVC'); ?></label>
                <input class="form-control" type="text" name="cvc" placeholder="Enter CVC">
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($gateway->keyword == 'tap'): ?>
   
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/front/payment_form.blade.php ENDPATH**/ ?>