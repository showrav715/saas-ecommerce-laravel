<div class="full-row pt-3 px-sm-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="top-collection-tab nav-tab-active-secondary">
                    <ul class="nav nav-pills list-color-general justify-content-center mb-5">
                        <li class="nav-item">
                            <a class="nav-link get__highlight__product active" href="javascript:;" data-href="<?php echo e(route('seller.front.highlight.product','new')); ?>" ><?php echo app('translator')->get('New Arrival'); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link get__highlight__product" href="javascript:;" data-href="<?php echo e(route('seller.front.highlight.product','trending')); ?>" ><?php echo app('translator')->get('Trending'); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link get__highlight__product" href="javascript:;" data-href="<?php echo e(route('seller.front.highlight.product','best')); ?>" ><?php echo app('translator')->get('Best Selling'); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link get__highlight__product" href="javascript:;" data-href="<?php echo e(route('seller.front.highlight.product','featured')); ?>" ><?php echo app('translator')->get('Featured'); ?></a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active">
                            <div class="products product-style-1">
                                <div class="row gy-3 row-cols-xl-5 row-cols-md-3 row-cols-sm-2 row-cols-1 e-title-hover-primary e-image-bg-light e-hover-image-zoom e-info-center" id="show__highlight__product">
                                    <?php $__currentLoopData = $new_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                        <div class="product type-product">
                                            <div class="product-wrapper">
                                                <div class="product-image">
                                                    <a href="<?php echo e(route('seller.front.product.details',$product->slug)); ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo e(getPhoto($product->photo,getUser('user_id'))); ?>" alt="Product Image"></a>
                                                    <?php if($product->previous_price): ?>
                                                    <div class="on-sale"><?php echo e(discountPrice($product)); ?></div>
                                                    <?php endif; ?>
                                                    <div class="hover-area">
                                                        <div class="cart-button">
                                                            <a href="javascript:;" class="button add_to_cart_button add__to__cart" data-href="<?php echo e(route('seller.front.cart.store')); ?>" data-bs-toggle="tooltip" itemid="<?php echo e($product->id); ?>"
                                                                data-bs-placement="right" title="" data-bs-original-title="Add to Cart"
                                                                aria-label="Add to Cart"><?php echo app('translator')->get('Add to Cart'); ?></a>
                                                        </div>
                                                        <div class="wishlist-button">
                                                            <?php if(Auth::check()): ?>
                                                            <a class="add_to_wishlist add__wishlist" href="javascript:;" data-href="<?php echo e(route('seller.user.wishlist.add',$product->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist"><?php echo app('translator')->get('Wishlist'); ?></a>
                                                            <?php else: ?>
                                                            <a class="add_to_wishlist" href="<?php echo e(route('seller.user.login')); ?>"  data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Add to Wishlist" aria-label="Add to Wishlist"><?php echo app('translator')->get('Wishlist'); ?></a>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="compare-button">
                                                            <a class="compare button" href="javascript:;" data-href="<?php echo e(route('seller.front.compare.add',$product->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="Compare" aria-label="Compare"><?php echo app('translator')->get('Compare'); ?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-info">
                                                    <h3 class="product-title"><a href="<?php echo e(route('seller.front.product.details',$product->slug)); ?>"><?php echo e($product->name); ?></a></h3>
                                                    <div class="product-price">
                                                        <div class="price">
                                                            <ins><?php echo e(sellerShowAmount($product->base_price)); ?></ins>
                                                            <?php if($product->previous_price): ?>
                                                            <del><?php echo e(sellerShowAmount($product->previous_price)); ?></del>
                                                            <?php endif; ?>
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="shipping-feed-back">
                                                        <div class="star-rating">
                                                            <div class="rating-wrap">
                                                                <a href="<?php echo e(route('seller.front.product.details',$product->slug)); ?>">
                                                                    <i class="fas fa-star"></i><span> <?php echo e($product->rating()); ?> (<?php echo e($product->reviews_count); ?>)</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/highlight.blade.php ENDPATH**/ ?>