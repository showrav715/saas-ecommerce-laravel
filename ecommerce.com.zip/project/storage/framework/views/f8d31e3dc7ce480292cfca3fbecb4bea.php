<?php
    if (Session::has('cart' . getUser('user_id'))) {
        $cartCount = count(Session::get('cart' . getUser('user_id')));
    } else {
        $cartCount = 0;
    }
?>

<?php if($cartCount != 0): ?>
    <ul class="cart_list product_list_widget ">
        <?php
            $cartTotal = 0;
        ?>
        <?php if(Session::has('cart' . getUser('user_id'))): ?>
            <?php $__currentLoopData = Session::get('cart' . getUser('user_id')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartKey => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $cartTotal += $item['cart_item_price'];
                ?>
                <li class="mini-cart-item">
                    <a href="javascript:;" class="remove cart__item__remove"
                        data-href="<?php echo e(route('seller.front.cart.remove', $cartKey)); ?>" referrerpolicy="1"
                        title="Remove this item"><i class="fas fa-times"></i></a>
                    <a href="#" class="product-image bg-light"><img src="<?php echo e($item['photo']); ?>"
                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="Cart product"></a>
                    <a href="#" class="product-name"><?php echo e($item['name']); ?></a>

                    <?php if(isset($item['color'])): ?>
                        <div class="variation">
                            <span>Color:</span>
                            <span><?php echo e($item['color']['color_name']); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if($item['attributes']): ?>
                        <?php $__currentLoopData = $item['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="variation">
                                <span><?php echo e($key); ?>:</span>
                                <span><?php echo e($attr['name']); ?> + <?php echo e(sellerShowAmount($attr['price'])); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="cart-item-quantity"><?php echo e($item['quantity']); ?> ×
                        <span
                            class="woocommerce-Price-amount amount"><bdi><?php echo e(sellerShowAmount($item['cart_single_price'])); ?></bdi>
                        </span>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>

    <div class="total-cart">
        <div class="title"><?php echo app('translator')->get('Total'); ?>: </div>
        <div class="price"><span class="woocommerce-Price-amount amount"><span
                    class="woocommerce-Price-currencySymbol"> <?php echo e(sellerShowAmount($cartTotal)); ?></span>
        </div>
    </div>
    <div class="buttons">
        <a href="<?php echo e(route('seller.front.cart.index')); ?>"
            class="btn btn-primary rounded-0 view-cart"><?php echo app('translator')->get('View cart'); ?></a>
        <a href="<?php echo e(route('seller.front.checkout.index')); ?>"
            class="btn btn-secondary rounded-0 checkout"><?php echo app('translator')->get('Check out'); ?></a>
    </div>
<?php else: ?>
    <p><?php echo app('translator')->get('Cart is empty'); ?></p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/inc/header_cart.blade.php ENDPATH**/ ?>