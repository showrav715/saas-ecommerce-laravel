

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Customers'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header d-flex justify-content-between">
            <h1><?php echo app('translator')->get('Customers'); ?></h1>
            <a href="<?php echo e(route('admin.customer.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i>
                <?php echo app('translator')->get('Create New'); ?> </a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="table-responsive p-3">
                    <table class="table table-striped" id="table">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Email'); ?></th>
                                <th><?php echo app('translator')->get('Domain'); ?></th>
                                <th><?php echo app('translator')->get('Package/Plan'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Title'); ?>">
                                    <?php echo e($seller->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('URL Slug'); ?>">
                                    <?php echo e($seller->email); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                    <?php
                                    if (request()->secure()) {
                                        $customer_domain = 'https://' . $seller->domain->domain;
                                    } else {
                                        $customer_domain = 'http://' . $seller->domain->domain;
                                    }
                                ?>
                                    <a href="<?php echo e($customer_domain ?? ''); ?>"
                                        target="_blank"><?php echo e($customer_domain ?? ''); ?></a>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Package'); ?>">
                                    <?php echo e($seller->user_package->package_info->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php if($seller->status == 1): ?>
                                        <span class="badge badge-success"><?php echo e(__('Active')); ?></span>
                                    <?php elseif($seller->status == 0): ?>
                                        <span class="badge badge-danger"><?php echo e(__('Trash')); ?></span>
                                    <?php elseif($seller->status == 2): ?>
                                        <span class="badge badge-warning"><?php echo e(__('Suspended')); ?></span>
                                    <?php elseif($seller->status == 3): ?>
                                        <span class="badge badge-primary"><?php echo e(__('Pending')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Actions'); ?>">
                                    <div class="dropdown d-inline ">
                                        <button class="btn btn-primary dropdown-toggle"
                                            type="button"id="dropdownMenuButton2" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            Actions
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item has-icon edit" href="javascript:;"
                                                data-route="<?php echo e(route('admin.customer.update', $seller->id)); ?>"
                                                data-item="<?php echo e($seller); ?>" data-toggle="tooltip"
                                                title="<?php echo app('translator')->get('Edit'); ?>"><i class="fas fa-user-edit"></i>
                                                <?php echo e(__('Edit')); ?></a>
                                            <a class="dropdown-item has-icon sendMail" href="javascript:;"
                                                data-route="<?php echo e(route('admin.customer.send.mail', $seller->id)); ?>"
                                                data-item="<?php echo e($seller); ?>" data-toggle="tooltip"
                                                title="<?php echo app('translator')->get('Send Mail'); ?>"><i class="fas fa-envelope"></i>
                                                <?php echo e(__('Send Mail')); ?></a>
                                            <a class="dropdown-item has-icon"
                                                href="<?php echo e(route('admin.customer.package.edit', $seller->id)); ?>"><i
                                                    class="far fa-edit"></i><?php echo e(__('Edit Package')); ?></a>
                                            <a class="dropdown-item has-icon"
                                                href="<?php echo e(route('admin.customer.view', $seller->id)); ?>"><i
                                                    class="far fa-eye"></i><?php echo e(__('View')); ?></a>
                                            <a class="dropdown-item has-icon remove"  data-id="<?php echo e($seller->id); ?>" data-toggle="tooltip"><i
                                                    class="fas fa-trash"></i><?php echo e(__('Delete')); ?></a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo app('translator')->get('Edit Customer'); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Name'); ?></label>
                            <input class="form-control" type="text" name="name">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Email'); ?></label>
                            <input class="form-control" type="text" name="email">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Password'); ?></label>
                            <input class="form-control" type="text" name="password">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Status'); ?></label>
                            <select name="status" class="form-control">
                                <option value="1"><?php echo app('translator')->get('Active'); ?></option>
                                <option value="2"><?php echo app('translator')->get('Ban'); ?></option>
                                <option value="0"><?php echo app('translator')->get('Request'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="sendMail" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo app('translator')->get('Send Mail'); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Customer Name'); ?></label>
                            <input class="form-control" readonly type="text" name="name">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Customer Email'); ?></label>
                            <input class="form-control" readonly type="text" name="email">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Subject'); ?></label>
                            <input class="form-control" type="text" name="subject">
                        </div>
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Subject'); ?></label>
                            <textarea name="body" class="form-control" id="" cols="20" rows="7"></textarea>
                        </div>
                       
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="removeMod" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.customer.destroy')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="hidden" name="id">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.edit').on('click', function() {
            var data = $(this).data('item')
            $('#edit').find('input[name=name]').val(data.name)
            $('#edit').find('input[name=email]').val(data.email)
            $('#edit').find('select[name=status]').val(data.status)
            $('#edit').find('form').attr('action', $(this).data('route'))
            $('#edit').modal('show')
        })

        $('.sendMail').on('click', function() {
            var data = $(this).data('item')
            $('#sendMail').find('input[name=name]').val(data.name)
            $('#sendMail').find('input[name=email]').val(data.email)
            $('#sendMail').find('form').attr('action', $(this).data('route'))
            $('#sendMail').modal('show')
        })

        $('.remove').on('click', function(e) {
            e.preventDefault()
            $('#removeMod').find('input[name=id]').val($(this).data('id'))
            $('#removeMod').modal('show')
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/admin/customer/index.blade.php ENDPATH**/ ?>