<div class="full-row limited-stock sm-bg-img-none bg-gray" style="background: url(<?php echo e(getPhoto(@$bottom_banner->photo,sellerId())); ?>) no-repeat top / cover;">

    <div class="container">
        <div class="row sm-justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5 col-xxl-5 offset-lg-1">
                <div class="text-center">
                    <span class="product-tag text-primary"><?php echo e(@$bottom_banner->title); ?></span>
                    <h2 class="font-500"> <?php echo e(@$bottom_banner->text); ?></h2>
                    <a href="<?php echo e(@$bottom_banner->btn_link); ?>" class="btn-link-down-line text-uppercase d-table mx-auto font-small font-500"><?php echo e(@$bottom_banner->btn_text); ?></a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/includes/bottom_banner.blade.php ENDPATH**/ ?>