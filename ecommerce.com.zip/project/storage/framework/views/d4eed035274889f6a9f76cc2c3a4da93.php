
<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Orders'); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Orders'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="table-responsive p-3">
                    <table class="table table-striped" id="table">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Oder Id'); ?></th>
                                <th><?php echo app('translator')->get('Customer'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Purchase Date'); ?></th>
                                <th><?php echo app('translator')->get('Expiry Date'); ?></th>
                                <th><?php echo app('translator')->get('Price'); ?></th>
                                <th><?php echo app('translator')->get('Method'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Expiry'); ?></th>
                                <th class="text-right"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Order Id'); ?>">
                                    <?php echo e($item->order_no); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Customer'); ?>">
                                    <?php echo e($item->user->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                    <?php echo e($item->package_info->name); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Purchase Date'); ?>">
                                    <?php echo e(dateFormat($item->created_at)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Expiry Date'); ?>">
                                    <?php echo e(dateFormat($item->will_expire)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Price'); ?>">
                                    <?php echo e(adminShowAmount($item->amount)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Method'); ?>">
                                    <?php echo e($item->method); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($item->status == 0): ?>
                                        <span class="badge badge-primary"> <?php echo app('translator')->get('Pending'); ?> </span>
                                    <?php elseif($item->status == 1): ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Approved'); ?> </span>
                                    <?php else: ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Expired'); ?> </span>
                                    <?php endif; ?>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Expiry'); ?>">
                                    <?php if(Carbon\Carbon::parse($item->will_expire)->isPast()): ?>
                                        <span class="badge badge-danger"> <?php echo app('translator')->get('Expired'); ?> </span>
                                    <?php else: ?>
                                        <span class="badge badge-success"> <?php echo app('translator')->get('Active'); ?> </span>
                                    <?php endif; ?>
                                </td>



                                <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-right">
                                    <div class="btn-group mb-2">
                                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php echo app('translator')->get('Action'); ?>
                                        </button>
                                        <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 29px, 0px); top: 0px; left: 0px; will-change: transform;">
                                           <a class="dropdown-item" href="<?php echo e(route('admin.order.edit',$item->id)); ?>"><?php echo app('translator')->get('Edit'); ?></a>
                                           <a class="dropdown-item" href="<?php echo e(route('admin.order.details',$item->id)); ?>"><?php echo app('translator')->get('View'); ?></a>
                                        </div>
                                     </div>
                                </td>
                            </tr>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/admin/order/index.blade.php ENDPATH**/ ?>