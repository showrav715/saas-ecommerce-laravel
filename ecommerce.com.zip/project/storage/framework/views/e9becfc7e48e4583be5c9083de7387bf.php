

<?php
    $cookie = $gs->cookie;

?>

<?php $__env->startSection('content'); ?>
    <!-- Banner -->
    <section class="banner-section">
        <div class="container">
            <div class="banner__wrapper">
                <div class="banner__wrapper-content">
                    <h6 class="subtitle text--base">Welcome To <?php echo e($gs->title); ?></h6>
                    <h1 class="title">
                        <?php echo e($gs->banner_title); ?>

                    </h1>
                    <p>
                        <?php echo e($gs->banner_text); ?>

                    </p>
                    <div class="btn__grp mt-4">
                        <a href="#0" class="cmn--btn">Contact US <i class="fas fa-arrow-right"></i></a>
                        <a href="<?php echo e($gs->banner_video); ?>" class="cmn--video" data-lightbox>
                            <i class="fas fa-solid fa-play"></i>
                            <span>Watch The Video</span>
                        </a>
                    </div>
                </div>
                <div class="banner__wrapper-thumb">
                    <img src="<?php echo e(getPhoto($gs->banner_photo)); ?>" alt="banner" />
                </div>
            </div>
        </div>
        <span class="banner-elem elem1">&nbsp;</span>
        <span class="banner-elem elem2">&nbsp;</span>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem4">&nbsp;</span>
        <span class="banner-elem elem5">&nbsp;</span>
        <span class="banner-elem elem6">&nbsp;</span>
        <span class="banner-elem elem7">&nbsp;</span>
        <span class="banner-elem elem8">&nbsp;</span>
        <span class="banner-elem elem9">&nbsp;</span>
    </section>
    <!-- Banner -->


    <!-- Service -->
    <section class="service-section pt-100 pb-50 position-relative overflow-hidden">
        <div class="container position-relative">
            <div class="section-title text-center">
                <h6 class="subtitle text--base">Services</h6>
                <h2 class="title">What We Serve to You</h2>
                <p>
                    Deserunt hic consequatur ex placeat! atque repellendus
                    inventore quisquam, perferendis, eum reiciendis quia nesciunt
                    fuga magni.
                </p>
            </div>
            <div class="row g-4 justify-content-center">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-sm-6">
                        <div class="service-item">
                            <div class="service-icon">
                                <img src="<?php echo e(getPhoto($service->photo)); ?>" alt="">
                            </div>
                            <div class="feature-content">
                                <h5 class="title">
                                    <a href="javascript:;"><?php echo e($service->title); ?></a>
                                </h5>
                                <p>
                                    <?php echo e($service->text); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
        <span class="banner-elem elem3">&nbsp;</span>
        <span class="banner-elem elem7">&nbsp;</span>
        <span class="banner-elem elem2">&nbsp;</span>
        <span class="banner-elem elem5">&nbsp;</span>
        <span class="banner-elem elem8">&nbsp;</span>
    </section>
    <!-- Service -->

    <!-- Testimonial -->
    <section class="testimonial-section bg--section pt-100 pb-100 overflow-hidden position-relative">
        <div class="container">
            <div class="section-title text-center">
                <h6 class="subtitle text--base">Testimonials</h6>
                <h2 class="title">What our students say</h2>
                <p>
                    Deserunt hic consequatur ex placeat! atque repellendus
                    inventore quisquam, perferendis, eum reiciendis quia nesciunt
                    fuga magni.
                </p>
            </div>
            <div class="testimonial-slider owl-carousel owl-theme">
                <?php $__currentLoopData = $testimonails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial-item">
                        <div class="icon">
                            <i class="fas fa-quote-left"></i>
                        </div>
                        <div class="all-wrapper">
                            <div class="testimonial-content">
                                <p>
                                    <?php echo e($testimonial->message); ?>

                                </p>
                            </div>
                            <div class="testimonial-header">
                                <div class="thumb">
                                    <img src="<?php echo e(getPhoto($testimonial->photo)); ?>" alt="testimonial">
                                </div>
                                <div class="cont">
                                    <h5 class="name"><?php echo e($testimonial->name); ?></h5>
                                    <span><?php echo e($testimonial->designation); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
        <span class="banner-elem elem2">&nbsp;</span>
    </section>
    <!-- Testimonial -->

    <!-- Pricing -->
    <section class="pricing-plan pt-100">
        <div class="container">
            <div class="section-title text-center">
                <h6 class="subtitle text--base">Pricing</h6>
                <h2 class="title">Choose your plan</h2>
                <p>
                    Deserunt hic consequatur ex placeat! atque repellendus
                    inventore quisquam, perferendis, eum reiciendis quia nesciunt
                    fuga magni.
                </p>
            </div>
            <div class="row g-4 justify-content-center">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="pricing-items">
                            <div class="pricing-head">
                                <h4>
                                    <?php echo e($package->name); ?>

                                </h4>
                                <?php if($package->days == 7): ?>
                                    <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Week'); ?></strong></div>
                                <?php elseif($package->days == 30): ?>
                                    <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Month'); ?></strong></div>
                                <?php elseif($package->days == 365): ?>
                                    <div class="pricing-detail text-white"><strong><?php echo app('translator')->get('Per Year'); ?></strong></div>
                                <?php endif; ?>
                                <p class="p-2 m-2 mt-0"> <?php echo e($package->description); ?></p>
                            </div>

                            <div class="pricing-content">
                                <div class="content-body">

                                    <ul class="pricing-list">
                                        <li>
                                            <span>Category Limit <?php echo e($package->category_limit); ?></span>
                                        </li>
                                        <li>
                                            <span>Product Limit <?php echo e($package->product_limit); ?></span>
                                        </li>
                                        <li>
                                            <span>Customer Limit <?php echo e($package->customer_limit); ?></span>
                                        </li>
                                        <li>
                                            <span>Brand Limit <?php echo e($package->brand_limit); ?></span>
                                        </li>

                                        <li>
                                            <span>Variant Limit <?php echo e($package->variant_limit); ?></span>
                                        </li>




                                        <?php if($package->custom_domain == 1): ?>
                                            <li>
                                                <span><i class="fas fa-check"></i></span>
                                                <span>Custom Domain</span>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <span><i class="fas fa-times red"></i></span>
                                                <span>Custom Domain</span>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($package->customer_panel_access == 1): ?>
                                            <li>
                                                <span><i class="fas fa-check"></i></span>
                                                <span>Customer Panel Access</span>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <span><i class="fas fa-times red"></i></span>
                                                <span>Customer Panel Access</span>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($package->support == 1): ?>
                                            <li>
                                                <span><i class="fas fa-check"></i></span>
                                                <span>Support Module</span>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <span><i class="fas fa-times red"></i></span>
                                                <span>Support Module</span>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($package->qr_code == 1): ?>
                                            <li>
                                                <span><i class="fas fa-check"></i></span>
                                                <span>QR Code</span>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <span><i class="fas fa-times red"></i></span>
                                                <span>QR Code</span>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($package->facebook_pixel == 1): ?>
                                            <li>
                                                <span><i class="fas fa-check"></i></span>
                                                <span>Facebook Pixel</span>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <span><i class="fas fa-times red"></i></span>
                                                <span>Facebook Pixel</span>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($package->google_analytics == 1): ?>
                                            <li>
                                                <span><i class="fas fa-check"></i></span>
                                                <span>Google Analytics</span>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <span><i class="fas fa-times red"></i></span>
                                                <span>Google Analytics</span>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                    <h2>
                                        <?php echo e(landingShowAmount($package->price)); ?>

                                    </h2>
                                    <div class="pricing-btn">
                                        <a href="<?php echo e(route('landing.package.order', $package->id)); ?>" class="cmn--btn">
                                            Purchase now
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Pricing -->

    <!-- Blog -->
    <section class="blog-section pt-100 pb-100">
        <div class="container">
            <div class="section-title text-center">
                <h6 class="subtitle text--base">Blog Posts</h6>
                <h2 class="title">Our Latest News & Tips</h2>
                <p>
                    Deserunt hic consequatur ex placeat! atque repellendus
                    inventore quisquam, perferendis, eum reiciendis quia nesciunt
                    fuga magni.
                </p>
            </div>
            <div class="row g-4 g-lg-3 g-xl-4 justify-content-center">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-10">
                        <div class="blog__item">
                            <a href="<?php echo e(route('landing.blog.show', $blog->slug)); ?>" class="blog-link">&nbsp;</a>
                            <div class="blog__item-img">
                                <img src="<?php echo e(getPhoto($blog->photo)); ?>" alt="blog">
                                <span class="date">
                                    <span><?php echo e($blog->category->name); ?></span>
                                </span>
                            </div>
                            <div class="blog__item-cont">
                                <div class="blog-date">
                                    <span><i class="fas fa-clock"></i></span>
                                    <span><?php echo e(dateFormat($blog->createda_at)); ?></span>
                                </div>
                                <h5 class="blog__item-cont-title line--2">
                                    <?php echo e(Str::limit($blog->title, 50)); ?>

                                </h5>
                                <p class="line--3">
                                    <?php echo Str::limit($blog->details, 100); ?>


                                </p>
                                <div class="blog__author">
                                    <span class="read--more">Read More</span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
    <!-- Blog -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/front/index.blade.php ENDPATH**/ ?>