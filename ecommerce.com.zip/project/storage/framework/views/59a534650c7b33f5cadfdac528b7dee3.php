    <!--==================== Header Section Start ====================-->
    <header class="ecommerce-header px-sm-5">
        <div class="top-header d-none d-lg-block py-2 border-0 font-400">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-4 sm-mx-none">
                        <a href="help-center.html" class="text-general"><span><?php echo app('translator')->get('Help & Support'); ?> :
                                <?php echo e($gs->support_number); ?></span></a>
                    </div>
                    <div class="col-lg-8 d-flex">
                        <ul class="top-links d-flex ms-auto align-items-center">
                            <?php if($gs->currency_show == 1): ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle text-general" data-bs-toggle="dropdown"
                                        role="button" aria-haspopup="true"
                                        aria-expanded="false"><span><?php echo e(sellerCurrencyCode()); ?></span></a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $globalcurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gcurrency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class=""><a
                                                    href="<?php echo e(route('seller.front.currency.set', $gcurrency->id)); ?>"
                                                    class="dropdown-item"><?php echo e($gcurrency->code); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <?php if($gs->language_show == 1): ?>
                                <?php
                                    $language = \DB::table('languages')
                                        ->where('code', Session::get('lang'))
                                        ->first();
                                ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle text-general" data-bs-toggle="dropdown"
                                        role="button" aria-haspopup="true"
                                        aria-expanded="false"><span><?php echo e($language->language); ?></span></a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = App\Models\Language::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('seller.front.language.set', $language->code)); ?>"
                                                    class="dropdown-item"><?php echo e($language->language); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            <li class="my-account-dropdown">
                                <a href="my-account.html" class="has-dropdown"><i
                                        class="flaticon-user-3 flat-mini me-1"></i><?php echo app('translator')->get('My Account'); ?></a>
                                <ul class="my-account-popup">
                                    <?php if(Auth::check()): ?>
                                        <li><a href="<?php echo e(route('seller.user.dashboard')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Dashboard'); ?></span></a></li>
                                        <li><a href="<?php echo e(route('seller.user.profile')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Profile'); ?></span></a></li>
                                        <li><a href="<?php echo e(route('seller.user.logout')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Logout'); ?></span></a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(route('seller.user.login')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Login'); ?></span></a></li>
                                        <li><a href="<?php echo e(route('seller.user.register')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Create Account'); ?></span></a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-nav py-4 d-none d-lg-block">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <nav class="navbar navbar-expand-lg nav-dark nav-primary-hover">
                            <a class="navbar-brand" href="<?php echo e(route('seller.front.index')); ?>"><img class="nav-logo"
                                    src="<?php echo e(getPhoto($gs->header_logo, getUser('user_id'))); ?>"
                                    alt="Image not found !"></a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <i class="navbar-toggler-icon flaticon-menu-2 flat-small text-primary"></i>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav ms-xxl-5">
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?php echo e(route('seller.front.index')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                                    <li class="nav-item dropdown mega-dropdown">
                                        <a class="nav-link dropdown-toggle"
                                            href="<?php echo e(route('seller.front.product.catalog')); ?>"><?php echo e(__('Product')); ?></a>
                                        <ul class="dropdown-menu mega-dropdown-menu">
                                            <li class="mega-container">
                                                <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                                                    <?php $__currentLoopData = $globalcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col">
                                                            <a
                                                                href="<?php echo e(route('seller.front.product.catalog') . '?category=' . $category->slug); ?>"><span
                                                                    class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2"><?php echo e($category->name); ?></span></a>
                                                            <ul>
                                                                <?php if($category->subcategories_count != 0): ?>
                                                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li><a class="dropdown-item"
                                                                                href="<?php echo e(route('seller.front.product.catalog') . '?subcategory=' . $subcategory->slug); ?>"><?php echo e($subcategory->name); ?></a>
                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#"><?php echo app('translator')->get('Pages'); ?></a>
                                        <ul class="dropdown-menu">
                                            <?php
                                                $pages = DB::table('user_pages')
                                                    ->whereUserId(getUser('user_id'))
                                                    ->get();
                                            ?>
                                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a class="dropdown-item"
                                                        href="<?php echo e(route('seller.front.page', $page->slug)); ?>"><?php echo e($page->title); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>

                                    <li class="nav-item"><a class="nav-link"
                                            href="<?php echo e(route('seller.front.blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?php echo e(route('seller.front.contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="col-xl-5 col-lg-3">
                        <div class="margin-right-1 d-flex align-items-center justify-content-end h-100">
                            <div class="product-search-one flex-grow-1 mr-20 global-search touch-screen-view">
                                <form class="form-inline search-pill-shape"
                                    action="<?php echo e(route('seller.front.product.catalog')); ?>" method="get">
                                    <input type="text" class="form-control search-field" name="search"
                                        value="" placeholder="<?php echo app('translator')->get('Search Products'); ?>">
                                    <div class="select-appearance-none">
                                        <select class="form-control" name="category">
                                            <option value=""><?php echo app('translator')->get('All Categories'); ?></option>
                                            <?php $__currentLoopData = $globalcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gcateogry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($gcateogry->slug); ?>"><?php echo e($gcateogry->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <button type="submit" class="search-submit"><i
                                            class="flaticon-search flat-mini text-white"></i></button>
                                </form>
                            </div>
                            <div class="search-view d-xxl-none">
                                <a href="#"
                                    class="search-pop top-quantity d-flex align-items-center text-decoration-none">
                                    <i class="flaticon-search flat-mini text-dark mx-auto"></i>
                                </a>
                            </div>
                            <div class="wishlist-view">
                                <a href="<?php echo e(route('seller.user.wishlist.index')); ?>"
                                    class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                    <i class="flaticon-like flat-mini text-dark mx-auto"></i>
                                    <?php
                                        if (Auth::check()) {
                                            $wishlistCount = count(Auth::user()->wishlists);
                                        } else {
                                            $wishlistCount = 0;
                                        }
                                        if (Session::has('compare' . sellerId())) {
                                            $oldCompare = Session::get('compare' . sellerId());
                                            $compare = new App\Models\Compare($oldCompare);
                                            $products = $compare->items;
                                            $compareCount = count($products);
                                        } else {
                                            $compareCount = 0;
                                        }
                                    ?>
                                    <span
                                        class="header-cart-count wishlist_count1 wishlist_count"><?php echo e($wishlistCount); ?></span>
                                </a>
                            </div>
                            <div class="refresh-view">
                                <a href="<?php echo e(route('seller.front.compare.index')); ?>"
                                    class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                    <i class="flaticon-shuffle flat-mini text-dark mx-auto"></i>
                                    <span
                                        class="header-cart-count compare_count1 compare_count"><?php echo e($compareCount); ?></span>
                                </a>
                            </div>
                            <div class="header-cart-1">
                                <a href="cart.html" class="cart has-cart-data">
                                    <?php
                                        if (Session::has('cart' . getUser('user_id'))) {
                                            $cartCount = count(Session::get('cart' . getUser('user_id')));
                                        } else {
                                            $cartCount = 0;
                                        }
                                    ?>

                                    <div class="cart-icon"><i class="flaticon-shopping-cart flat-mini"></i> <span
                                            class="header-cart-count" id="cart_count1"><?php echo e($cartCount); ?></span>
                                    </div>
                                    <div class="cart-wrap">
                                        <div class="cart-text">Cart</div>
                                        <span class="header-cart-count">(<?php echo e($cartCount); ?>)
                                            <?php echo e($cartCount > 1 ? __('Items') : __('Item')); ?> </span>

                                    </div>
                                </a>
                                <div class="cart-popup" data-href="<?php echo e(route('seller.front.header.cart.load')); ?>">
                                    <?php echo $__env->make('sellerFront.inc.header_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-sticky bg-white py-10">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xxl-2 col-xl-2 col-lg-3 col-6 order-lg-1">
                        <div class="d-flex align-items-center h-100 md-py-10">
                            <div class="nav-leftpush-overlay">
                                <nav class="navbar navbar-expand-lg nav-general nav-primary-hover">
                                    <button type="button" class="push-nav-toggle d-lg-none border-0">
                                        <i class="flaticon-menu-2 flat-small text-primary"></i>
                                    </button>
                                    <div class="navbar-slide-push transation-this">
                                        <div
                                            class="login-signup bg-secondary d-flex justify-content-between py-10 px-20 align-items-center mb-3">
                                            <a href="<?php echo e(route('seller.user.login')); ?>"
                                                class="d-flex align-items-center text-white">
                                                <i class="flaticon-user flat-small me-1"></i>
                                                <span><?php echo app('translator')->get('Login'); ?></span>
                                            </a>
                                            /
                                            <a href="<?php echo e(route('seller.user.register')); ?>"
                                                class="d-flex align-items-center text-white">
                                                <i class="flaticon-user flat-small me-1"></i>
                                                <span><?php echo app('translator')->get('Signup'); ?></span>
                                            </a>
                                            <span class="slide-nav-close"><i
                                                    class="flaticon-cancel flat-mini text-white"></i></span>
                                        </div>
                                        <div class="menu-and-category">
                                            <div class="push-navbar">
                                                <ul class="navbar-nav">
                                                    <li class="nav-item"><a class="nav-link"
                                                            href="<?php echo e(route('seller.front.index')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                                                    </li>
                                                    <li class="nav-item dropdown mega-dropdown">
                                                        <a class="nav-link dropdown-toggle"
                                                            href="#"><?php echo app('translator')->get('Product'); ?></a>
                                                        <ul class="dropdown-menu mega-dropdown-menu">
                                                            <li class="mega-container">
                                                                <div
                                                                    class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                                                                    <?php $__currentLoopData = $globalcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="col">
                                                                            <a
                                                                                href="<?php echo e(route('seller.front.product.catalog') . '?category=' . $category->slug); ?>"><span
                                                                                    class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2"><?php echo e($category->name); ?></span></a>
                                                                            <ul>
                                                                                <?php if($category->subcategories_count != 0): ?>
                                                                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <li><a class="dropdown-item"
                                                                                                href="<?php echo e(route('seller.front.product.catalog') . '?subcategory=' . $subcategory->slug); ?>"><?php echo e($subcategory->name); ?></a>
                                                                                        </li>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>
                                                                            </ul>
                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li class="nav-item dropdown">
                                                        <a class="nav-link dropdown-toggle"
                                                            href="#"><?php echo app('translator')->get('Pages'); ?></a>
                                                        <ul class="dropdown-menu">
                                                            <?php
                                                                $pages = DB::table('user_pages')
                                                                    ->whereUserId(getUser('user_id'))
                                                                    ->get();
                                                            ?>
                                                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><a class="dropdown-item"
                                                                        href="<?php echo e(route('seller.front.page', $page->slug)); ?>"><?php echo e($page->title); ?></a>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </li>

                                                    <li class="nav-item"><a class="nav-link"
                                                            href="<?php echo e(route('seller.front.blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a>
                                                    </li>
                                                    <li class="nav-item"><a class="nav-link"
                                                            href="<?php echo e(route('seller.front.contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                            <a class="navbar-brand" href="<?php echo e(route('seller.front.index')); ?>"><img class="nav-logo"
                                    src="<?php echo e(getPhoto($gs->header_logo, getUser('user_id'))); ?>"
                                    alt="Image not found !"></a>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-4 col-lg-3 col-6 order-lg-3">
                        <div class="margin-right-1 d-flex align-items-center justify-content-end h-100 md-py-10">
                            <?php if($gs->currency_show == 1): ?>
                                <div class="dropdown">
                                    <a href="#" class="dropdown-toggle __drp-icon text-general"
                                        data-bs-toggle="dropdown" role="button" aria-haspopup="true"
                                        aria-expanded="false"><span><?php echo e(sellerCurrencyCode()); ?></span></a>
                                    <ul class="dropdown-menu bg-white">
                                        <?php $__currentLoopData = $globalcurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gcurrency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class=""><a
                                                    href="<?php echo e(route('seller.front.currency.set', $gcurrency->id)); ?>"
                                                    class="dropdown-item"><?php echo e($gcurrency->code); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="sign-in position-relative font-general my-account-dropdown">
                                <a href="#0"
                                    class="has-dropdown d-flex align-items-center text-dark text-decoration-none"
                                    title="My Account">
                                    <i class="flaticon-user-3 flat-mini me-1 mx-auto"></i>
                                </a>
                                <ul class="my-account-popup">
                                    <?php if(Auth::check()): ?>
                                        <li><a href="<?php echo e(route('seller.user.dashboard')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Dashboard'); ?></span></a></li>
                                        <li><a href="<?php echo e(route('seller.user.profile')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Profile'); ?></span></a></li>
                                        <li><a href="<?php echo e(route('seller.user.logout')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Logout'); ?></span></a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(route('seller.user.login')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Login'); ?></span></a></li>
                                        <li><a href="<?php echo e(route('seller.user.register')); ?>"><span
                                                    class="menu-item-text"><?php echo app('translator')->get('Create Account'); ?></span></a></li>
                                    <?php endif; ?>

                                </ul>
                            </div>
                            <div class="wishlist-view">
                                <a href="<?php echo e(route('seller.user.wishlist.index')); ?>"
                                    class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                    <i class="flaticon-like flat-mini text-dark mx-auto"></i>
                                    <span class="header-cart-count wishlist_count"><?php echo e($wishlistCount); ?></span>
                                </a>
                            </div>
                            <div class="refresh-view">
                                <a href="<?php echo e(route('seller.front.compare.index')); ?>"
                                    class="position-relative top-quantity d-flex align-items-center text-dark text-decoration-none">
                                    <i class="flaticon-shuffle flat-mini text-dark mx-auto"></i>
                                    <span class="header-cart-count compare_count"><?php echo e($compareCount); ?></span>
                                </a>
                            </div>



                            <div class="header-cart-1">
                                <a href="cart.html" class="cart has-cart-data">
                                    <?php
                                        if (Session::has('cart' . getUser('user_id'))) {
                                            $cartCount = count(Session::get('cart' . getUser('user_id')));
                                        } else {
                                            $cartCount = 0;
                                        }
                                    ?>
                                    <div class="cart-icon"><i class="flaticon-shopping-cart flat-mini"></i> <span
                                            class="header-cart-count" id="cart_count"><?php echo e($cartCount); ?></span>
                                    </div>
                                    <div class="cart-wrap">
                                        <div class="cart-text">Cart</div>

                                        <span class="header-cart-count">(<?php echo e($cartCount); ?>)
                                            <?php echo e($cartCount > 1 ? __('Items') : __('Item')); ?> </span>

                                    </div>
                                </a>
                                <div class="cart-popup" data-href="<?php echo e(route('seller.front.header.cart.load')); ?>">
                                    <?php echo $__env->make('sellerFront.inc.header_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="col-xxl-7 col-xl-6 col-lg-6 col-12 order-lg-2">
                        <div class="product-search-one">
                            <form class="form-inline search-pill-shape"
                                action="<?php echo e(route('seller.front.product.catalog')); ?>" method="get">
                                <input type="text" class="form-control search-field" name="search"
                                    value="" placeholder="<?php echo app('translator')->get('Search Products'); ?>">
                                <div class="select-appearance-none">
                                    <select class="form-control" name="category">
                                        <option value=""><?php echo app('translator')->get('All Categories'); ?></option>
                                        <?php $__currentLoopData = $globalcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gcateogry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gcateogry->slug); ?>"><?php echo e($gcateogry->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <button type="submit" class="search-submit"><i
                                        class="flaticon-search flat-mini text-white"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--==================== Header Section End ====================-->
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/inc/header.blade.php ENDPATH**/ ?>