<script src="<?php echo e(asset('assets/front')); ?>/js/jquery.min.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/greensock.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/layerslider.transitions.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/layerslider.kreaturamedia.jquery.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/popper.min.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/wow.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/jquery.countdown.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/sweetalert.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/jquery.elevatezoom.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/custom.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/myscript.js"></script>
<script src="<?php echo e(asset('assets/front')); ?>/js/user.js"></script>

<?php echo $__env->yieldContent('scripts'); ?>
<script>
    'use strict';
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })

    function showAmount(amount){
        let direction = '<?php echo e(sellerCurrencyDirection()); ?>';
        if(direction == 'left'){
            return '<?php echo e(sellerCurrency()); ?>'+ parseFloat(amount).toFixed(2);
        }else{
            return parseFloat(amount).toFixed(2)+'<?php echo e(sellerCurrency()); ?>';
        } 
    }

    $("#single-image-zoom").elevateZoom({
            gallery: 'gallery_09',
            zoomType: "inner",
            cursor: "crosshair",
            galleryActiveClass: 'active',
            imageCrossfade: true,
            loadingIcon: 'http://www.elevateweb.co.uk/spinner.gif'
        });
        //pass the images to Fancybox
        $("#single-image-zoom").bind("click", function(e) {
            var ez = $('#single-image-zoom').data('elevateZoom');
            $.fancybox(ez.getGalleryList());
            return false;
        });
</script>

<?php if(Session::has('success')): ?>
    <script>
        'use strict';
        Toast.fire({
        icon: 'success',
        title: '<?php echo e(Session::get('success')); ?>'
        })
    </script>
<?php endif; ?>


<?php if(Session::has('error')): ?>
    <script>
        'use strict';
        Toast.fire({
        icon: 'error',
        title: '<?php echo e(Session::get('error')); ?>'
    })
    </script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/inc/script.blade.php ENDPATH**/ ?>