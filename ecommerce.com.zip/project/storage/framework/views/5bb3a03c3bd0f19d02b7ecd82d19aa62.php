
<?php $__env->startSection('breadcrumb'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo app('translator')->get('Order No:'); ?> <?php echo e($order->order_no); ?></h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('Orders'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-header">
                    <h4>Order Information</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <td>Order No</td>
                                    <td><b><?php echo e($order->order_no); ?></b></td>
                                </tr>
                                <tr>
                                    <td>Order Status</td>
                                    <td>
                                        <?php if($order->status == 0): ?>
                                            <span class="badge badge-primary"> <?php echo app('translator')->get('Pending'); ?> </span>
                                        <?php elseif($order->status == 1): ?>
                                            <span class="badge badge-success"> <?php echo app('translator')->get('Approved'); ?> </span>
                                        <?php else: ?>
                                            <span class="badge badge-success"> <?php echo app('translator')->get('Expired'); ?> </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Order Created Date</td>
                                    <td><b><?php echo e(dateFormat($order->created_at)); ?></b></td>
                                </tr>
                                
                                <tr>
                                    <td>Order Will Be Expired</td>
                                    <td><b><?php echo e(dateFormat($order->will_expire)); ?></b></td>
                                </tr>
                                <tr>
                                    <td>Order Amount</td>
                                    <td><b><?php echo e(adminShowAmount($order->amount)); ?></b></td>
                                </tr>
                                
                                <tr>
                                    <td>Plan Name</td>
                                    <td><b><?php echo e($order->package_info->name); ?></b></td>
                                </tr>
                                <tr>
                                    <td>Payment Mode</td>
                                    <td><b><?php echo e($order->method); ?></b></td>
                                </tr>
                                <tr>
                                    <td>Transaction Id</td>
                                    <td><b><?php echo e($order->txn); ?></b></td>
                                </tr>
                                <tr>
                                    <td>Payment Status</td>
                                    <td>
                                          <?php if($order->payment_status == 0): ?>
                                             <span class="badge badge-danger"> <?php echo app('translator')->get('Unpaid'); ?> </span>
                                          <?php else: ?>
                                             <span class="badge badge-success"> <?php echo app('translator')->get('Paid'); ?> </span>
                                          <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-header">
                    <h4>User Information</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <td>User Name</td>
                                    <td><b><a href="<?php echo e(route('admin.customer.view',$order->user_id)); ?>"><?php echo e($order->user->name); ?></a></b></td>
                                </tr>
                                <tr>
                                    <td>User Email</td>
                                    <td><a href="mailto:<?php echo e($order->user->name); ?>"><b><?php echo e($order->user->name); ?></b></a></td>
                                </tr>
                                <tr>
                                    <td>User Domain</td>
                                    <td><b><a href="javascript:;"><?php echo e($order->user->domain->domain); ?></a></b></td>
                                </tr>
                                <tr>
                                    <td>Join Date</td>
                                    <td><b><a href="javascript:;"><?php echo e(dateFormat($order->user->created_at)); ?></a></b></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/admin/order/details.blade.php ENDPATH**/ ?>