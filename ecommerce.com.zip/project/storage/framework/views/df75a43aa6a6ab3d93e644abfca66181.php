<link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/animate.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/webfonts/flaticon/flaticon.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/style.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/user.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/template.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/front')); ?>/css/category/minimal.css"><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/inc/style.blade.php ENDPATH**/ ?>