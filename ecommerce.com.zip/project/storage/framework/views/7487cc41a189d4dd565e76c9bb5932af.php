

<?php $__env->startSection('content'); ?>
    <div class="full-row py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-2"><?php echo app('translator')->get('Products'); ?></h3>
                </div>
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 bg-transparent p-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('seller.front.index')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                            <li class="breadcrumb-item"><a href="javascript:;"><?php echo app('translator')->get('Products'); ?></a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="full-row pt-0">
        <div class="container">
            <div class="row">
                <div class="col-xl-3">
                    <div id="sidebar" class="widget-title-bordered-full">
                        <div class="filter-btn d-xl-none ms-auto">
                            <i class="fas fa-times"></i>
                        </div>
                        <div id="woocommerce_product_categories-4"
                            class="widget woocommerce widget_product_categories widget-toggle">
                            <h2 class="widget-title"><?php echo app('translator')->get('Product categories'); ?></h2>
                            <ul class="product-categories">
                                <?php $__currentLoopData = $globalcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cat-item cat-parent">
                                        <a href="<?php echo e(route('seller.front.product.catalog').'?category='.$category->slug); ?>"><?php echo e($category->name); ?> <span
                                                class="count">(<?php echo e($category->products_count); ?>)</span></a>
                                        <?php if($category->subcategories_count != 0): ?>
                                            <span class="has-child"></span>
                                            <ul class="children">
                                                <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="cat-item"><a href="<?php echo e(route('seller.front.product.catalog').'?subcategory='.$subcategory->slug); ?>"><?php echo e($subcategory->name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div id="bigbazar-price-filter-list-1"
                            class="widget bigbazar_widget_price_filter_list widget_layered_nav widget-toggle">
                            <h2 class="widget-title"><?php echo app('translator')->get('Brands'); ?></h2>
                            <ul class="price-filter-list">
                                <li class="wc-layered-nav-term <?php echo e(!request()->input('brand') ? 'chosen' : ''); ?>">
                                    <span class="woocommerce-Price-amount product__brand" data="">
                                        <span class="woocommerce-Price-currencySymbol"><?php echo app('translator')->get('All Brands'); ?></span>
                                    </span>
                                </li>
                                <?php $__currentLoopData = $product_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        class="wc-layered-nav-term  <?php echo e(request()->input('brand') == $brand->id ? 'chosen' : ''); ?>">
                                        <span class="woocommerce-Price-amount product__brand" data="<?php echo e($brand->id); ?>">
                                            <span class="woocommerce-Price-currencySymbol"><?php echo e($brand->name); ?></span>
                                        </span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>


                        <div id="bigbazar-price-filter-list-1"
                            class="widget bigbazar_widget_price_filter_list widget_layered_nav widget-toggle">
                            <h2 class="widget-title">Colors</h2>
                            <ul class="price-filter-list">
                                <li class="wc-layered-nav-term <?php echo e(!request()->input('color') ? 'chosen' : ''); ?>">
                                    <span class="woocommerce-Price-amount product__color" data="">
                                        <span class="woocommerce-Price-currencySymbol"><?php echo app('translator')->get('All Colors'); ?></span>
                                    </span>
                                </li>
                                <?php $__currentLoopData = $product_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        class="wc-layered-nav-term <?php echo e(request()->input('color') == $color->id ? 'chosen' : ''); ?>">
                                        <span class="woocommerce-Price-amount product__color" data="<?php echo e($color->id); ?>">
                                            <span class="woocommerce-Price-currencySymbol"><?php echo e($color->color_name); ?></span>
                                        </span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>


                        <?php $__currentLoopData = $product_attrbutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($attribute->variations_count != 0): ?>
                                <div id="bigbazar-price-filter-list-1"
                                    class="widget bigbazar_widget_price_filter_list widget_layered_nav widget-toggle">
                                    <h2 class="widget-title"><?php echo e($attribute->name); ?></h2>
                                    <ul class="price-filter-list">
                                        <?php $__currentLoopData = $attribute->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="wc-layered-nav-term product_attribute <?php echo e(request()->input('attribute') && in_array($attribute->id . '_' . $variation->id, explode(',', request()->input('attribute'))) ? 'chosen' : ''); ?>"
                                                data-attribute="<?php echo e($attribute->id); ?>"
                                                data-variation="<?php echo e($variation->id); ?>">
                                                <span class="woocommerce-Price-amount amount">
                                                    <span
                                                        class="woocommerce-Price-currencySymbol"><?php echo e($variation->name); ?></span>
                                                </span>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button id="clear__attributes" class="btn btn-danger btn-small"><?php echo app('translator')->get('Clear Attribute'); ?></button>
                    </div>
                </div>
                <div class="col-xl-9">
                    <div
                        class="products-header d-flex flex-wrap justify-content-between align-items-center py-10 px-20 bg-light md-mt-30 gap-10px">
                        <div class="products-header-left d-flex align-items-center me-auto">
                            <h6 class="woocommerce-products-header__title page-title d-block"><?php echo app('translator')->get('Products'); ?></h6>
                        </div>
                        <div class="filter-btn d-xl-none ms-auto">
                            <i class="fas fa-filter"></i>
                        </div>
                        <div class="gap-10px d-flex flex-wrap">
                            <div class="products-header-right">
                                <select name="pagination" class="orderby" id="pagination__product" aria-label="Shop order">
                                    <option value="9" <?php echo e(request()->input('pagination') == '9' ? 'selected' : ''); ?>> <?php echo app('translator')->get('Show:9'); ?>
                                    </option>
                                    <option value="12" <?php echo e(request()->input('pagination') == '12' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Show:12'); ?> </option>
                                    <option value="16" <?php echo e(request()->input('pagination') ==
                                    '16' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Show:16'); ?></option>
                                    <option value="20" <?php echo e(request()->input('pagination') == '20' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Show:20'); ?></option>
                                </select>
                            </div>
                            <div class="products-header-right">
                                <select name="orderby" class="orderby" id="orderby" aria-label="Shop order">
                                    <option value="latest" <?php echo e(request()->input('sort') == 'latest' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Sort by latest'); ?></option>
                                    <option value="oldest" <?php echo e(request()->input('sort') == 'oldest' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Sort by Oldest'); ?></option>
                                    <option value="name_a_z" <?php echo e(request()->input('sort') == 'name_a_z' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Sort by A TO Z'); ?></option>
                                    <option value="name_z_a" <?php echo e(request()->input('sort') == 'name_z_a' ? 'selected' : ''); ?>>
                                        <?php echo app('translator')->get('Sort by Z TO A'); ?></option>
                                    <option value="low_to_high"
                                        <?php echo e(request()->input('sort') == 'low_to_high' ? 'selected' : ''); ?>><?php echo app('translator')->get('Sort by price: low to high'); ?>
                                    </option>
                                    <option value="high_to_low"
                                        <?php echo e(request()->input('sort') == 'high_to_low' ? 'selected' : ''); ?>><?php echo app('translator')->get('Sort by price: high to low'); ?>
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="showing-products pt-30 pb-50 border-2 border-bottom border-light">
                        <div
                            class="row row-cols-xl-4 row-cols-md-3 row-cols-sm-2 row-cols-1 product-style-3 e-hover-image-zoom after-border-two gy-3 gx-0">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="<?php echo e(route('seller.front.product.details', $product->slug)); ?>"
                                                    class="woocommerce-LoopProduct-link"><img
                                                        src="<?php echo e(getPhoto($product->photo, getUser('user_id'))); ?>"
                                                        alt="Product Image"></a>
                                            </div>
                                            <div class="product-info">
                                                <div class="product-cats"><a
                                                        href="#"><?php echo e($product->category->name); ?></a></div>
                                                <h3 class="product-title"><a
                                                        href="<?php echo e(route('seller.front.product.details', $product->slug)); ?>"><?php echo e($product->name); ?></a>
                                                </h3>
                                                <div class="product-price">
                                                    <div class="price">
                                                        <ins><?php echo e(productBasePrice($product)); ?></ins>
                                                        <?php if($product->previous_price): ?>
                                                            <del><?php echo e(sellerShowAmount($product->previous_price)); ?></del>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="shipping-feed-back">
                                                    <div class="star-rating">
                                                        <div class="rating-wrap">
                                                            <a href="<?php echo e(route('seller.front.product.details',$product->slug)); ?>">
                                                                <i class="fas fa-star"></i><span> <?php echo e($product->rating()); ?> (<?php echo e($product->reviews_count); ?>)</span>
                                                            </a>
                                                        </div>
                                                       
                                                    </div>

                                                </div>
                                                <div class="hover-area">
                                                    <div class="cart-button">
                                                        <a href="javascript:;"
                                                            data-href="<?php echo e(route('seller.front.cart.store')); ?>"
                                                            class="button  add__to__cart" itemid="<?php echo e($product->id); ?>"
                                                            data-bs-toggle="tooltip" data-bs-placement="right"
                                                            title="add" data-bs-original-title="Add to Cart"
                                                            aria-label="Add to Cart"><?php echo app('translator')->get('Add to Cart'); ?></a>
                                                    </div>
                                                    <div class="wishlist-button">
                                                        <?php if(Auth::check()): ?>
                                                            <a class="add_to_wishlist add__wishlist" href="javascript:;"
                                                                data-href="<?php echo e(route('seller.user.wishlist.add', $product->id)); ?>"
                                                                data-bs-toggle="tooltip" data-bs-placement="right"
                                                                title="" data-bs-original-title="Add to Wishlist"
                                                                aria-label="Add to Wishlist"><?php echo app('translator')->get('Wishlist'); ?></a>
                                                        <?php else: ?>
                                                            <a class="add_to_wishlist"
                                                                href="<?php echo e(route('seller.user.login')); ?>"
                                                                data-bs-toggle="tooltip" data-bs-placement="right"
                                                                title="" data-bs-original-title="Add to Wishlist"
                                                                aria-label="Add to Wishlist"><?php echo app('translator')->get('Wishlist'); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="compare-button">
                                                        <a class="compare button" href="javascript:;"
                                                            data-href="<?php echo e(route('seller.front.compare.add', $product->id)); ?>"
                                                            data-bs-toggle="tooltip" data-bs-placement="right"
                                                            title="" data-bs-original-title="Compare"
                                                            aria-label="Compare"><?php echo app('translator')->get('Compare'); ?></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col">
                                    <div class="product-info">
                                        <h3 class="product-title"><?php echo app('translator')->get('No Product Found'); ?></h3>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center pt-3">
                        <div class="pagination-style-one">
                            <nav aria-label="Page navigation example">
                                <?php if($products->lastPage() > 1): ?>
                                    <ul class="pagination">
                                        <li class="page-item <?php echo e($products->currentPage() == 1 ? 'disabled' : ''); ?>">
                                            <a class="page-link" href="<?php echo e($products->url(1)); ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                        <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                                            <li class="page-item <?php echo e($products->currentPage() == $i ? 'active' : ''); ?>">
                                                <a class="page-link"
                                                    href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
                                            </li>
                                        <?php endfor; ?>
                                        <li
                                            class="page-item <?php echo e($products->currentPage() == $products->lastPage() ? 'disabled' : ''); ?>">
                                            <a class="page-link"
                                                href="<?php echo e($products->url($products->currentPage() + 1)); ?>"
                                                aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                    </ul>
                                <?php endif; ?>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Shop Area End Here -->

    <form hidden action="<?php echo e(route('seller.front.product.catalog')); ?>" id="search__products" method="GET">
        <input type="text" name="sort" id="sort"
            value="<?php echo e(request()->input('sort') ? request()->input('sort') : ''); ?>">
        <input type="text" name="pagination" id="pagination"
            value="<?php echo e(request()->input('pagination') ? request()->input('pagination') : ''); ?>">
        <input type="text" name="color" id="color"
            value="<?php echo e(request()->input('color') ? request()->input('color') : ''); ?>">
        <input type="text" name="brand" id="brand"
            value="<?php echo e(request()->input('brand') ? request()->input('brand') : ''); ?>">
        <input type="text" name="attribute" id="attribute"
            value="<?php echo e(request()->input('attribute') ? request()->input('attribute') : ''); ?>">
    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        // php array abc to js array

        $(document).on('change', '#orderby', function() {
            $('#sort').val($(this).val());
            $('#search__products').submit();
        })
        $(document).on('change', '#pagination__product', function() {
            $('#pagination').val($(this).val());
            $('#search__products').submit();
        })
        $(document).on('click', '.product__brand', function() {
            let brand = $(this).attr('data');
            $('#brand').val(brand);
            $('#search__products').submit();
        })
        $(document).on('click', '.product__color', function() {
            let color = $(this).attr('data');
            $('#color').val(color);
            $('#search__products').submit();
        })

        let array = [];

        $(document).on('click', '.product_attribute', function() {

            let xarray = $('#attribute').val();
            if (xarray != '') {
                array = xarray.split(',');
            }
            console.log(array);
            // return true;
            // loop through array
            let attribute = $(this).attr('data-attribute');
            let variation = $(this).attr('data-variation');
            let value = attribute + '_' + variation;
            array.push(value);

            array = array.filter(function(item, pos) {
                return array.indexOf(item) == pos;
            })

            $('#attribute').val(array);
            $('#search__products').submit();
        })

        $(document).on('click', '#clear__attributes', function() {
            $('#attribute').remove();
            $('#search__products').submit();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sellerFront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/sellerFront/product/catalog.blade.php ENDPATH**/ ?>