<html>

<head>
    <title><?php echo e($gs->title); ?></title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <link rel="shortcut icon" href="<?php echo e(getPhoto($gs->favicon)); ?>" />
    <link href="https://goSellJSLib.b-cdn.net/v2.0.0/css/gosell.css" rel="stylesheet" />
</head>

<body>

    <div id="root"></div>
    <button style="display:none" id="openLightBox" onclick="goSell.openLightBox()">Payment Now</button>
    <script src="<?php echo e(asset('assets/landing')); ?>/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://goSellJSLib.b-cdn.net/v2.0.0/js/gosell.js"></script>
    <script>


        $(document).ready(function() {
            $('#openLightBox').click();
        });

        goSell.config({
            containerID: "root",
            gateway: {
                publicKey: "<?php echo e($paydata['public_key']); ?>",
                language: "en",
                contactInfo: true,
                supportedCurrencies: "all",
                supportedPaymentMethods: "all",
                saveCardOption: false,
                customerCards: true,
                notifications: 'standard',
                callback: (response) => {
                    console.log('response', response);
                },
                onClose: () => {
                    console.log("onClose Event");
                    window.location.href = "<?php echo e($previous); ?>"
                },
                backgroundImg: {
                    url: "https://goSellJSLib.b-cdn.net/v2.0.0/imgs/tap-bg.png",
                    opacity: '0.5'
                },
                labels: {
                    cardNumber: "Card Number",
                    expirationDate: "MM/YY",
                    cvv: "CVV",
                    cardHolder: "Name on Card",
                    actionButton: "Pay"
                },
                style: {
                    base: {
                        color: '#535353',
                        lineHeight: '18px',
                        fontFamily: 'sans-serif',
                        fontSmoothing: 'antialiased',
                        fontSize: '16px',
                        '::placeholder': {
                            color: 'rgba(0, 0, 0, 0.26)',
                            fontSize: '15px'
                        }
                    },
                    invalid: {
                        color: 'red',
                        iconColor: '#fa755a '
                    }
                }
            },
            customer: {
                id: null,
                first_name: "<?php echo e($information['name']); ?>",
                middle_name: "",
                last_name: "",
                email: "<?php echo e($information['email']); ?>",
                phone: null
            },
            order: {
                amount: "<?php echo e($price); ?>",
                currency: "<?php echo e($currency); ?>",
                items: null,
                shipping: null,
                taxes: null
            },
            transaction: {
                mode: 'charge',
                charge: {
                    saveCard: false,
                    threeDSecure: true,
                    description: "Tap Payment",
                    statement_descriptor: "Tap Payment",
                    reference: {
                        transaction: null,
                        order: null
                    },
                    metadata: {},
                    receipt: {
                        email: false,
                        sms: true
                    },
                    redirect: "<?php echo e(route('landing.tap.payment.notify')); ?>",
                    post: null,
                }
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ecommerce.com\project\resources\views/front/tab.blade.php ENDPATH**/ ?>