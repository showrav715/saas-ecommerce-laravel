<?php

use App\Http\Controllers\SellerPayment\AuthorizeController;
use App\Http\Controllers\SellerPayment\PaypalController;
use App\Http\Controllers\SellerPayment\PaystackController;
use App\Http\Controllers\SellerPayment\PaytmController;
use App\Http\Controllers\SellerPayment\RazorpayController;
use App\Http\Controllers\SellerPayment\StripeController;
use App\Http\Controllers\Seller\AttributeController;
use App\Http\Controllers\Seller\BannerController;
use App\Http\Controllers\Seller\BlogCategoryController;
use App\Http\Controllers\Seller\BlogController;
use App\Http\Controllers\Seller\BottomBannerController;
use App\Http\Controllers\Seller\BrandController;
use App\Http\Controllers\Seller\CategoryController;
use App\Http\Controllers\Seller\ChildCategoryController;
use App\Http\Controllers\Seller\ColorController;
use App\Http\Controllers\Seller\ContactPageController;
use App\Http\Controllers\Seller\CouponController;
use App\Http\Controllers\Seller\CustomerController;
use App\Http\Controllers\Seller\DomainSettingController;
use App\Http\Controllers\Seller\GeneralSettingController;
use App\Http\Controllers\Seller\LanguageController;
use App\Http\Controllers\Seller\LocationController;
use App\Http\Controllers\Seller\LoginController;
use App\Http\Controllers\Seller\ManageCurrencyController;
use App\Http\Controllers\Seller\OrderController;
use App\Http\Controllers\Seller\PageController;
use App\Http\Controllers\Seller\PaymentMethodController;
use App\Http\Controllers\Seller\ProductController;
use App\Http\Controllers\Seller\SellerController;
use App\Http\Controllers\Seller\ServiceController;
use App\Http\Controllers\Seller\ShippingController;
use App\Http\Controllers\Seller\SliderController;
use App\Http\Controllers\Seller\SubscriptionController;
use App\Http\Controllers\Seller\SupportTicketController;
use App\Http\Controllers\Seller\VariationController;
use Illuminate\Support\Facades\Route;

// middleware
Route::middleware('domain-check')->group(function () {

    Route::prefix('seller')->name('seller.')->group(function () {

        Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
        Route::post('/login', [LoginController::class, 'login']);

        Route::get('/forgot-password', [LoginController::class, 'forgotPasswordForm'])->name('forgot.password');
        Route::post('/forgot-password', [LoginController::class, 'forgotPasswordSubmit']);
        Route::get('forgot-password/verify-code', [SellerLoginController::class, 'verifyCode'])->name('verify.code');
        Route::post('forgot-password/verify-code', [LoginController::class, 'verifyCodeSubmit']);
        Route::get('reset-password', [LoginController::class, 'resetPassword'])->name('reset.password');
        Route::post('reset-password', [LoginController::class, 'resetPasswordSubmit']);

        Route::middleware('auth:web')->group(function () {

            Route::get('/logout', [LoginController::class, 'logout'])->name('logout');
            Route::get('/', [SellerController::class, 'index'])->name('dashboard');
            Route::get('/profile', [SellerController::class, 'profile'])->name('profile');
            Route::post('/profile/update', [SellerController::class, 'profileupdate'])->name('profile.update');
            Route::get('/password', [SellerController::class, 'passwordreset'])->name('password');
            Route::post('/password/update', [SellerController::class, 'changepass'])->name('password.update');

            Route::middleware('seller-end-date')->group(function () {

// page
                Route::get('/page', [PageController::class, 'index'])->name('page.index');
                Route::get('/page/create', [PageController::class, 'create'])->name('page.create');
                Route::post('/page/store', [PageController::class, 'store'])->name('page.store');
                Route::get('/page/edit/{id}', [PageController::class, 'edit'])->name('page.edit');
                Route::put('/page/update/{id}', [PageController::class, 'update'])->name('page.update');
                Route::post('/page/destroy', [PageController::class, 'destroy'])->name('page.destroy');

// slider
                Route::get('/slider', [SliderController::class, 'index'])->name('slider.index');
                Route::get('/slider/create', [SliderController::class, 'create'])->name('slider.create');
                Route::post('/slider/store', [SliderController::class, 'store'])->name('slider.store');
                Route::get('/slider/edit/{id}', [SliderController::class, 'edit'])->name('slider.edit');
                Route::put('/slider/update/{id}', [SliderController::class, 'update'])->name('slider.update');
                Route::post('/slider/destroy', [SliderController::class, 'destroy'])->name('slider.destroy');

// category
                Route::get('/categories', [CategoryController::class, 'index'])->name('category.index');
                Route::post('/store-category', [CategoryController::class, 'store'])->name('category.store');
                Route::put('/update-category/{id}', [CategoryController::class, 'update'])->name('category.update');
                Route::delete('/delete-category', [CategoryController::class, 'destory'])->name('category.destroy');
// child category
                Route::get('/{id}/child-categories', [ChildCategoryController::class, 'index'])->name('childcategory.index');
                Route::post('/store-child-category/{id}', [ChildCategoryController::class, 'store'])->name('childcategory.store');
                Route::put('/update-child-category/{id}', [ChildCategoryController::class, 'update'])->name('childcategory.update');
                Route::delete('/delete-child-category', [ChildCategoryController::class, 'destory'])->name('childcategory.destroy');

// colors
                Route::get('/colors', [ColorController::class, 'index'])->name('color.index');
                Route::post('/store-color', [ColorController::class, 'store'])->name('color.store');
                Route::put('/update-color/{id}', [ColorController::class, 'update'])->name('color.update');
                Route::delete('/delete-color', [ColorController::class, 'destory'])->name('color.destroy');

// attribute
                Route::get('/attributes', [AttributeController::class, 'index'])->name('attribute.index');
                Route::post('/store-attribute', [AttributeController::class, 'store'])->name('attribute.store');
                Route::put('/update-attribute/{id}', [AttributeController::class, 'update'])->name('attribute.update');
                Route::delete('/delete-attribute', [AttributeController::class, 'destory'])->name('attribute.destroy');
//variation
                Route::get('/variations/{id}', [VariationController::class, 'index'])->name('variation.index');
                Route::post('/store-variation', [VariationController::class, 'store'])->name('variation.store');
                Route::put('/update-variation/{id}', [VariationController::class, 'update'])->name('variation.update');
                Route::delete('/delete-variation', [VariationController::class, 'destory'])->name('variation.destroy');

// products
                Route::get('/products', [ProductController::class, 'index'])->name('product.index');
                Route::get('/products/create', [ProductController::class, 'create'])->name('product.create');
                Route::post('/products/store', [ProductController::class, 'store'])->name('product.store');
                Route::get('/products/{id}/edit', [ProductController::class, 'edit'])->name('product.edit');
                Route::put('/products/{id}/update', [ProductController::class, 'update'])->name('product.update');
                Route::delete('/product/delete', [ProductController::class, 'destroy'])->name('product.destroy');
                Route::get('/products/variations', [ProductController::class, 'getVariation'])->name('product.variation.get');
                Route::get('/products/get/subcategory', [ProductController::class, 'getSubcategory'])->name('product.subcategory.get');
                Route::get('/products/highlight', [ProductController::class, 'highlight'])->name('product.highlight');
                Route::post('/products/highlight/submit', [ProductController::class, 'highlightSubmit'])->name('product.highlight.submit');
                Route::get('/product/gallery/delete/{id}', [ProductController::class, 'galleryDelete'])->name('gallery.delete');

// coupons
                Route::get('/coupons', [CouponController::class, 'index'])->name('coupon.index');
                Route::post('/store-coupon', [CouponController::class, 'store'])->name('coupon.store');
                Route::put('/update-coupon/{id}', [CouponController::class, 'update'])->name('coupon.update');
                Route::delete('/delete-coupon', [CouponController::class, 'destory'])->name('coupon.destroy');

// locations
                Route::get('/locations', [LocationController::class, 'index'])->name('location.index');
                Route::post('/store-location', [LocationController::class, 'store'])->name('location.store');
                Route::put('/update-location/{id}', [LocationController::class, 'update'])->name('location.update');
                Route::delete('/delete-location', [LocationController::class, 'destory'])->name('location.destroy');

// shipping
                Route::get('/shipping', [ShippingController::class, 'index'])->name('shipping.index');
                Route::post('/store-shipping', [ShippingController::class, 'store'])->name('shipping.store');
                Route::put('/update-shipping/{id}', [ShippingController::class, 'update'])->name('shipping.update');
                Route::delete('/delete-shipping', [ShippingController::class, 'destory'])->name('shipping.destroy');

// blog category
                Route::get('blog-category', [BlogCategoryController::class, 'index'])->name('bcategory.index');
                Route::post('blog-category/store', [BlogCategoryController::class, 'store'])->name('bcategory.store');
                Route::put('blog-category/update/{id}', [BlogCategoryController::class, 'update'])->name('bcategory.update');
                Route::delete('blog-category/destroy', [BlogCategoryController::class, 'destroy'])->name('bcategory.destroy');
// blog
                Route::get('blog', [BlogController::class, 'index'])->name('blog.index');
                Route::get('blog/create', [BlogController::class, 'create'])->name('blog.create');
                Route::post('blog/store', [BlogController::class, 'store'])->name('blog.store');
                Route::get('blog/edit/{blog}', [BlogController::class, 'edit'])->name('blog.edit');
                Route::put('blog/update/{blog}', [BlogController::class, 'update'])->name('blog.update');
                Route::delete('blog-delete/{blog}', [BlogController::class, 'destroy'])->name('blog.destroy');

// banners
                Route::get('/banners', [BannerController::class, 'index'])->name('banner.index');
                Route::post('/store-banner', [BannerController::class, 'store'])->name('banner.store');
                Route::put('/update-banner/{id}', [BannerController::class, 'update'])->name('banner.update');
                Route::delete('/delete-banner', [BannerController::class, 'destory'])->name('banner.destroy');
// bottom banner
                Route::get('/bottom-banners', [BottomBannerController::class, 'index'])->name('bottom-banner.index');
                Route::put('/update-bottom-banner/{id}', [BottomBannerController::class, 'update'])->name('bottom-banner.update');

// services
                Route::get('/services', [ServiceController::class, 'index'])->name('service.index');
                Route::post('/store-service', [ServiceController::class, 'store'])->name('service.store');
                Route::put('/update-service/{id}', [ServiceController::class, 'update'])->name('service.update');
                Route::delete('/delete-service', [ServiceController::class, 'destory'])->name('service.destroy');

// Brand
                Route::get('/brands', [BrandController::class, 'index'])->name('brand.index');
                Route::post('/store-brand', [BrandController::class, 'store'])->name('brand.store');
                Route::put('/update-brand/{id}', [BrandController::class, 'update'])->name('brand.update');
                Route::delete('/delete-brand', [BrandController::class, 'destory'])->name('brand.destroy');

// contact page
                Route::get('/contact-page', [ContactPageController::class, 'index'])->name('contact.page.index');
                Route::put('/update-contact-page', [ContactPageController::class, 'update'])->name('contact.page.update');
// contact messages
                Route::get('/contact-messages', [ContactPageController::class, 'messages'])->name('contact.messages');
                Route::delete('/contact-messages', [ContactPageController::class, 'delete'])->name('contact.message.destroy');

//GENERAL SETTING SECTION

                Route::get('/general-settings', [GeneralSettingController::class, 'siteSettings'])->name('gs.site.settings');
                Route::get('/other/general-settings', [GeneralSettingController::class, 'otherSettings'])->name('gs.other.settings');
                Route::get('/google/analytics', [GeneralSettingController::class, 'google_analytics'])->name('gs.google_analytics');
                Route::get('/facebook/pixel', [GeneralSettingController::class, 'facebookPixel'])->name('gs.facebookPixel');
                Route::post('/general-settings/update', [GeneralSettingController::class, 'update'])->name('gs.update');
                Route::get('/general-settings/logo-favicon', [GeneralSettingController::class, 'logo'])->name('gs.logo');
                Route::get('/general-settings/menu-builder', [GeneralSettingController::class, 'menu'])->name('front.menu');
                Route::get('/general-settings/maintenance', [GeneralSettingController::class, 'maintenance'])->name('gs.maintenance');
                Route::get('/general-settings/status/update/{value}', [GeneralSettingController::class, 'StatusUpdate'])->name('gs.status');

// Currency
                Route::get('/manage-currency', [ManageCurrencyController::class, 'index'])->name('currency.index');
                Route::get('/add-currency', [ManageCurrencyController::class, 'addCurrency'])->name('currency.add');
                Route::post('/add/currency/store', [ManageCurrencyController::class, 'store'])->name('currency.store');
                Route::get('/edit-currency/{id}', [ManageCurrencyController::class, 'editCurrency'])->name('currency.edit');
                Route::put('/update-currency/{id}', [ManageCurrencyController::class, 'updateCurrency'])->name('currency.update');
                Route::get('/currency/set-default/{id}', [ManageCurrencyController::class, 'setDefault'])->name('currency.default');
                Route::delete('/delete-currency', [ManageCurrencyController::class, 'deleteCurrency'])->name('currency.delete');




// Language Manage
                
                Route::resource('language', LanguageController::class);
                Route::post('add-translate/{id}', [LanguageController::class,'storeTranslate'])->name('translate.store');
                Route::post('update-translate/{id}', [LanguageController::class,'updateTranslate'])->name('translate.update');
                Route::post('remove-translate', [LanguageController::class,'removeTranslate'])->name('translate.remove');
                Route::post('language/status-update', [LanguageController::class,'statusUpdate'])->name('update-status.language');
                Route::post('language/remove', [LanguageController::class,'destroy'])->name('remove.language');
  

// Payment Method
                Route::get('/payment/method', [PaymentMethodController::class, 'index'])->name('payment.method.index');
                Route::get('/payment/method/create', [PaymentMethodController::class, 'create'])->name('payment.method.create');
                Route::post('/payment/method/store', [PaymentMethodController::class, 'store'])->name('payment.method.store');
                Route::get('/payment/method/edit/{id}', [PaymentMethodController::class, 'edit'])->name('payment.method.edit');
                Route::put('/payment/method/update/{id}', [PaymentMethodController::class, 'update'])->name('payment.method.update');
                Route::delete('/payment/method/destroy', [PaymentMethodController::class, 'delete'])->name('payment.method.delete');

// ORDER MANAGE
                Route::get('/orders', [OrderController::class, 'index'])->name('order.index');
                Route::get('/order/details/{id}', [OrderController::class, 'details'])->name('order.details');
                Route::post('/order/update/{id}', [OrderController::class, 'update'])->name('order.update');

// MANGE CUSTOMER
                Route::get('/customers', [CustomerController::class, 'index'])->name('customer.index');
                Route::get('/customer/details/{id}', [CustomerController::class, 'details'])->name('customer.details');
                Route::get('/customer/mail/{id}', [CustomerController::class, 'mail'])->name('customer.mail');
                Route::post('/customer/mail/send/{id}', [CustomerController::class, 'mailSend'])->name('customer.mail.send');
                Route::get('/customer/edit/{id}', [CustomerController::class, 'edit'])->name('customer.edit');
                Route::put('/customer/update/{id}', [CustomerController::class, 'update'])->name('customer.update');
                Route::get('/customer/login/{id}', [CustomerController::class, 'login'])->name('customer.login');
            });

// Domain Setting

            Route::get('/domain-setting', [DomainSettingController::class, 'index'])->name('domain.setting');
            Route::post('send/domain/request', [DomainSettingController::class, 'sendRequest'])->name('domain.request.send');
            Route::put('send/domain/update/{id}', [DomainSettingController::class, 'updateRequest'])->name('domain.request.update');
            Route::delete('send/domain/destroy', [DomainSettingController::class, 'destroy'])->name('domain.request.destroy');

            // Subscription
            Route::get('/subscription', [SubscriptionController::class, 'index'])->name('subscription.index');
            Route::get('/subscription/details/{id}', [SubscriptionController::class, 'details'])->name('subscription.details');
            Route::get('/subscription/order/details/{id}', [SubscriptionController::class, 'order_details'])->name('subscription.order.details');
            Route::get('subscription/get/form/{keyword}', [SubscriptionController::class, 'getForm'])->name('subscription.form.get');
            Route::post('subscription/free/submit', [SubscriptionController::class, 'freeSubscription'])->name('subscription.free.submit');

            // support ticket
            Route::get('support/tickets', [SupportTicketController::class, 'index'])->name('ticket.index');
            Route::post('open/support/tickets', [SupportTicketController::class, 'openTicket'])->name('ticket.open');
            Route::post('reply/ticket/{ticket_num}', [SupportTicketController::class, 'replyTicket'])->name('ticket.reply');

            Route::post('/paypal/submit', [PaypalController::class, 'store'])->name('paypal.submit');
            Route::get('/paypal/notify', [PaypalController::class, 'notify'])->name('paypal.notify');
            Route::post('/stripe/submit', [StripeController::class, 'store'])->name('stripe.submit');
            Route::post('/authorize/submit', [AuthorizeController::class, 'store'])->name('authorize.submit');
            Route::post('/paytm-submit', [PaytmController::class, 'store'])->name('paytm.submit');;
            Route::post('/paytm/notify', [PaytmController::class, 'paytmCallback'])->name('paytm.notify');
            Route::post('/razorpay/submit', [RazorpayController::class, 'store'])->name('razorpay.submit');;
            Route::post('/razorpay/notify', [RazorpayController::class, 'razorCallback'])->name('razorpay.notify');
            Route::post('/paystack/submit', [PaystackController::class, 'store'])->name('paystack.submit');

        });
    });
});
