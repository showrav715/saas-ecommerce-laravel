<?php

use App\Http\Controllers\Front\LandingController;
use App\Http\Controllers\Front\PackageOrderController;
use App\Http\Controllers\LandingPayment\AuthorizeController;
use App\Http\Controllers\LandingPayment\PaypalController as LandingPaymentPaypalController;
use App\Http\Controllers\LandingPayment\PaystackController as LandingPaymentPaystackController;
use App\Http\Controllers\LandingPayment\PaytmController as LandingPaymentPaytmController;
use App\Http\Controllers\LandingPayment\RazorpayController as LandingPaymentRazorpayController;
use App\Http\Controllers\LandingPayment\StripeController as LandingPaymentStripeController;
use App\Http\Controllers\LandingPayment\TapController;
use App\Http\Controllers\SellerFront\CartController;
use App\Http\Controllers\SellerFront\CheckoutController;
use App\Http\Controllers\SellerFront\CompareController;
use App\Http\Controllers\SellerFront\FrontendController;
use App\Http\Controllers\SellerFront\ProductController;
use App\Http\Controllers\SellerUser\DashboardController;
use App\Http\Controllers\SellerUser\LoginController;
use App\Http\Controllers\SellerUser\OrderController;
use App\Http\Controllers\SellerUser\WishlistController;
use App\Http\Controllers\UserPayment\AuthorizeController as UserPaymentAuthorizeController;
use App\Http\Controllers\UserPayment\CashOnDeliveryController;
use App\Http\Controllers\UserPayment\ManualPaymentController;
use App\Http\Controllers\UserPayment\MercadopagoController;
use App\Http\Controllers\UserPayment\PaypalController;
use App\Http\Controllers\UserPayment\PaystackController;
use App\Http\Controllers\UserPayment\PaytmController;
use App\Http\Controllers\UserPayment\RazorpayController;
use App\Http\Controllers\UserPayment\StripeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::view('error', 'errors.404')->name('error');

// get host 
$domain = env('MAIN_DOMAIN');

// if (substr($_SERVER['HTTP_HOST'], 0, 4) === 'www.') {
//     $domain = 'www.' . env('MAIN_DOMAIN');
// }

Route::group(['domain' => $domain],function () {

    Route::get('/', [LandingController::class, 'index'])->name('landing.index');
    Route::get('/packages', [LandingController::class, 'pricing'])->name('landing.pricing');
    Route::get('/package/order/{id}', [LandingController::class, 'pricing_order'])->name('landing.package.order');
    Route::get('/currency/setup', [LandingController::class, 'currencySetup'])->name('landing.currency.store');
    Route::get('/contact', [LandingController::class, 'contact'])->name('landing.contact');
    Route::get('/blogs', [LandingController::class, 'blogs'])->name('landing.blogs');
    // login
    Route::get('/login', [LandingController::class, 'login'])->name('landing.login');
    Route::post('/login/submit', [LandingController::class, 'loginSubmit'])->name('landing.login.submit');

    Route::get('blog/{slug}/', [LandingController::class, 'blogShow'])->name('landing.blog.show');

    
    Route::post('/paypal/submit', [LandingPaymentPaypalController::class,'store'])->name('landing.paypal.submit');
    Route::get('/paypal/notify', [LandingPaymentPaypalController::class,'notify'])->name('landing.paypal.notify');
    Route::post('/stripe/submit', [LandingPaymentStripeController::class,'store'])->name('landing.stripe.submit');
    Route::post('/authorize/submit', [AuthorizeController::class,'store'])->name('landing.authorize.submit');
    Route::post('/paytm/submit', [LandingPaymentPaytmController::class,'store'])->name('landing.paytm.submit');
    Route::post('/paytm/notify', [LandingPaymentPaytmController::class,'paytmCallback'])->name('landing.paytm.notify');
    Route::post('/razorpay/submit', [LandingPaymentRazorpayController::class,'store'])->name('landing.razorpay.submit');
    Route::post('/razorpay/notify', [LandingPaymentRazorpayController::class,'razorCallback'])->name('landing.razorpay.notify');
    Route::post('/paystack/submit', [LandingPaymentPaystackController::class,'store'])->name('landing.paystack.submit');
    Route::post('/tap/submit', [TapController::class,'store'])->name('landing.tap.submit');
    Route::get('/tap/payment/notify', [TapController::class,'notify'])->name('landing.tap.payment.notify');
    // package order 
    Route::get('package/get/form/{keyword}', [PackageOrderController::class, 'getForm'])->name('landing.form.get');
    Route::get('/{slug}', [LandingController::class, 'page'])->name('landing.page');
    
});


Route::group(['middleware' => 'seller-check'], function () {
    Route::name('seller.')->group(function () {
        Route::get('/', [FrontendController::class, 'index'])->name('front.index');
        Route::get('/contact', [FrontendController::class, 'contact'])->name('front.contact');
        Route::post('/contact/submit', [FrontendController::class, 'contactSubmit'])->name('front.contact.submit');
        Route::get('/blog', [FrontendController::class, 'blog'])->name('front.blog');
        Route::get('/blog/{slug}', [FrontendController::class, 'blogShow'])->name('front.blog.show');

        Route::get('/currency/set/default/{id}', [FrontendController::class, 'setCurrency'])->name('front.currency.set');
        Route::get('/language/set/default/{id}', [FrontendController::class, 'setlanguage'])->name('front.language.set');

        // products
        Route::get('catalog', [ProductController::class, 'index'])->name('front.product.catalog');
        Route::get('/product/{slug}', [ProductController::class, 'details'])->name('front.product.details');
        Route::get('/highlight/products/{type}', [ProductController::class, 'highlight'])->name('front.highlight.product');
        Route::post('/product/review/submit', [ProductController::class, 'reviewSubmit'])->name('front.product.review');

        // compare products
        Route::get('/compare/view', [CompareController::class, 'compare'])->name('front.compare.index');
        Route::get('/compare/add/{id}', [CompareController::class, 'addcompare'])->name('front.compare.add');
        Route::get('/compare/remove/{id}', [CompareController::class, 'removecompare'])->name('front.compare.remove');

        // 

        // cart
        Route::get('/cart', [CartController::class, 'index'])->name('front.cart.index');
        Route::get('/refresh/cart', [CartController::class, 'refreshCart'])->name('front.cart.refresh');
        Route::get('/header/cart', [CartController::class, 'headerCart'])->name('front.header.cart.load');
        Route::post('/cart/item/store', [CartController::class, 'store'])->name('front.cart.store');
        Route::get('/cart/item/remove/{key}', [CartController::class, 'cartRemove'])->name('front.cart.remove');
        Route::post('apply/coupon', [CartController::class, 'applyCoupon'])->name('front.cart.coupon');

        // checkout
        Route::get('/checkout', [CheckoutController::class, 'index'])->name('front.checkout.index');
        Route::get('/get/shipping/address/{location_id}', [CheckoutController::class, 'getShipping'])->name('front.get.shipping');
        Route::get('checkout/get/form/{keyword}',[CheckoutController::class,'getForm'])->name('front.checkout.form.get');
        // gatway payment route

        Route::post('/paypal/submit', [PaypalController::class,'store'])->name('front.paypal.submit');
        Route::get('/paypal/notify', [PaypalController::class,'notify'])->name('front.paypal.notify');
        Route::post('/stripe/submit', [StripeController::class,'store'])->name('front.stripe.submit');
        Route::post('/mercadopago/submit', [MercadopagoController::class,'store'])->name('front.mercadopago.submit');
        Route::post('/authorize/submit', [UserPaymentAuthorizeController::class,'store'])->name('front.authorize.submit');
        Route::post('/paytm/submit', [PaytmController::class,'store'])->name('front.paytm.submit');
        Route::post('/paytm/notify', [PaytmController::class,'paytmCallback'])->name('front.paytm.notify');
        Route::post('/razorpay/submit', [RazorpayController::class,'store'])->name('front.razorpay.submit');
        Route::post('/razorpay/notify', [RazorpayController::class,'razorCallback'])->name('front.razorpay.notify');
        Route::post('/paystack/submit', [PaystackController::class,'store'])->name('front.paystack.submit');
        Route::post('/cashondelivery/submit', [CashOnDeliveryController::class,'store'])->name('front.cod.submit');
        Route::post('/manual/submit', [ManualPaymentController::class,'store'])->name('front.manual.submit');
       

        Route::get('/{slug}', [FrontendController::class, 'page'])->name('front.page');

        // =================== USER ===================//
        Route::prefix('user')->name('user.')->group(function () {
            Route::get('/login', [LoginController::class, 'login'])->name('login');
            Route::post('/login/submit', [LoginController::class, 'loginSubmit'])->name('login.submit');
            Route::get('/register', [LoginController::class, 'register'])->name('register');
            Route::post('/register/submit', [LoginController::class, 'registerSubmit'])->name('register.submit');
            Route::get('/verify/email/{code}', [LoginController::class, 'verifyEmail'])->name('verify.email');
            Route::get('/forgot/password', [LoginController::class, 'forgotPassword'])->name('forgot.password');
            Route::post('/forgot/password/submit', [LoginController::class, 'forgotPasswordSubmit'])->name('forgot.submit');
            Route::get('/forgot/reset/password/{code}', [LoginController::class, 'resetPassword'])->name('reset.password');
            Route::post('/forgot/reset/password/submit', [LoginController::class, 'resetPasswordSubmit'])->name('reset.password.submit');

            Route::group(['middleware' => 'auth:web'], function () {
                // =================== USER DASHBOARD ===================//
                Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
                Route::get('/profile', [DashboardController::class, 'profile'])->name('profile');
                Route::post('/profile/update', [DashboardController::class, 'profileUpdate'])->name('profile.update');
                Route::get('/reset/password', [DashboardController::class, 'reset'])->name('reset');
                Route::post('/reset/password/submit', [DashboardController::class, 'resetSubmit'])->name('reset.submit');
                Route::get('/logout', [DashboardController::class, 'logout'])->name('logout');


                // =================== USER WISHLIST ===================//
                Route::get('/wishlists/view', [WishlistController::class,'wishlists'])->name('wishlist.index');
                Route::get('/wishlist/add/{id}',[WishlistController::class,'addwish'])->name('wishlist.add');
                Route::get('/wishlist/remove/{id}', [WishlistController::class,'removewish'])->name('wishlist.remove');


                // =================== USER ORDER ===================//
                Route::get('/orders', [OrderController::class,'index'])->name('order.index');
                Route::get('/order/details/{id}', [OrderController::class,'orderDetails'])->name('order.details');
                Route::get('/order/print/{id}', [OrderController::class,'print'])->name('order.print');
              


            });
        });

    });

});







